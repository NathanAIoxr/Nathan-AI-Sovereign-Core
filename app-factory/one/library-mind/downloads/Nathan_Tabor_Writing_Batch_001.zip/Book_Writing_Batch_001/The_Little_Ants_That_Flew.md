# THE LITTLE ANTS THAT FLEW
## By Nathan Tabor

### 1. The Agreement

I have an agreement with nature.

Especially the bug world.

You stay off me, and we can coexist.

The tree belongs to the tree.
The grass belongs to the grass.
The ant has ant business.
I have Nathan business.

We have a whole world to share.

Then a little ant climbed onto my arm.

Right onto my arm.

Apparently, he had not read the agreement.

### 2. Six Feet on Nathan Street

He walked across one hair.

Under another.

Around a freckle.

Six feet. No shoes. No hesitation.

He stopped beside my elbow like a little fellow checking a street sign.

“Nathan Street,” he announced.

I looked down.

He looked up.

“Little fellow,” I said, “that street is closed.”

The ant lifted one foot.

Then another.

Then he kept right on walking.

### 3. The First Flight

I took a breath.

A little breath for me.

A whole weather event for him.

Pfffff!

Off he went toward the grass beside my chair.

Six feet in the air.

No ticket.
No suitcase.
No airplane.

“WEEEEEEEE!”

He landed on a broad green leaf.

For one quiet second, he stood perfectly still.

Then he spread all six feet.

“THE GIANT JUST MADE ME FLY!”

### 4. Tell Everybody

He ran down the leaf.

Across the stem.

Over a twig.

Straight into another ant.

“Watch where you’re going!” said the other ant.

“I KNOW where I’m going!”

“Where?”

“BACK!”

“Back where?”

“To the giant!”

The other ant lowered his crumb.

“The enormous one?”

“Yes!”

“The one with the enormous feet?”

“Yes!”

“The one who just blew you off?”

The little ant stood tall.

“The one who just made me FLY.”

### 5. Here He Comes Again

I settled into my chair.

The sun warmed my arm.

The leaves moved overhead.

Something tickled my wrist.

I looked down.

Another little ant.

Same road.
Same direction.
Same complete disregard for the agreement.

“You again?” I said.

He walked toward my elbow.

I watched him go.

A dog brings a ball back.

This little fellow brought himself.

### 6. The Little Aunt

Then I saw the second size.

Bigger than the almost invisible fellow.

Smaller than the ants I see marching through a kitchen.

A little aunt.

AUNT?

No.

ANT.

Although she walked with the confidence of an aunt who knew exactly where everybody ought to be.

“Single file!” she told the little fellow.

He stepped behind her.

She stepped forward.

They both stepped onto me.

“Wrong line,” I said.

### 7. The Almost Invisible One

Then the smallest ant arrived.

Almost too small to see.

Not too small to be somebody.

He stood beside the middle-sized ant.

The middle-sized ant stood beside the larger ant.

Little.
Littler.
Almost look-again.

Three sizes.

Three sets of six feet.

One arm.

Mine.

The smallest ant lifted his front feet.

“I’M HERE!”

The larger ant looked down.

“We see you.”

“GOOD. I WANT A TURN.”

### 8. Read the Agreement

“All right,” I said. “Listen carefully.”

The ants stopped.

“You stay off me.”

The little ant stepped sideways.

“We can coexist.”

The middle-sized ant nodded like a little aunt at a family meeting.

“There is grass.”

Six feet pointed toward the grass.

“There are leaves.”

Six more feet pointed toward the leaves.

“There is an entire yard.”

The smallest ant looked across my arm.

“THIS IS A VERY WARM YARD.”

“This,” I said, “is Nathan.”

### 9. The Big Breath

I leaned closer.

The larger ant planted his feet.

The middle-sized ant lowered herself.

The smallest ant stood as tall as small could stand.

I took a breath.

The leaves waited.

The grass waited.

The three little ants waited.

PFFFFFF!

“WEEEEEEEE!”

Three sizes went sailing toward the green.

One turned sideways.

One turned around.

The smallest one shouted louder than both the others.

“I’M STILL HEEEEERE!”

### 10. The Landing Committee

The larger ant landed on a leaf.

The middle-sized ant landed beside a stem.

The smallest ant landed on the larger ant.

“OFF,” said the larger ant.

The smallest ant climbed down.

“You sound like the giant.”

“I have an agreement too.”

The middle-sized ant counted them.

“One. Two. Three.”

All present.

All standing.

All talking at once.

“I went highest!”

“I went farthest!”

“I LANDED ON SOMEBODY!”

“Yes,” said the larger ant. “I noticed.”

### 11. Black Ants, Brown Giant

They were black.

I was brown.

Pasty-white brown, with a little more sunshine on some places than others.

Against my arm, those little black ants showed up like moving marks on a page.

Big and little.
Dark and light.

The yard held all of us.

Nobody had to look like anybody else to belong in it.

The smallest ant stood on a pale stone.

“LOOK! NOW I HAVE A STAGE!”

The larger ant kept walking.

“You always have a stage.”

### 12. The Return Trip

Across the twig.

Around the stone.

Under the chair.

Back came the little feet.

I saw them near my shoe.

“Now hold on.”

They held on.

To my shoe.

“That is not what I meant.”

The middle-sized ant looked toward the others.

“He is explaining the rules again.”

The smallest ant climbed onto a blade of grass.

“I CAN HEAR HIM FROM HERE!”

“Good,” I said. “Stay there.”

He stayed there.

For one whole ant-sized moment.

### 13. A Better Place

I put a broad fallen leaf beside my chair.

An ant-sized platform.

A Nathan-sized solution.

“Here,” I said.

The larger ant stepped onto it.

The middle-sized ant inspected the edge.

The smallest ant ran straight to the highest wrinkle.

“BALCONY!”

I moved the leaf beside the grass.

Three passengers.

One leaf.

Nobody on my arm.

The little aunt stood in the middle.

“Everybody off. Take your feet with you.”

### 14. Ant Business

A crumb waited near a root.

The larger ant found it.

The middle-sized ant took one side.

The smallest ant grabbed a corner.

“That corner is bigger than you,” said the larger ant.

“THEN HELP ME.”

So they helped.

One pulled.
One pushed.
One shouted instructions from underneath.

Together, the crumb moved.

Across the dirt.

Around the root.

Homeward.

They had ant business to finish.

I had Nathan business to finish.

For once, we were both doing it.

### 15. Who Came Back

Later, three little shapes moved beside my chair.

One larger.

One middle-sized.

One almost too small to see.

I knew the story they carried.

The giant.

The breath.

The leaf.

The flight.

Their story had six little feet and a great big WEEE in the middle.

They stopped at the grass.

I stayed in my chair.

The agreement stood between us.

A whole yard stood around us.

That was enough room for everybody.

### 16. The Little Ants That Flew

The sun moved.

The shadows stretched.

I rested my arm on the chair.

Something tickled.

I looked down.

One little ant.

Standing on my wrist.

I looked at him.

He looked at me.

“Little fellow,” I said, “you know the agreement.”

He lifted his front feet.

I took one little breath.

And somewhere inside that enormous little adventure—

“WEEEEEEEE!”

The giant had made him fly.

Again.

**THE END**
