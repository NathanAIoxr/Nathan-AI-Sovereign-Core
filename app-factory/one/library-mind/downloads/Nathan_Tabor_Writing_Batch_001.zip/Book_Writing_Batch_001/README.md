# Writing Batch 001 — Nathan Tabor

The first new complete story is The Little Ants That Flew: 16 sections, a complete beginning and ending, expanded from Nathan Tabor’s preserved source words. The original words and the new manuscript are separate files.

Style: direct statements, playful repetition, the WEEE refrain, three ant sizes, the little aunt/ant joke, nature’s coexistence agreement, and Nathan’s voice. No Vatican framing. Talking ants belong to the story.

`writing_register.json` distinguishes this completed first draft from existing series awaiting manuscript inventory. The 2,000+ original manuscripts reported by Nathan are not recreated or counted as imported here. A search found the source for this story and the existing planning index; that does not establish the presence or absence of other manuscripts.

`publishing_database.sqlite` extends the v0.2 database with this one actual source manuscript, its hash, stable source sections and D27 linkage. Its required series field uses a catalog collection with thirteen available positions, not an invented thirteen-volume ant series. One manuscript is registered; language review and translations have not been completed. The original v0.2 release remains unchanged.

Use the v0.2 publishing CLI with `--db publishing_database.sqlite` to inspect or extend this database. The writing register is the visible ledger of this batch. No background writing process continues after delivery.
