from pathlib import Path
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT

root=Path('/workspace/scratch/b47db66952ec')
src=root/'Nathan_Tabor_Forensic_Project_Dossier_2026-10-30.md'
doc=Document(); sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=sec.bottom_margin=Inches(.7)
sec.left_margin=sec.right_margin=Inches(.75)
for name in ['Normal','Title','Subtitle','Heading 1','Heading 2','Heading 3']:
 st=doc.styles[name];st.font.name='Calibri';st.font.color.rgb=RGBColor(0,0,0)
doc.styles['Normal'].font.size=Pt(11)
doc.styles['Normal'].paragraph_format.space_after=Pt(7)
doc.styles['Normal'].paragraph_format.line_spacing=1.08
doc.styles['Title'].font.size=Pt(27)
for n,size in [('Heading 1',16),('Heading 2',12),('Heading 3',11)]:
 doc.styles[n].font.size=Pt(size);doc.styles[n].paragraph_format.space_before=Pt(13);doc.styles[n].paragraph_format.space_after=Pt(7)
 doc.styles[n].paragraph_format.keep_with_next=True

def inline(p,text):
 for token in re.split(r'(\[[^\]]+\]\([^)]+\)|\*\*[^*]+\*\*|`[^`]+`)',text):
  if not token:continue
  m=re.fullmatch(r'\[([^\]]+)\]\(([^)]+)\)',token)
  if m:
   h=OxmlElement('w:hyperlink');h.set(qn('r:id'),p.part.relate_to(m[2],RT.HYPERLINK,is_external=True))
   rr=OxmlElement('w:r');rp=OxmlElement('w:rPr');co=OxmlElement('w:color');co.set(qn('w:val'),'24527A');rp.append(co);rr.append(rp);tt=OxmlElement('w:t');tt.text=m[1];rr.append(tt);h.append(rr);p._p.append(h)
  elif token.startswith('**'):
   p.add_run(token[2:-2]).bold=True
  elif token.startswith('`'):
   r=p.add_run(token[1:-1]);r.font.name='Consolas';r.font.size=Pt(8)
  else:p.add_run(token)

def table(rows):
 cols=len(rows[0]);t=doc.add_table(rows=0,cols=cols);t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
 if cols==2:widths=[2.05,4.95]
 elif cols==3 and rows[0][0]=='Code':widths=[.6,4.9,1.5]
 elif cols==3 and rows[0][0]=='Book':widths=[.55,4.7,1.75]
 elif cols==3:widths=[1.45,2.55,3.0]
 else:widths=[7/cols]*cols
 if cols==2 and rows[0][0]=='Collection':widths=[5.7,1.3]
 for c,w in zip(t.columns,widths):c.width=Inches(w)
 pr=t._tbl.tblPr;b=OxmlElement('w:tblBorders')
 for edge in ['top','left','bottom','right','insideH','insideV']:
  e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');b.append(e)
 pr.append(b)
 for i,row in enumerate(rows):
  cells=t.add_row().cells;trpr=t.rows[-1]._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
  if i==0:trpr.append(OxmlElement('w:tblHeader'))
  for k,(cell,value) in enumerate(zip(cells,row)):
   cell.width=Inches(widths[k]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
   cp=cell._tc.get_or_add_tcPr();m=OxmlElement('w:tcMar')
   for edge in ['top','left','bottom','right']:
    e=OxmlElement('w:'+edge);e.set(qn('w:w'),'90');e.set(qn('w:type'),'dxa');m.append(e)
   cp.append(m);sh=OxmlElement('w:shd');sh.set(qn('w:fill'),'E6EDF3' if i==0 else ('F7F9FB' if i%2==0 else 'FFFFFF'));cp.append(sh)
   p=cell.paragraphs[0];p.paragraph_format.space_after=Pt(2);p.paragraph_format.line_spacing=1.02
   inline(p,value)
   for r in p.runs:r.font.size=Pt(10);r.bold=(True if i==0 else r.bold)
   if re.fullmatch(r'[\d,]+',value):p.alignment=WD_ALIGN_PARAGRAPH.CENTER
 doc.add_paragraph().paragraph_format.space_after=Pt(2)

lines=src.read_text().splitlines();i=0
while i<len(lines):
 line=lines[i]
 if not line or line=='---':i+=1;continue
 if line.startswith('|'):
  rows=[]
  while i<len(lines) and lines[i].startswith('|'):
   row=[x.strip() for x in lines[i].strip('|').split('|')]
   if not all(re.fullmatch(r'[-: ]+',x) for x in row):rows.append(row)
   i+=1
  table(rows);continue
 if line.startswith('# '):doc.add_paragraph('Nathan Tabor Project Dossier','Title')
 elif line.startswith('## Forensic project dossier:'):doc.add_paragraph('Achievements Active Development and the Finished Vision','Subtitle')
 elif line.startswith('#'):
  n=len(line)-len(line.lstrip('#'));txt=line[n:].strip();txt=txt.replace('Nathan’s','Nathan Tabor').replace('ChatGPT’s','ChatGPT');txt=re.sub(r'[^\w\s]',' ',txt);txt=re.sub(r'\s+',' ',txt)
  doc.add_paragraph(txt,'Heading '+str(min(n-1,3)))
 else:inline(doc.add_paragraph(),line)
 i+=1
f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.RIGHT
f.add_run('Nathan Tabor Project Dossier  |  ').font.size=Pt(9)
field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');f._p.append(field)
doc.core_properties.author='ChatGPT'
doc.core_properties.title='Nathan Tabor Project Dossier'
doc.core_properties.subject='Achievements active development and completion vision'
for el in doc.styles.element.xpath('.//w:pBdr'):
 el.getparent().remove(el)
for el in doc.element.xpath('.//w:pBdr'):
 el.getparent().remove(el)
doc.save(root/'Nathan_Tabor_Forensic_Project_Dossier_2026-10-30.docx')
