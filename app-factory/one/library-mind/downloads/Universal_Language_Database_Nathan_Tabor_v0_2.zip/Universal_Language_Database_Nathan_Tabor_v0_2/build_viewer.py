#!/usr/bin/env python3
"""Build self-contained, offline HTML viewer from current SQLite database."""
from pathlib import Path
import sqlite3, json, html
root = Path(__file__).resolve().parent
con=sqlite3.connect(root/'universal_languages.sqlite'); con.row_factory=sqlite3.Row
rows=con.execute('''SELECT v.variety_id,v.preferred_name,v.kind,v.iso_type,v.iso_scope,v.vitality,v.review_status,
  (SELECT identifier FROM identifiers WHERE variety_id=v.variety_id AND scheme='ISO_639_3' LIMIT 1) AS iso3,
  (SELECT identifier FROM identifiers WHERE variety_id=v.variety_id AND scheme='ISO_639_1' LIMIT 1) AS iso1,
  (SELECT identifier FROM identifiers WHERE variety_id=v.variety_id AND scheme='GLOTTOCODE' LIMIT 1) AS glotto
  FROM varieties v ORDER BY preferred_name COLLATE NOCASE''').fetchall()
data=[dict(r) for r in rows]
blob=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
base = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Universal Language Database | Nathan Tabor · v0.1</title>
<style>
:root{color-scheme:light;--ink:#18253c;--muted:#657286;--line:#d9e1e9;--bg:#f5f7fa;--white:#fff;--blue:#164a72;--mint:#eaf6ef}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.52 system-ui,-apple-system,'Segoe UI',sans-serif}
main{max-width:1120px;margin:0 auto;padding:32px 18px 55px}h1{font-size:clamp(24px,3.3vw,42px);margin:0 0 7px;line-height:1.16;letter-spacing:-1px}h2{font-size:18px;margin:0 0 12px}p{margin:8px 0 16px}.eyebrow{color:var(--blue);font-size:12px;letter-spacing:.13em;font-weight:800;text-transform:uppercase}
.muted,small{color:var(--muted)}.intro{max-width:790px;font-size:16px}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:22px 0}
.stat,.panel{background:var(--white);border:1px solid var(--line);border-radius:15px}.stat{padding:18px}.stat strong{font-size:27px;display:block;font-variant-numeric:tabular-nums}.stat small{display:block;font-size:12px}.panel{padding:18px;margin-top:18px}
.controls{display:grid;grid-template-columns:minmax(0,2fr) repeat(2,minmax(150px,1fr));gap:12px;align-items:end}.ctrl{display:flex;flex-direction:column;gap:6px}.ctrl label{font-size:12px;font-weight:700;color:var(--muted)}input,select,button{font:inherit;border-radius:9px;border:1px solid #bcc8d5;padding:10px 12px;background:white;min-width:0}input:focus,select:focus,button:focus-visible{outline:3px solid #a5d7e8;outline-offset:2px}button{cursor:pointer;color:var(--blue);font-weight:700}button:hover{background:#eef5f9}.toolbar{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;align-items:center;margin-top:16px}.toolbar .muted{margin:0}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;margin-top:10px;min-width:620px}th{position:sticky;top:0;background:#edf2f7;text-align:left;font-size:12px;color:#4b5d6e}td,th{padding:12px 12px;border-bottom:1px solid #e6ebf0}tbody tr:hover{background:#f8fafc}.name{font-weight:700;cursor:pointer;background:none;border:0;padding:0;text-align:left;color:var(--blue);text-decoration:underline;text-underline-offset:2px}.tag{font-size:12px;color:#30506a;background:#eaf2fa;border-radius:20px;padding:2px 8px;white-space:nowrap}.pager{display:flex;justify-content:flex-end;align-items:center;gap:10px;margin-top:15px}.pager button{padding:7px 12px}.detail{margin-top:15px;padding:16px;border:1px solid var(--line);background:#fbfcff;border-radius:12px}.detail h3{margin:0 0 6px}.facts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;font-size:14px}.facts div{padding:8px;background:#fff;border-radius:7px}.important{border-left:4px solid #2d6c8f;padding-left:15px}.foot{margin-top:18px;font-size:12px;color:var(--muted)}.hidden{display:none}a{color:var(--blue)}
@media(max-width:720px){.stats{grid-template-columns:repeat(2,1fr)}.controls{grid-template-columns:1fr}.facts{grid-template-columns:1fr}}
</style></head><body><main>
<div class="eyebrow">ONE · The Library Mind of John Nathan Tabor · D17 Languages & Translation</div>
<h1>The Universal Language Database</h1>
<p class="intro">Search the first source-linked reference catalog of human languages. This local prototype preserves different kinds of language records rather than equating an ISO code with government recognition or current vitality.</p>
<div class="stats" id="stats"></div>
<section class="panel"><h2>Explore the catalog</h2>
<div class="controls">
<div class="ctrl"><label for="query">Language name or ISO code</label><input id="query" placeholder="Try Akkadian, Swahili, English, Arabic, or ase…" autocomplete="off"></div>
<div class="ctrl"><label for="type">ISO type in local snapshot</label><select id="type"><option value="">All ISO types</option><option value="L">Living (L) *</option><option value="E">Extinct (E) *</option><option value="A">Ancient (A)</option><option value="H">Historical (H)</option><option value="C">Constructed (C)</option><option value="S">Special (S)</option></select></div>
<div class="ctrl"><label for="kind">Record kind</label><select id="kind"><option value="">All kinds</option><option>language</option><option>macrolanguage</option><option>special</option><option>dialect</option><option>family</option><option>unclassified</option><option>register</option></select></div>
</div><div class="toolbar"><p id="count" class="muted"></p><button id="export">Export matching rows to CSV</button></div>
<div class="scroll"><table><thead><tr><th>Language / entry</th><th>ISO 639-3</th><th>Record kind</th><th>ISO type *</th><th>Vitality assessment</th></tr></thead><tbody id="results"></tbody></table></div>
<div class="pager"><button id="prev">Previous</button><span id="pageLabel"></span><button id="next">Next</button></div>
<div id="detail" class="detail hidden" aria-live="polite"></div></section>
<section class="panel important"><h2>What these entries do and do not establish</h2>
<p><b>ISO codes and names are a reference index, not the full research database.</b> A name in the catalog does not prove living speakers today, legal recognition, a native script, a reconstructed lexicon, or complete documentation. "Living" and "Extinct" in the filter refer only to ISO type labels from the bundled snapshot. Current community status must be independently documented.</p>
<p><b>Expansion paths:</b> Glottolog varieties and genealogies, community names, unwritten and underrecognized varieties, historical texts, inscriptions, sign languages, IPA, source-backed lexical items, word comparisons and editorial hypotheses. The SQLite database can link these to D17 and to any of the 33 million reserved book addresses.</p>
<p><b>Preservation rule:</b> no sacred, community-restricted, or privately contributed linguistic material is republished without the appropriate permission.</p></section>
<footer class="foot">Source seed: ISO 639-3 via pycountry 24.6.1 and Debian pkg-isocodes, not verified as the latest ISO release. Build date 2026-10-30. Source: <a href="https://github.com/pycountry/pycountry">pycountry</a>. Next expansion: <a href="https://glottolog.org/download">Glottolog 5.3</a>. Original scripts preserved in Unicode. Entire viewer works offline after saving this file.</footer>
</main><script id="data" type="application/json">__DATA__</script>
<script>
(()=>{'use strict';const items=JSON.parse(document.getElementById('data').textContent);
const labels={L:'Living (ISO)',E:'Extinct (ISO)',A:'Ancient',H:'Historical',C:'Constructed',S:'Special'};
const el=id=>document.getElementById(id);let current=[],page=0;const per=50;
const count=(fn)=>items.filter(fn).length;
el('stats').innerHTML=[['ISO entries',items.length.toLocaleString()],['Individual entries',count(x=>x.iso_scope==='I').toLocaleString()],['ISO living-type individuals',count(x=>x.iso_type==='L'&&x.iso_scope==='I').toLocaleString()],['Ancient / historic / extinct',count(x=>['A','H','E'].includes(x.iso_type)).toLocaleString()]].map(([a,b])=>`<div class="stat"><small>${a}</small><strong>${b}</strong></div>`).join('');
function csvSafe(s){s=String(s??'');if(/^[=+@\-]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';}
function filter(){const q=el('query').value.toLocaleLowerCase().trim(), t=el('type').value,k=el('kind').value;
 current=items.filter(x=>(!q||[x.preferred_name,x.iso3,x.iso1,x.glotto].some(v=>(v||'').toLocaleLowerCase().includes(q)))&&(!t||x.iso_type===t)&&(!k||x.kind===k));page=0;render();}
function render(){const start=page*per;el('count').textContent=current.length.toLocaleString()+' matching entries';
 el('results').replaceChildren(...current.slice(start,start+per).map(x=>{let tr=document.createElement('tr');
 let name=document.createElement('td'),btn=document.createElement('button');btn.className='name';btn.textContent=x.preferred_name;btn.dir='auto';btn.onclick=()=>detail(x);name.append(btn);tr.append(name);
 for(const v of [x.iso3||'—',x.kind,labels[x.iso_type]||'Unspecified',x.vitality||'Not assessed']){let td=document.createElement('td');td.textContent=v;tr.append(td);}return tr;}));
 el('pageLabel').textContent=current.length?`${page+1} / ${Math.ceil(current.length/per)}`:'0 / 0';
 el('prev').disabled=page===0;el('next').disabled=(page+1)*per>=current.length;el('detail').classList.add('hidden');}
function detail(x){const d=el('detail');d.replaceChildren();const h=document.createElement('h3');h.textContent=x.preferred_name;h.dir='auto';d.append(h);
const wrap=document.createElement('div');wrap.className='facts';for(const [key,value] of [['ISO 639-3',x.iso3||'Not assigned in this dataset'],['ISO 639-1',x.iso1||'Not assigned'],['Glottocode',x.glotto||'Not yet imported'],['Record kind',x.kind],['ISO type',labels[x.iso_type]||'Not known'],['Vitality / recognition', 'Not independently assessed'],['Source','ISO 639-3 via pycountry snapshot'],['Original language documents','Not yet populated']]){const p=document.createElement('div');const b=document.createElement('b');b.textContent=key+': ';p.append(b,document.createTextNode(value));wrap.append(p);}d.append(wrap);d.classList.remove('hidden');}
el('query').addEventListener('input',filter);el('type').addEventListener('change',filter);el('kind').addEventListener('change',filter);
el('prev').onclick=()=>{if(page>0){page--;render()}};el('next').onclick=()=>{if((page+1)*per<current.length){page++;render()}};
el('export').onclick=()=>{const columns=['preferred_name','iso3','iso1','kind','iso_type','iso_scope','vitality'];let txt=columns.map(csvSafe).join(',')+'\n'+current.map(x=>columns.map(c=>csvSafe(x[c])).join(',')).join('\n');let a=document.createElement('a'),b=new Blob([txt],{type:'text/csv;charset=utf-8'});a.href=URL.createObjectURL(b);a.download='universal_languages_filtered.csv';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),5000);};
filter();})();
</script></body></html>'''
(root/'language_browser.html').write_text(base.replace('__DATA__',blob),encoding='utf-8')
(root/'catalog_export.json').write_text(json.dumps({'meta':{'title':'Universal Language Database','version':'0.1','source':'ISO 639-3 names and codes via pycountry 24.6.1','warning':'These are code records, not a current total of living languages.'},'records':data},ensure_ascii=False,indent=1),encoding='utf-8')
print('Viewer built for',len(data),'entries')
