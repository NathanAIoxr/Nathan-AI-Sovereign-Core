#!/usr/bin/env python3
"""Offline manuscript × language edition registry. Python standard library only."""
import argparse, hashlib, json, re, sqlite3
from pathlib import Path
HERE=Path(__file__).resolve().parent
CRITERIA=('identity','grammar','lexicon','orthography','evidence','rights','reviewer')
REVIEW=('fidelity','terminology','grammar','script','completeness')

def connect(path=None):
    c=sqlite3.connect(path or HERE/'universal_languages.sqlite')
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    c.execute('PRAGMA busy_timeout=5000')
    return c

def migrate(c):
    c.executescript((HERE/'publishing_schema.sql').read_text())
    c.execute("INSERT OR IGNORE INTO sources(source_id,title,notes) VALUES('nathan-map-v02','Nathan Tabor requested language map','User-directed mapping; linguistic relationships pending external verification. No current web verification succeeded during this build.')")
    for v in c.execute('SELECT * FROM varieties').fetchall():
        category=('umbrella' if v['kind'] in ('family','macrolanguage','special') else {'L':'living','E':'fragmentary','A':'historical','H':'historical','C':'constructed'}.get(v['iso_type'],'research'))
        c.execute('INSERT OR IGNORE INTO language_profiles(variety_id,category) VALUES(?,?)',(v['variety_id'],category))
    entries=[('High Valyrian','language','constructed','A Song of Ice and Fire / Game of Thrones; precise resources and specialist review required.'),('Low Valyrian','unclassified','umbrella','Umbrella for distinct fictional descendant varieties; not one production language.'),('Astapori Valyrian','dialect','constructed','Named Valyrian variety; independent resource assessment required.'),('Meereenese Valyrian','dialect','constructed','Named Valyrian variety; independent resource assessment required.'),('Dothraki','language','constructed','Game of Thrones; domain vocabulary and reviewer availability must be assessed.'),("Na’vi",'language','constructed','Avatar; resource and reviewer assessment required.'),('Quenya','language','constructed','Tolkien; distinguish attested forms from later community extensions.'),('Sindarin','language','constructed','Tolkien; distinguish attested forms from later community extensions.'),('Minoan (Linear A language, provisional)','unclassified','undeciphered','Linear A is a script designation; language identification and decipherment unresolved. No translation target.'),('Unidentified lost language — research category','unclassified','unknown','One research category, not a discovered language or a count of 25,000 records.')]
    ids={}
    for name,kind,category,note in entries:
        r=c.execute('SELECT variety_id FROM varieties WHERE preferred_name=?',(name,)).fetchone()
        if r: vid=r[0]
        else:
            vid=c.execute("INSERT INTO varieties(preferred_name,kind,review_status,summary,initial_source_id) VALUES(?,?,'community_reported',?,'nathan-map-v02')",(name,kind,note)).lastrowid
            c.execute("INSERT INTO names(variety_id,name,name_type,source_id) VALUES(?,?,'catalog_name','nathan-map-v02')",(vid,name))
            c.execute("INSERT INTO identifiers(variety_id,scheme,identifier,source_id) VALUES(?,'INTERNAL',?,'nathan-map-v02')",(vid,'NT-'+str(vid)))
        ids[name]=vid
        c.execute('INSERT OR IGNORE INTO language_profiles(variety_id,category,note) VALUES(?,?,?)',(vid,category,note))
    for child,parent,relation in [('Astapori Valyrian','Low Valyrian','member_of_umbrella'),('Meereenese Valyrian','Low Valyrian','member_of_umbrella'),('Astapori Valyrian','High Valyrian','fictional_descendant'),('Meereenese Valyrian','High Valyrian','fictional_descendant')]:
        c.execute("INSERT OR IGNORE INTO relations(subject_id,object_id,relation_type,source_id,claim_status,note) VALUES(?,?,?,'nathan-map-v02','pending_source_review','Requested map; not a claim of ISO recognition')",(ids[child],ids[parent],relation))
    for (vid,) in c.execute('SELECT variety_id FROM language_profiles').fetchall():
        for criterion in CRITERIA:
            c.execute('INSERT OR IGNORE INTO readiness(variety_id,criterion) VALUES(?,?)',(vid,criterion))
    c.execute('DELETE FROM variety_search')
    c.execute('INSERT INTO variety_search(variety_id,name,kind) SELECT variety_id,preferred_name,kind FROM varieties')
    c.commit()

def digest(text): return hashlib.sha256(text.encode('utf-8')).hexdigest()

def add_work(c,wid,sid,part,title,source_language,text,rights=0,ready=0):
    if type(rights) is not int or rights not in (0,1) or type(ready) is not int or ready not in (0,1): raise ValueError('whole binary integers required')
    if not text.strip(): raise ValueError('empty manuscript')
    c.execute('INSERT INTO works(work_id,series_id,part,title,source_language_id,source_text,source_sha256,rights_cleared,source_ready) VALUES(?,?,?,?,?,?,?,?,?)',(wid,sid,part,title,source_language,text,digest(text),rights,ready))

def plan(c,wid,vid):
    eid='NT-'+hashlib.sha256(json.dumps([wid,int(vid)],ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
    c.execute('INSERT OR IGNORE INTO editions(edition_id,work_id,variety_id) VALUES(?,?,?)',(eid,wid,vid))
    return eid

def index_sections(c,wid,text):
    # Stable source sections; target language may combine or split sentences freely.
    chunks=[x.strip() for x in re.split(r'(?m)(?=^#{1,6}\s+\S)',text) if x.strip()]
    for ordinal,chunk in enumerate(chunks,1):
        c.execute('INSERT INTO source_sections VALUES(?,?,?,?)',(wid+':S'+str(ordinal),wid,ordinal,chunk))

def blockers(c,vid):
    p=c.execute('SELECT * FROM language_profiles WHERE variety_id=?',(vid,)).fetchone()
    if not p: raise ValueError('language profile not found')
    result=[]
    if not p['target_enabled']: result.append('target_disabled')
    if p['category'] in ('unknown','undeciphered','umbrella','research'): result.append('category_requires_assessment_or_specific_variety')
    kind=c.execute('SELECT kind FROM varieties WHERE variety_id=?',(vid,)).fetchone()[0]
    if kind not in ('language','dialect','register'): result.append('not_an_individual_translation_target')
    result.extend('missing_'+r[0] for r in c.execute('SELECT criterion FROM readiness WHERE variety_id=? AND passed=0 ORDER BY criterion',(vid,)))
    return {'variety_id':vid,'active':int(not result),'reasons':result,'note':p['note']}

def advance(c,eid,state):
    if c.execute('UPDATE editions SET state=? WHERE edition_id=?',(state,eid)).rowcount!=1: raise ValueError('edition not found')

def draft(c,eid,text,translator,expected_sections=None,coverage=None):
    if not text.strip(): raise ValueError('empty translation')
    artifact=c.execute('INSERT INTO artifacts(edition_id,text,sha256,translator) VALUES(?,?,?,?)',(eid,text,digest(text),translator)).lastrowid
    placeholders=int(not re.search(r'\b(?:TODO|TBD|TRANSLATE_ME)\b|\{\{[^}]+\}\}',text,re.I))
    # Structure is a human-agreed export contract: explicit Markdown section count.
    count=len(re.findall(r'^#{1,6}\s+\S',text,re.M))
    structural=int(expected_sections is not None and expected_sections>=1 and count==expected_sections)
    report={'section_count':count,'expected_sections':expected_sections,'note':'Structural checks do not establish linguistic fidelity.'}
    c.execute('INSERT INTO artifact_checks VALUES(?,?,?,?,?,?)',(artifact,1,int(bool(text.strip())),placeholders,structural,json.dumps(report)))
    if c.execute("UPDATE editions SET artifact_id=?,state='draft' WHERE edition_id=?",(artifact,eid)).rowcount!=1: raise ValueError('edition not found')
    for section,excerpt in (coverage or {}).items():
        c.execute('INSERT INTO section_coverage VALUES(?,?,?)',(artifact,section,excerpt))
    return artifact

def review(c,eid,reviewer,values,notes):
    if set(values)!=set(REVIEW) or any(type(v) is not int or v not in (0,1) for v in values.values()): raise ValueError('five whole binary review checks required')
    row=c.execute('SELECT artifact_id FROM editions WHERE edition_id=?',(eid,)).fetchone()
    if not row or row[0] is None: raise ValueError('edition has no artifact')
    c.execute('INSERT INTO reviews(artifact_id,reviewer,fidelity,terminology,grammar,script,completeness,notes) VALUES(?,?,?,?,?,?,?,?)',(row[0],reviewer,*(values[k] for k in REVIEW),notes))

def stats(c):
    n=lambda sql: c.execute(sql).fetchone()[0]
    capacity=n("SELECT value FROM publishing_config WHERE key='language_capacity'")
    works=n('SELECT count(*) FROM works')
    return {'language_capacity':capacity,'catalog_records':n('SELECT count(*) FROM language_profiles'),'ready_languages':n('SELECT count(*) FROM ready_languages'),'reported_manuscripts_floor':2000,'registered_manuscripts':works,'reported_capacity_projection':2000*capacity,'registered_capacity_projection':works*capacity,'actual_edition_records':n('SELECT count(*) FROM editions'),'approved_records':n("SELECT count(*) FROM editions WHERE state='approved'"),'currently_publishable_records':n('SELECT count(*) FROM publishable_editions'),'states':dict(c.execute('SELECT state,count(*) FROM editions GROUP BY state'))}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--db',default=str(HERE/'universal_languages.sqlite'));s=p.add_subparsers(dest='cmd',required=True)
    s.add_parser('migrate');s.add_parser('stats')
    f=s.add_parser('blockers');f.add_argument('language',type=int)
    f=s.add_parser('find');f.add_argument('name')
    f=s.add_parser('series');f.add_argument('id');f.add_argument('title');f.add_argument('parts',type=int,choices=range(13,18))
    f=s.add_parser('work');f.add_argument('id');f.add_argument('series');f.add_argument('part',type=int);f.add_argument('title');f.add_argument('language',type=int);f.add_argument('file');f.add_argument('--rights',type=int,choices=[0,1],default=0);f.add_argument('--ready',type=int,choices=[0,1],default=0)
    f=s.add_parser('assess');f.add_argument('language',type=int);f.add_argument('criterion',choices=CRITERIA);f.add_argument('passed',type=int,choices=[0,1]);f.add_argument('--evidence',default='');f.add_argument('--assessor',default='')
    f=s.add_parser('enable');f.add_argument('language',type=int);f.add_argument('value',type=int,choices=[0,1])
    f=s.add_parser('plan');f.add_argument('work');f.add_argument('language',type=int)
    f=s.add_parser('advance');f.add_argument('edition');f.add_argument('state',choices=['source_ready','review','approved'])
    f=s.add_parser('draft');f.add_argument('edition');f.add_argument('file');f.add_argument('translator');f.add_argument('--sections',type=int,required=True);f.add_argument('--coverage')
    f=s.add_parser('review');f.add_argument('edition');f.add_argument('reviewer');f.add_argument('checks_json');f.add_argument('notes')
    f=s.add_parser('export');f.add_argument('file')
    a=p.parse_args();c=connect(a.db)
    try:
        with c:
            if a.cmd=='migrate': migrate(c);print(json.dumps(stats(c),indent=2))
            elif a.cmd=='blockers': print(json.dumps(blockers(c,a.language),indent=2))
            elif a.cmd=='stats': print(json.dumps(stats(c),indent=2))
            elif a.cmd=='find':
                print(json.dumps([dict(r) for r in c.execute('SELECT v.variety_id,v.preferred_name,p.category,p.target_enabled FROM varieties v JOIN language_profiles p USING(variety_id) WHERE v.preferred_name LIKE ? ORDER BY v.preferred_name LIMIT 100',('%'+a.name+'%',))],ensure_ascii=False,indent=2))
            elif a.cmd=='series': c.execute('INSERT INTO series VALUES(?,?,?)',(a.id,a.title,a.parts))
            elif a.cmd=='work':
                text=Path(a.file).read_text(encoding='utf-8')
                add_work(c,a.id,a.series,a.part,a.title,a.language,text,a.rights,a.ready)
                index_sections(c,a.id,text)
            elif a.cmd=='assess':
                if c.execute('UPDATE readiness SET passed=?,evidence_ref=?,assessor=?,assessed_on=CURRENT_TIMESTAMP WHERE variety_id=? AND criterion=?',(a.passed,a.evidence,a.assessor,a.language,a.criterion)).rowcount!=1: raise ValueError('readiness record not found')
            elif a.cmd=='enable':
                if c.execute('UPDATE language_profiles SET target_enabled=? WHERE variety_id=?',(a.value,a.language)).rowcount!=1: raise ValueError('language profile not found')
            elif a.cmd=='plan': print(plan(c,a.work,a.language))
            elif a.cmd=='advance': advance(c,a.edition,a.state)
            elif a.cmd=='draft': print(draft(c,a.edition,Path(a.file).read_text(encoding='utf-8'),a.translator,a.sections,json.loads(Path(a.coverage).read_text()) if a.coverage else None))
            elif a.cmd=='review': review(c,a.edition,a.reviewer,json.loads(Path(a.checks_json).read_text()),a.notes)
            elif a.cmd=='export':
                data={'stats':stats(c),'language_profiles':[dict(r) for r in c.execute('SELECT v.preferred_name,p.* FROM language_profiles p JOIN varieties v USING(variety_id)')],'editions':[dict(r) for r in c.execute('SELECT edition_id,work_id,variety_id,state,artifact_id FROM editions')]}
                Path(a.file).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    except (ValueError,sqlite3.Error,OSError) as e: p.exit(1,'Error: '+str(e)+'\n')
    finally: c.close()
if __name__=='__main__': main()
