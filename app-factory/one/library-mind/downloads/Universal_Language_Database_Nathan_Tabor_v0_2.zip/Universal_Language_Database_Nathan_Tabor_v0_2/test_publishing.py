import shutil,sqlite3,tempfile,unittest
from pathlib import Path
import publishing as p

class PublishingTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();path=Path(self.tmp.name)/'test.sqlite'
  shutil.copy2(p.HERE/'universal_languages.sqlite',path)
  self.c=p.connect(path);p.migrate(self.c)
  self.vid=self.c.execute("SELECT variety_id FROM identifiers WHERE scheme='ISO_639_3' AND identifier='eng'").fetchone()[0]
  self.c.execute("INSERT INTO series VALUES('TEST','Test only',13)")
  p.add_work(self.c,'W','TEST',1,'Test manuscript',self.vid,'# Chapter\nSource text.',1,1)
  p.index_sections(self.c,'W','# Chapter\nSource text.')
  self.eid=p.plan(self.c,'W',self.vid)
 def tearDown(self): self.c.close();self.tmp.cleanup()
 def enable(self):
  self.c.execute('UPDATE language_profiles SET target_enabled=1 WHERE variety_id=?',(self.vid,))
  self.c.execute("UPDATE readiness SET passed=1,evidence_ref='test fixture only',assessor='test assessor' WHERE variety_id=?",(self.vid,))
 def draft(self,text='# Chapter\nTranslated text.',coverage=True,translator='Translator'):
  self.enable();p.advance(self.c,self.eid,'source_ready')
  return p.draft(self.c,self.eid,text,translator,1,{'W:S1':'Translated text.'} if coverage else None)
 def test_math(self): self.assertEqual(2000*66666-33333333,99998667)
 def test_integer_anchors(self):
  self.assertEqual([r[0] for r in self.c.execute('SELECT value FROM binary_anchors ORDER BY value')],[0,1])
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute('UPDATE binary_anchors SET value=2 WHERE value=1')
 def test_fraction_rejected(self):
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute('UPDATE readiness SET passed=0.5 WHERE variety_id=?',(self.vid,))
 def test_readiness_requires_evidence(self):
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute('UPDATE readiness SET passed=1 WHERE variety_id=?',(self.vid,))
 def test_hold(self):
  with self.assertRaises(sqlite3.IntegrityError): p.advance(self.c,self.eid,'source_ready')
  self.assertIn('missing_grammar',p.blockers(self.c,self.vid)['reasons'])
 def test_idempotent_pair(self): self.assertEqual(p.plan(self.c,'W',self.vid),self.eid);self.assertEqual(self.c.execute('SELECT count(*) FROM editions').fetchone()[0],1)
 def test_invalid_jump(self):
  self.enable()
  with self.assertRaises(sqlite3.IntegrityError): p.advance(self.c,self.eid,'approved')
 def test_empty_draft(self):
  self.enable();p.advance(self.c,self.eid,'source_ready')
  with self.assertRaises(ValueError): p.draft(self.c,self.eid,' ','Translator',1)
 def test_unmapped_sections(self):
  self.draft(coverage=False)
  with self.assertRaises(sqlite3.IntegrityError): p.advance(self.c,self.eid,'review')
 def test_placeholder(self):
  self.draft('# Chapter\nTranslated text. TODO')
  with self.assertRaises(sqlite3.IntegrityError): p.advance(self.c,self.eid,'review')
 def test_bad_excerpt(self):
  self.enable();p.advance(self.c,self.eid,'source_ready')
  with self.assertRaises(sqlite3.IntegrityError): p.draft(self.c,self.eid,'# C\nActual.','Translator',1,{'W:S1':'Absent text'})
 def test_unresolved_terms(self):
  aid=self.draft()
  self.c.execute("INSERT INTO lexical_issues(artifact_id,source_term,proposal_kind) VALUES(?,'computer','unresolved')",(aid,))
  with self.assertRaises(sqlite3.IntegrityError): p.advance(self.c,self.eid,'review')
 def test_self_review(self):
  self.draft();p.advance(self.c,self.eid,'review')
  with self.assertRaises(sqlite3.IntegrityError): p.review(self.c,self.eid,'Translator',dict.fromkeys(p.REVIEW,1),'Test')
 def test_approve_and_revoke(self):
  self.draft();p.advance(self.c,self.eid,'review')
  with self.assertRaises(sqlite3.IntegrityError): p.advance(self.c,self.eid,'approved')
  p.review(self.c,self.eid,'Reviewer',dict.fromkeys(p.REVIEW,1),'Test review only')
  p.advance(self.c,self.eid,'approved')
  self.assertEqual(self.c.execute('SELECT count(*) FROM publishable_editions').fetchone()[0],1)
  self.c.execute("UPDATE readiness SET passed=0 WHERE variety_id=? AND criterion='grammar'",(self.vid,))
  self.assertEqual(self.c.execute('SELECT count(*) FROM publishable_editions').fetchone()[0],0)
 def test_revised_draft_needs_new_review(self):
  self.draft();p.advance(self.c,self.eid,'review')
  p.review(self.c,self.eid,'Reviewer',dict.fromkeys(p.REVIEW,1),'First artifact only')
  p.draft(self.c,self.eid,'# Chapter\nRevised.','Translator',1,{'W:S1':'Revised.'})
  p.advance(self.c,self.eid,'review')
  with self.assertRaises(sqlite3.IntegrityError): p.advance(self.c,self.eid,'approved')
 def test_immutable_artifact_and_audit(self):
  aid=self.draft()
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute("UPDATE artifacts SET text='changed' WHERE artifact_id=?",(aid,))
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute('DELETE FROM edition_events')
 def test_series_bounds(self):
  with self.assertRaises(sqlite3.IntegrityError): p.add_work(self.c,'W14','TEST',14,'Bad part',self.vid,'Text',1,1)
 def test_umbrella_never_active(self):
  vid=self.c.execute("SELECT variety_id FROM varieties WHERE preferred_name='Low Valyrian'").fetchone()[0]
  self.c.execute('UPDATE language_profiles SET target_enabled=1 WHERE variety_id=?',(vid,))
  self.c.execute("UPDATE readiness SET passed=1,evidence_ref='fixture',assessor='fixture' WHERE variety_id=?",(vid,))
  self.assertNotIn(vid,[r[0] for r in self.c.execute('SELECT variety_id FROM ready_languages')])
 def test_migration_idempotent(self):
  before=self.c.execute('SELECT count(*) FROM varieties').fetchone()[0];p.migrate(self.c)
  self.assertEqual(before,self.c.execute('SELECT count(*) FROM varieties').fetchone()[0])
 def test_fixed_capacity(self):
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute("UPDATE publishing_config SET value=70000 WHERE key='language_capacity'")
 def test_sections_freeze(self):
  self.draft()
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute("INSERT INTO source_sections VALUES('W:S2','W',2,'Late section')")
 def test_coinage_needs_evidence(self):
  with self.assertRaises(sqlite3.IntegrityError): self.c.execute("INSERT INTO term_proposals(variety_id,source_concept,proposed_form,method,grammar_basis,source_ref,proposer,approved) VALUES(?,'computer','candidate','new_coinage','','','A',1)",(self.vid,))
 def test_database_integrity(self):
  self.assertEqual(self.c.execute('PRAGMA integrity_check').fetchone()[0],'ok')
  self.assertEqual(self.c.execute('PRAGMA foreign_key_check').fetchall(),[])
if __name__=='__main__': unittest.main(verbosity=2)
