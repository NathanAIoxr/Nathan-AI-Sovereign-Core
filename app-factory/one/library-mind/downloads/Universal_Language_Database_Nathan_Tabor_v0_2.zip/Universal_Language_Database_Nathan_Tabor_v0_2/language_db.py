#!/usr/bin/env python3
"""The Universal Language Database v0.1. Python stdlib at runtime; pycountry only for initial ISO seed.

Author/project: The Library Mind of John Nathan Tabor.
Data provenance remains external to this software's authorship.
"""
import argparse
import csv
import hashlib
import io
import json
import sqlite3
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_DB = HERE / 'universal_languages.sqlite'


def connect(path):
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    return con


def init(con):
    con.executescript((HERE / 'schema.sql').read_text(encoding='utf-8'))
    con.commit()


def add_source(con, key, title, version=None, url=None, publisher=None, license=None, notes=None):
    con.execute('''INSERT OR IGNORE INTO sources
      (source_id,title,version,source_url,publisher,license,notes)
      VALUES(?,?,?,?,?,?,?)''', (key,title,version,url,publisher,license,notes))


def identifier_lookup(con, scheme, value):
    row = con.execute('SELECT variety_id FROM identifiers WHERE scheme=? AND identifier=?', (scheme,value)).fetchone()
    return row['variety_id'] if row else None


def refresh_search(con):
    con.execute('DELETE FROM variety_search')
    con.execute('''INSERT INTO variety_search(variety_id,name,kind)
      SELECT v.variety_id, v.preferred_name, v.kind FROM varieties v''')
    con.execute('''INSERT INTO variety_search(variety_id,name,kind)
      SELECT n.variety_id, n.name, v.kind FROM names n
      JOIN varieties v ON v.variety_id=n.variety_id
      WHERE n.name <> v.preferred_name''')
    con.commit()


def add_variety(con, name, kind, source_id, status='imported_unreviewed', summary=None, iso_scope=None, iso_type=None):
    cursor = con.execute('''INSERT INTO varieties
       (preferred_name,kind,initial_source_id,review_status,summary,iso_scope,iso_type)
       VALUES(?,?,?,?,?,?,?)''', (name,kind,source_id,status,summary,iso_scope,iso_type))
    vid = cursor.lastrowid
    con.execute('''INSERT OR IGNORE INTO names(variety_id,name,name_type,source_id)
       VALUES(?,?,?,?)''', (vid,name,'catalog_name',source_id))
    return vid


def seed_iso(con):
    try:
        import pycountry
    except ImportError as exc:
        raise SystemExit('Install pycountry to generate a fresh ISO seed: pip install pycountry') from exc
    key = 'pycountry-iso6393-24.6.1'
    add_source(con,key,'ISO 639-3 name/code snapshot distributed with pycountry',
       version=str(getattr(pycountry,'__version__','unknown')),
       url='https://github.com/pycountry/pycountry',
       publisher='pycountry / Debian pkg-isocodes / ISO 639-3',
       notes='Snapshot only. ISO type L is a catalog category, NOT verified current speaker vitality. '
             'Included scope M and S are not individual languages; no double-counting. '
             'No Glottolog, UNESCO, Ethnologue, or extinct-language count is implied.')
    types = {'L':'living','E':'extinct','A':'ancient','H':'historical','C':'constructed','S':'special'}
    scopes = {'I':'language','M':'macrolanguage','S':'special'}
    added = matched = 0
    for lang in pycountry.languages:
        code = getattr(lang,'alpha_3',None)
        if not code: continue
        exist = identifier_lookup(con,'ISO_639_3',code)
        if exist:
            matched += 1
            continue
        kind = scopes.get(getattr(lang,'scope','I'),'unclassified')
        vid = add_variety(con,lang.name,kind,key,iso_scope=getattr(lang,'scope',None),iso_type=getattr(lang,'type',None))
        for scheme,code_value in [('ISO_639_3',code),('ISO_639_1',getattr(lang,'alpha_2',None)),('ISO_639_2_B',getattr(lang,'bibliographic',None))]:
            if code_value:
                con.execute('INSERT OR IGNORE INTO identifiers(variety_id,scheme,identifier,source_id) VALUES(?,?,?,?)', (vid,scheme,code_value,key))
        alt = getattr(lang,'inverted_name',None)
        if alt and alt != lang.name:
            con.execute('INSERT OR IGNORE INTO names(variety_id,name,name_type,source_id) VALUES(?,?,?,?)',(vid,alt,'alternate',key))
        added += 1
    con.execute('INSERT INTO import_batches (source_id,original_filename,rows_read,added,matched,notes) VALUES(?,?,?,?,?,?)',
                (key,'pycountry ISO 639-3 snapshot',added+matched,added,matched,'Type key '+str(types)))
    refresh_search(con)
    con.commit()
    print(f'ISO snapshot: added {added:,}; already present {matched:,}.')


def get_csv_bytes(file_path):
    raw = Path(file_path).read_bytes()
    if zipfile.is_zipfile(io.BytesIO(raw)):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            names = [n for n in z.namelist() if n.lower().endswith('.csv') and not n.startswith('__MACOSX')]
            if not names: raise ValueError('ZIP archive has no CSV')
            return z.read(names[0]), hashlib.sha256(raw).hexdigest()
    return raw, hashlib.sha256(raw).hexdigest()


def pick(r, *keys):
    low = {str(k).lower(): str(v).strip() if v is not None else '' for k,v in r.items() if k}
    for key in keys:
        val = low.get(key.lower())
        if val: return val
    return None


def import_glottolog(con, file_path, version='5.3'):
    """Import standard Glottolog languoid CSV or its CSV ZIP; match by ISO, else create.

    The importer intentionally DOES NOT overwrite ISO names or claim vitality.
    Unmatched/differently classified entries remain independent reviewable varieties.
    """
    key = 'glottolog-'+version
    add_source(con,key,'Glottolog languoids CSV',version,'https://glottolog.org/download',
               'Glottolog editors','CC BY 4.0','Glottolog editorial classification; attribution required.')
    raw, digest = get_csv_bytes(file_path)
    rows = list(csv.DictReader(io.StringIO(raw.decode('utf-8-sig'))))
    if not rows: raise ValueError('No rows')
    if not any(k.lower() in ('id','glottocode') for k in rows[0]):
        raise ValueError('Expected Glottolog field id or glottocode; got '+str(list(rows[0])[:12]))
    seen = {}
    added = matched = 0
    for r in rows:
        code = pick(r,'id','glottocode')
        name = pick(r,'name')
        if not code or not name: continue
        iso = pick(r,'iso639p3code','iso639-3','iso639_3','iso639p3')
        vid = identifier_lookup(con,'GLOTTOCODE',code)
        if not vid and iso:
            vid = identifier_lookup(con,'ISO_639_3',iso)
        if vid:
            matched += 1
            con.execute('INSERT OR IGNORE INTO identifiers(variety_id,scheme,identifier,source_id) VALUES(?,?,?,?)',
                        (vid,'GLOTTOCODE',code,key))
            con.execute('INSERT OR IGNORE INTO names(variety_id,name,name_type,source_id) VALUES(?,?,?,?)',
                        (vid,name,'alternate',key))
        else:
            level = (pick(r,'level') or 'language').lower()
            kind = {'family':'family','language':'language','dialect':'dialect'}.get(level,'unclassified')
            vid = add_variety(con,name,kind,key)
            con.execute('INSERT OR IGNORE INTO identifiers(variety_id,scheme,identifier,source_id) VALUES(?,?,?,?)',
                        (vid,'GLOTTOCODE',code,key))
            if iso: # preserve ISO only if not already owned by another variety
                con.execute('INSERT OR IGNORE INTO identifiers(variety_id,scheme,identifier,source_id) VALUES(?,?,?,?)',
                            (vid,'ISO_639_3',iso,key))
            added += 1
        seen[code]=(vid,pick(r,'parent_id','parent','parentcode'))
    for code,(vid,parent_code) in seen.items():
        if parent_code:
            parent_id = seen.get(parent_code,(identifier_lookup(con,'GLOTTOCODE',parent_code),None))[0]
            if parent_id and parent_id != vid:
                con.execute('''INSERT OR IGNORE INTO relations(subject_id,object_id,relation_type,source_id,note)
                   VALUES(?,?,?,?,?)''',(vid,parent_id,'subgroup_of',key,'Glottolog parent-child taxonomy, not a claim of legal status'))
    con.execute('''INSERT INTO import_batches(source_id,original_filename,sha256,rows_read,added,matched,notes)
        VALUES(?,?,?,?,?,?,?)''',(key,str(Path(file_path).name),digest,len(rows),added,matched,'No overwrites of initial source data'))
    refresh_search(con)
    print(f'Glottolog CSV read {len(rows):,} rows; added {added:,}; matched {matched:,}.')


def cmd_search(con, term, limit):
    q = '%'+term+'%'
    rows = con.execute('''SELECT DISTINCT v.variety_id,v.preferred_name,v.kind,v.iso_type,
     (SELECT identifier FROM identifiers WHERE variety_id=v.variety_id AND scheme='ISO_639_3' LIMIT 1) iso,
     (SELECT identifier FROM identifiers WHERE variety_id=v.variety_id AND scheme='GLOTTOCODE' LIMIT 1) glottocode
     FROM varieties v LEFT JOIN names n ON n.variety_id=v.variety_id
     LEFT JOIN identifiers i ON i.variety_id=v.variety_id
     WHERE v.preferred_name LIKE ? OR n.name LIKE ? OR i.identifier = ?
     ORDER BY v.preferred_name LIMIT ?''',(q,q,term,limit)).fetchall()
    for r in rows:
        print(f"{r['preferred_name'][:45]:45} {r['kind']:15} {r['iso_type'] or '-':2} {r['iso'] or '-':5} {r['glottocode'] or '-'}")
    print(f'{len(rows)} shown (max {limit})')


def cmd_stats(con):
    print('TOTAL VARIETY RECORDS:',con.execute('SELECT COUNT(*) FROM varieties').fetchone()[0])
    for row in con.execute('SELECT kind, COUNT(*) n FROM varieties GROUP BY kind ORDER BY n DESC'):print('  kind:',row['kind'],row['n'])
    for row in con.execute('SELECT iso_type, COUNT(*) n FROM varieties GROUP BY iso_type ORDER BY n DESC'):print('  ISO type:',row['iso_type'],row['n'])
    print('IDENTIFIERS:',con.execute('SELECT COUNT(*) FROM identifiers').fetchone()[0])
    print('NOT VERIFIED SPEAKERS:',con.execute('SELECT COUNT(*) FROM varieties WHERE vitality IS NULL').fetchone()[0])
    print('IMPORTS:',con.execute('SELECT COUNT(*) FROM import_batches').fetchone()[0])


def cmd_add(con,args):
    key = args.source_key or 'community-submissions'
    add_source(con,key,args.source_title or 'Contributor-submitted record',url=args.source_url,
               notes='Do not mistake community submissions for ISO certification.')
    vid = add_variety(con,args.name,args.kind,key,'community_reported',summary=args.note)
    con.execute('INSERT INTO identifiers(variety_id,scheme,identifier,source_id) VALUES(?,?,?,?)',
                (vid,'INTERNAL',f'NT-ULDB-{vid:08d}',key))
    refresh_search(con)
    print(f'Added reviewable record NT-ULDB-{vid:08d}: {args.name} ({args.kind}).')


def main():
    p = argparse.ArgumentParser(description='Universal Language Database v0.1')
    p.add_argument('--db',default=str(DEFAULT_DB),help='SQLite database path')
    sub = p.add_subparsers(dest='action',required=True)
    sub.add_parser('init');sub.add_parser('seed-iso');sub.add_parser('stats')
    s=sub.add_parser('search');s.add_argument('query');s.add_argument('--limit',type=int,default=30)
    s=sub.add_parser('import-glottolog');s.add_argument('filename');s.add_argument('--version',default='5.3')
    s=sub.add_parser('add-variety');s.add_argument('name');s.add_argument('--kind',choices=['language','dialect','family','register','communication_system','unclassified'],default='language');s.add_argument('--note');s.add_argument('--source-key');s.add_argument('--source-title');s.add_argument('--source-url')
    args=p.parse_args()
    con=connect(args.db); init(con)
    if args.action=='seed-iso':seed_iso(con)
    elif args.action=='stats':cmd_stats(con)
    elif args.action=='search':cmd_search(con,args.query,args.limit)
    elif args.action=='import-glottolog':import_glottolog(con,args.filename,args.version)
    elif args.action=='add-variety':cmd_add(con,args)
    elif args.action=='init': print(f'Schema created at {args.db}')
    con.close()

if __name__=='__main__':main()
