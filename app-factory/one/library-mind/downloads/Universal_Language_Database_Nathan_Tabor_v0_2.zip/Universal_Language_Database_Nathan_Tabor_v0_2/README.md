# The Library Mind of John Nathan Tabor — Universal Language Database v0.2

ONE MIND. ONE MASTER LIBRARY. ONE CONNECTED SYSTEM.

Built October 30, 2026. D17 Languages and Translation, connected by stable work/variety IDs to ONE / WORDS / Nathan AI and the master publishing catalog.

## This release connects to what was built

The current saved v0.1 SQLite database and language CLI were downloaded and copied into this release. Existing source, identifier, name, claim, evidence, lexeme, interpretation and library-link tables are preserved. New publishing tables extend that same database. The original standalone saved files remain unchanged; this is a new versioned package.

Included: **7,918 catalog profiles**, including the **7,910 existing code records** and eight new requested research/constructed-language entries. Quenya and Sindarin reuse existing records. Profiles include grouping and special records; 7,918 is not a count of living languages. Imported code categories do not establish current vitality, grammatical completeness, legal recognition or production readiness.

The package includes an offline search browser, the existing catalog CLI, a new publishing CLI, SQL migration, hold report for every profile, lexical proposal template, and automated tests. All daily functions use Python 3 and SQLite from the standard library. No server or paid service is required for the registry.

## Whole binary foundation

`binary_anchors` contains exactly the immutable integers **0** and **1**. Every binary requirement references those anchors. There are no fractional readiness scores.

| Layer | Representation |
|---|---|
| Under the system | 0 = requirement not established; 1 = requirement established with recorded evidence |
| On the foundation | Immutable source manuscripts and source sections; unique book × language edition identities |
| Around the foundation | Fixed 66,666 profile capacity; provenance, seven readiness checks, review gates and audit records |
| Production workflow | Named stages: planned, source_ready, draft, review, approved |

A draft is a complete stored artifact at a named stage. It can contain unresolved work without becoming a fractional number. `target_enabled=1` alone does not mean validated: **active eligibility is computed from all requirements**. A zero check does not mean the language lacks grammar or is inherently impossible; it means that requirement has not been established for this project. Unknown, dormant, extinct, constructed, unsupported and disabled are different metadata states.

The capacity counts catalog profiles, including archival profiles; the system does not manufacture 66,666 alleged language discoveries or blank edition files.

## Four connected tiers

| Tier | Tables | Responsibility |
|---|---|---|
| Original works | series, works, source_sections | 13–17-part series; one immutable UTF-8 source manuscript per source-version Work ID; source hash and rights/readiness assertions |
| Universal language registry | existing varieties and provenance tables; language_profiles, readiness, readiness_events, term_proposals | Language identity, scripts, evidence, terminology proposals, explicit holds and eligibility |
| Language editions | editions, artifacts, section_coverage, lexical_issues | Unique Work ID × Variety ID; immutable draft artifacts and artifact-specific section mappings |
| Production status | artifact_checks, reviews, edition_events; publishable_editions view | Structural checks, independent language review, approved state and current publication eligibility |

Edition IDs use SHA-256 over a canonical JSON book/variety pair, with a database unique pair constraint as the authoritative duplicate guard. Plan calls are idempotent. Artifact revisions remain under the same pair; source manuscript revisions use a new Work ID. A completed approved pair is immutable in this prototype; a future revision workflow must retain the original approval history.

## What is on hold, and what releases it?

The complete per-profile report is `language_hold_report.csv`. Run `python publishing.py blockers VARIETY_ID` for live details. Every seeded profile currently starts with unverified readiness checks: none has been marked production-ready based on a name, an ISO code, a copied passage or a fictional-language popularity claim.

| Hold | Meaning | Release condition |
|---|---|---|
| missing_identity | Target variety not assessed | Document the specific variety, source, period and domain |
| missing_grammar | Required constructions not assessed | Document usable grammar and unresolved domain constraints |
| missing_lexicon | Book-domain vocabulary not established | Approve terminology, paraphrases or labeled coinages with evidence |
| missing_orthography | Script/export contract not tested | Test Unicode, directionality, fonts and the actual output format |
| missing_evidence | Resource provenance not reviewed | Record accessible supporting resources and provenance |
| missing_rights | Reuse/publication clearance pending | Document applicable source/material permissions |
| missing_reviewer | Language review capability not established | Identify a qualified reviewer for the specific target/domain |
| target_disabled | Target deliberately disabled | Enable only after the assessment decision |
| category_requires_assessment_or_specific_variety | Unknown/undeciphered/grouping/research entry | Supply evidence and a specific supported target profile |
| not_an_individual_translation_target | Family, umbrella or special code | Link a specific language, dialect or register |
| unmapped source section | Some original material has no target link | Map every stable source section to actual target text |
| unresolved lexical issue | A recorded term problem remains open | Resolve with reviewer and evidence; no silent invention |
| failed structural check | Empty text, placeholder marker or section-contract failure | Create a corrected draft artifact |
| missing/failed language review | Fidelity or other review checks missing | Independent reviewer evaluates the exact artifact |

These holds are not declarations that all languages in a category are impossible. No unsupported “25,000 lost languages” records were generated. A wholly unattested language cannot currently receive a faithful translation; it may remain a clearly labeled research entry. A family or unidentified grouping is not silently treated as a known individual language.

## Requested fictional and historical map

| Target | Variety ID in this release | Handling |
|---|---:|---|
| High Valyrian | 7911 | Constructed language; independent resource, vocabulary, script and reviewer assessment |
| Low Valyrian | 7912 | Umbrella only; cannot become an active edition target |
| Astapori Valyrian | 7913 | Separate constructed target; proposed fictional descent link to High Valyrian |
| Meereenese Valyrian | 7914 | Separate constructed target; proposed fictional descent link to High Valyrian |
| Dothraki | 7915 | Constructed target; assess actual resources without declaring it a mere sketch |
| Na’vi | 7916 | Separate constructed target; original Unicode spelling retained |
| Quenya | 5520 | Existing snapshot record reused; label attested vs community-created forms |
| Sindarin | 5877 | Existing snapshot record reused; label attested vs community-created forms |
| Klingon | 6428 | Existing `tlh` snapshot entry; code does not itself establish readiness |
| Esperanto | 1843 | Existing `epo` snapshot entry; domain-specific readiness still assessed |
| Latin | 3490 | Historical profile; not placed in a low-readiness tier simply because historical |
| Ancient Greek | 2222 | Historical profile; usable period/register must be specified |
| Sanskrit | 5696 | Historical snapshot category; current usage not inferred from that label |
| Etruscan | 1875 | Existing historical snapshot record; full-book feasibility needs specialist assessment |
| Minoan (Linear A language, provisional) | 7917 | Undeciphered research entry; script and language identity distinguished |
| Unidentified lost language — research category | 7918 | Research category only; not a newly discovered language |

Valyrian links are explicitly marked pending source review. No ISO code has been invented for High Valyrian, Astapori, Meereenese, Dothraki or Na’vi. “Low” is not a linguistic quality judgment. Named Free Cities varieties can be registered individually after their identity and resources are documented; no invented list has been inserted.

Live web retrieval failed during this build. New language-specific claims are therefore stored as user-directed mappings pending primary-source review. Existing code provenance remains the v0.1 historical snapshot. Useful primary-source starting points (not retrieved/verified in this release): https://iso639-3.sil.org/code_tables/download_tables and creator David J. Peterson’s https://dedalvs.com/ . No word counts or completeness percentages have been certified.

## Seven language readiness checks

`identity`, `grammar`, `lexicon`, `orthography`, `evidence`, `rights`, `reviewer` must each be 1, with an assessor and evidence reference. Then `target_enabled` must be 1 and the profile must be a specific eligible language/dialect/register. Profiles in unknown, undeciphered, umbrella or research categories remain inactive.

Grammar readiness means adequate documented grammar for the intended work and register. It does not assert a “100% complete grammar matrix,” which has no implemented objective universal test. An algorithm proposing an unfamiliar word does not establish its validity.

Lexical proposals use `term_proposals` and `lexicon_expansion_template.json`: source concept, proposed form, method, grammatical basis, source, proposer, independent reviewer and review note. New coinages remain labeled new coinages. Reconstructed forms remain reconstructed. Proposal approval does not automatically mark an entire language ready.

## Edition gates

1. **planned → source_ready:** immutable registered manuscript; source_ready=1 and rights_cleared=1; target passes all language checks.
2. **source_ready → draft:** nonempty target text stored with translator identity and SHA-256. Structural check report is attached to that exact artifact.
3. **draft → review:** placeholder scan passes; explicit target Markdown section contract passes; all source sections map to real target excerpts; no recorded lexical issue remains unresolved; target still eligible.
4. **review → approved:** independent reviewer, different from the translator identity, records 1 for fidelity, terminology, grammar, script and completeness for that artifact.
5. **review → draft:** a replacement artifact resets review. Prior approval checks do not transfer to revised text.

Sentence and paragraph counts need not match across languages. Section coverage checks trace source content without imposing English syntax. Automated coverage cannot prove semantic fidelity: two source sections may map into one target passage, but the reviewer must assess whether it actually conveys both. A target section-count contract is explicit; it is not automatically copied from the source.

Unicode text is preserved; the CLI validates UTF-8 decoding. Font shaping, pIqaD/Tengwar glyph rendering, PDF pagination, signed-language video quality and audio pronunciation are not validated by a plain-text scan. These require separate format-specific renderers and evidence under the orthography check. The system does not claim that transliteration and native script are interchangeable.

`publishable_editions` rechecks present language readiness. Revoking a check makes an already-approved record ineligible for publication without deleting its historical review.

## Run and connect

Open `language_browser.html` for the catalog. The browser is a generated read-only snapshot, not a live publishing editor. Run `python build_viewer.py` after catalog changes.

```bash
python publishing.py stats
python publishing.py find Valyrian
python publishing.py blockers 7911
python -m unittest test_publishing -v
```

Register a real manuscript (example commands, no sample manuscript is included or counted):

```bash
python publishing.py series SERIES001 'Actual series title' 13
python publishing.py work WORK001 SERIES001 1 'Actual title' 3490 manuscript.md --rights 1 --ready 1
```

Look up the correct source language ID with `find` first; 3490 is the existing Latin profile and is only a command example. Source readiness and rights flags are deliberate operator attestations. The software cannot infer that a text is a complete manuscript.

Assess each of the seven criteria separately, with actual evidence. For example:

```bash
python publishing.py assess 7911 grammar 1 --evidence 'Specific reviewed grammar reference and scope' --assessor 'Reviewer identity'
python publishing.py enable 7911 1
python publishing.py plan WORK001 7911
```

The last command prints an edition ID. Use that ID for subsequent commands. Planning is allowed while a target is on hold; production advancement remains blocked.

```bash
python publishing.py advance EDITION_ID source_ready
python publishing.py draft EDITION_ID translated.md TRANSLATOR_ID --sections 1 --coverage coverage.json
python publishing.py advance EDITION_ID review
python publishing.py review EDITION_ID REVIEWER_ID checks.json 'Review rationale and evidence'
python publishing.py advance EDITION_ID approved
python publishing.py export publishing_export.json
```

`coverage.json` maps every source-section ID (e.g. `WORK001:S1`) to an exact excerpt in the target text. `checks.json` contains `fidelity`, `terminology`, `grammar`, `script`, `completeness`, each integer 0 or 1. A positive review must be an actual qualified review; separate strings alone do not authenticate a person. Lexical issues and term proposals can be managed through their SQL tables; this release does not include a UI for those tables.

Existing v0.1 files can receive the additive migration with `python publishing.py --db /path/to/existing/universal_languages.sqlite migrate`. Back up the destination first. Use this release’s `publishing.py` and `publishing_schema.sql` together. The supplied database is already migrated. API callers must enable foreign keys and wrap each mutation in a transaction, as the CLI does.

## Counts and limits

- Reported originals: 2,000+ from Nathan Tabor. No manuscript files have been supplied/imported into this release, so **registered manuscripts = 0**.
- Configured catalog ceiling: **66,666**. Occupied profiles: **7,918**. Ready profiles: **0** pending evidence.
- Projection at the reported floor: **2,000 × 66,666 = 133,332,000 editions**.
- Amount above 33,333,333: **99,998,667**.
- Actual edition records and approved editions in the supplied database: **0**.

The cross-product remains a projection. The software creates real pair records on demand and does not allocate 133 million empty files or rows. It is not a translation model, job worker service or distributed scheduler. No translation provider, external app account, GitHub repository or running ONE deployment has been connected during this task. Stable IDs, JSON exports and the shared SQLite tables provide the integration boundary.

This release has not been benchmarked at 133 million rows. A production service at that scale needs a separately tested database deployment, bounded batches, workers with leases/retries, authentication, reviewer roles, durable backups and format-specific publication checks. Registry tests are evidence of the implemented constraints, not a promise of universal translation perfection or legal certification.

## Provenance and validation

Existing v0.1 provenance is retained in `README_v0_1.md` and the source tables. The existing catalog was not reclassified as independently verified. New tests run on disposable database copies; no test manuscripts or approvals remain in the deliverable database. See `test_results.txt`, `publishing_stats.json` and `language_hold_report.csv`.
