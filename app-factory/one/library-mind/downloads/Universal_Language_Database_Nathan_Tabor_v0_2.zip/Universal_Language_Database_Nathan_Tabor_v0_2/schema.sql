PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS sources (
  source_id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  version TEXT,
  source_url TEXT,
  publisher TEXT,
  license TEXT,
  accessed_on TEXT,
  notes TEXT
);

CREATE TABLE IF NOT EXISTS varieties (
  variety_id INTEGER PRIMARY KEY,
  preferred_name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('language','dialect','macrolanguage','family','register','communication_system','unclassified','special')),
  iso_scope TEXT,
  iso_type TEXT,
  modality TEXT,
  vitality TEXT,
  review_status TEXT NOT NULL DEFAULT 'imported_unreviewed'
    CHECK (review_status IN ('imported_unreviewed','community_reported','source_reviewed','expert_reviewed','disputed')),
  summary TEXT,
  initial_source_id TEXT REFERENCES sources(source_id),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS identifiers (
  identifier_id INTEGER PRIMARY KEY,
  variety_id INTEGER NOT NULL REFERENCES varieties(variety_id) ON DELETE CASCADE,
  scheme TEXT NOT NULL, -- ISO_639_3, GLOTTOCODE, COMMUNITY, INTERNAL, etc.
  identifier TEXT NOT NULL,
  source_id TEXT REFERENCES sources(source_id),
  UNIQUE (scheme, identifier)
);
CREATE INDEX IF NOT EXISTS idx_identifiers_variety ON identifiers(variety_id);

CREATE TABLE IF NOT EXISTS names (
  name_id INTEGER PRIMARY KEY,
  variety_id INTEGER NOT NULL REFERENCES varieties(variety_id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  language_of_name TEXT,
  script_code TEXT,
  name_type TEXT NOT NULL DEFAULT 'catalog_name'
    CHECK (name_type IN ('catalog_name','endonym','exonym','alternate','historical','transliteration','community_preferred')),
  source_id TEXT REFERENCES sources(source_id),
  UNIQUE(variety_id, name, name_type, source_id)
);
CREATE INDEX IF NOT EXISTS idx_names_variety ON names(variety_id);
CREATE INDEX IF NOT EXISTS idx_names_text ON names(name);

CREATE TABLE IF NOT EXISTS relations (
  relation_id INTEGER PRIMARY KEY,
  subject_id INTEGER NOT NULL REFERENCES varieties(variety_id),
  object_id INTEGER NOT NULL REFERENCES varieties(variety_id),
  relation_type TEXT NOT NULL, -- dialect_of, subgroup_of, descends_from, contact_with, etc.
  claim_status TEXT NOT NULL DEFAULT 'source_claim',
  source_id TEXT REFERENCES sources(source_id),
  note TEXT,
  CHECK (subject_id <> object_id),
  UNIQUE (subject_id, object_id, relation_type, source_id)
);

CREATE TABLE IF NOT EXISTS claims (
  claim_id INTEGER PRIMARY KEY,
  variety_id INTEGER NOT NULL REFERENCES varieties(variety_id),
  subject_field TEXT NOT NULL, -- legal_recognition, speakers, region, vitality, community_position, ...
  claim_value TEXT NOT NULL,
  geographic_scope TEXT,
  as_of_date TEXT,
  evidence_grade TEXT NOT NULL DEFAULT 'unreviewed'
    CHECK (evidence_grade IN ('direct_source','peer_reviewed','community_attested','scholarly_hypothesis','author_hypothesis','unreviewed','disputed')),
  source_id TEXT REFERENCES sources(source_id),
  note TEXT
);
CREATE INDEX IF NOT EXISTS idx_claims_variety_field ON claims(variety_id, subject_field);

CREATE TABLE IF NOT EXISTS evidence (
  evidence_id INTEGER PRIMARY KEY,
  variety_id INTEGER NOT NULL REFERENCES varieties(variety_id),
  evidence_type TEXT NOT NULL, -- inscription, text, audio, grammar, manuscript, oral account, wordlist, etc.
  title TEXT NOT NULL,
  date_range TEXT,
  source_id TEXT REFERENCES sources(source_id),
  url_or_archive TEXT,
  access_status TEXT NOT NULL DEFAULT 'metadata_only',
  permission_note TEXT,
  reliability TEXT NOT NULL DEFAULT 'not_assessed'
);

CREATE TABLE IF NOT EXISTS concepts (
  concept_id INTEGER PRIMARY KEY,
  concept_key TEXT NOT NULL UNIQUE,
  english_gloss TEXT NOT NULL,
  description TEXT
);

CREATE TABLE IF NOT EXISTS lexemes (
  lexeme_id INTEGER PRIMARY KEY,
  variety_id INTEGER NOT NULL REFERENCES varieties(variety_id),
  original_form TEXT NOT NULL, -- preserve Unicode, don't reverse RTL or force romanization
  ipa TEXT,
  script_code TEXT,
  text_direction TEXT CHECK (text_direction IN ('ltr','rtl','ttb','auto') OR text_direction IS NULL),
  part_of_speech TEXT,
  concept_id INTEGER REFERENCES concepts(concept_id),
  attestation_status TEXT NOT NULL DEFAULT 'unverified'
    CHECK (attestation_status IN ('attested','reconstructed','proposed','unverified')),
  source_id TEXT REFERENCES sources(source_id),
  access_status TEXT NOT NULL DEFAULT 'metadata_only',
  note TEXT
);
CREATE INDEX IF NOT EXISTS idx_lexemes_variety ON lexemes(variety_id);

CREATE TABLE IF NOT EXISTS word_interpretations (
  interpretation_id INTEGER PRIMARY KEY,
  lexeme_id INTEGER NOT NULL REFERENCES lexemes(lexeme_id),
  reading_type TEXT NOT NULL CHECK (reading_type IN ('dictionary_definition','historical_etymology','proposed_etymology','acrostic','reversal','symbolic_interpretation','translation','other')),
  proposed_text TEXT NOT NULL,
  evidence_grade TEXT NOT NULL DEFAULT 'unreviewed',
  source_id TEXT REFERENCES sources(source_id),
  notes TEXT
);

CREATE TABLE IF NOT EXISTS communication_modes (
  mode_id INTEGER PRIMARY KEY,
  variety_id INTEGER NOT NULL REFERENCES varieties(variety_id),
  mode TEXT NOT NULL, -- spoken, signed, tactile, written, whistled, drummed, ...
  source_id TEXT REFERENCES sources(source_id),
  notes TEXT,
  UNIQUE(variety_id,mode,source_id)
);

CREATE TABLE IF NOT EXISTS library_links (
  library_link_id INTEGER PRIMARY KEY,
  variety_id INTEGER NOT NULL REFERENCES varieties(variety_id),
  work_id TEXT,
  title TEXT NOT NULL,
  relation_type TEXT NOT NULL DEFAULT 'research_reference',
  note TEXT
);

CREATE TABLE IF NOT EXISTS import_batches (
  import_id INTEGER PRIMARY KEY,
  source_id TEXT REFERENCES sources(source_id),
  original_filename TEXT,
  sha256 TEXT,
  imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  rows_read INTEGER,
  added INTEGER,
  matched INTEGER,
  notes TEXT
);

-- Avoid silent merges of disputed records. Identifier collisions require human review.
CREATE VIRTUAL TABLE IF NOT EXISTS variety_search USING fts5(variety_id UNINDEXED, name, kind, tokenize='unicode61 remove_diacritics 2');
