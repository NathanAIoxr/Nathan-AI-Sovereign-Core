# The Universal Language Database — v0.1
**Part of THE LIBRARY MIND OF JOHN NATHAN TABOR · ONE / WORDS · Department D17 (Languages and Translation)**

**Build date:** 2026-10-30. **State:** functional, offline-first research prototype. This does **not** imply a complete universal catalog, a validated count of lost languages, or completed reconstruction of any undocumented language.

## What is actually included
- **7,910 ISO 639-3 code records**, populated from the *installed pycountry 24.6.1* database (which wraps Debian `pkg-isocodes`).
- Of these code records, **7,844 are individual entries**, **62 macrolanguage groupings**, **4 special codes**.
- ISO **type labels**: **7,063 L**, **608 E**, **124 A**, **88 H**, **23 C**, **4 S**. In the L category, **7,001** records have individual scope (I). The type labels are from a historical code snapshot; **they do not confirm that 7,001 languages still have living speakers today**.
- Source registry, language/variety identifiers, names, taxonomy relations, evidence records, claims (including legal recognition), lexical forms, word interpretations, concepts, communication modes, and links to the Master Library.
- A complete offline HTML search/filter/export page and a CLI to search and add records.

## Files
- `universal_languages.sqlite`: browsable database containing the actual imported ISO code inventory.
- `language_browser.html`: open in a browser, works offline, no account or server needed. Shows searchable names and codes, NOT invented speaker counts.
- `language_db.py`: init, search, statistics, add-variety, and import of official Glottolog CSV/ZIP files.
- `build_viewer.py`: regenerate the self-contained HTML browser after updating the SQLite database.
- `schema.sql`: schema for SQL/PostgreSQL adaptation.
- `catalog_export.json`: portable JSON records for ONE, WORDS and other clients.

## Run
Python 3.9+ and SQLite (Python stdlib) for daily work. `pycountry` is only required when creating the initial ISO seed from scratch.

```bash
python language_db.py stats
python language_db.py search Akkadian
python language_db.py search 'Sign Language'
python language_db.py add-variety 'Community Name' --kind language \
  --source-title 'Community-provided documentation' \
  --note 'Pending community review and independent documentation'
python build_viewer.py
```

To create the DB afresh (optional):
```bash
python language_db.py --db fresh.sqlite init
pip install pycountry
python language_db.py --db fresh.sqlite seed-iso
```

## Next: Glottolog 5.3 data
**Not downloaded into v0.1.** The download host was unavailable to this execution environment. Get `glottolog_languoid.csv.zip` from [the official Glottolog download page](https://glottolog.org/download). It is **CC BY 4.0**, credit Glottolog 5.3 editors Hammarström, Forkel, Haspelmath & Bank and the relevant data/version. Then import:
```bash
python language_db.py import-glottolog glottolog_languoid.csv.zip --version 5.3
python language_db.py stats
python build_viewer.py
```
The importer attempts to merge by ISO code and attach Glottocodes, and creates separate entries for unmatched dialects/families; it does not overwrite original ISO names or guess vitality. **Review conflicts and classifications before treating either source as decisive.**

## Subsequent authoritative source streams
1. UNESCO World Atlas of Languages: ~8,324 documented spoken/signed; ~7,000 still used; ~1,400 legally recognized — **different scopes than this ISO snapshot**. https://www.unesco.org/en/multilingualism-linguistic-diversity
2. Glottolog 5.3 (languages, dialects, families, sign etc): https://glottolog.org/download — CC BY 4.0.
3. ISO 639-3 official code tables for up-to-date codes: https://iso639-3.sil.org/code_tables/download_tables — review reuse terms and changes before refresh.
4. Endangered Languages Project / ELCat for community vitality and dormant languages: https://endangeredlanguages.com/about-catalogue — verify download-specific reuse terms and community permissions.
5. PHOIBLE for attested phoneme inventories and IPA: https://phoible.org — CC BY-SA 3.0, may impose share-alike obligations on data derivatives.
6. CLDF standard for external linguistic dataset exchange: https://cldf.clld.org/

## Strict conceptual distinctions
- A **language** can lack official/legal recognition and still be a legitimate language. Legal recognition must be a sourced claim, not inferred from existence/absence of a code.
- An ISO code is an identifier, not itself a complete description. **An ISO L (living type) code does not prove present-day vitality.**
- "Unwritten" does not mean "unrecognized"; "undocumented" does not mean "extinct"; "extinct" does not necessarily mean "unrecoverable"; **dormant** is often the community-preferred term for a sleeping language being revitalized.
- User's **25,000 lost-language estimate is a research target only**. No authoritative global historical inventory supporting it has been established. Avoid inventing 25,000 titles or extrapolating numeric slots into linguistic discoveries.
- Ancient inscriptions, fully attested historical languages, comparative reconstructions, putative and unattested languages, and fictional/constructed languages must be separate statuses.
- Voice, sign, whistling, drumming, writing and tactile encodings are **modalities**, not necessarily different languages. Animal communication and experimental universal mammal languages must stay in a separate scientific/creative research category, not assigned human ISO entries.
- Source-attested text, lexical definitions, reconstructed forms, phonetic reversals, and author interpretations live in distinct tables. No automatic claim that an acrostic or reversal is a historical etymology.
- Preserve original Unicode script and text direction (RTL/LTR); never transliterate/reverse silently. Reconstructed forms labeled as such.
- Community-contributed material, Indigenous cultural property, sacred materials, personal recordings, and unpublished text require rights/consent review before public release.
- The `claims` table supports legal recognition and speaker claims by geography and date; none were populated without evidence.

## Master Library crosswalk
- **Department D17**: Languages and translation; one primary classification for linguistic works.
- Secondary research links: D16 Ancient records, D18 Biblical text, D22 Tabor Secret Society, D27 Children's stories, D28 ONE/Nathan AI, D31 Words and Tongues.
- A language record is **not** a completed book. Every book gets a separate Work ID and an evidence-based bibliography.
- Author's arithmetic anchors `1+1=2` (build/link without duplicate counting) and `1−1=0` (clear a disproven assumption) are editorial workflow labels, not mathematical proof of etymologies or language relationships. Originals remain recoverable; "clear" never means destroying source records.

## Provenance
- Original framework, scope and integration are user-directed: Nathan Tabor.
- Original ISO 639 language identifiers/names are standards reference data from ISO 639-3 via the *pycountry* project and Debian's `pkg-isocodes`; they are **not** authored by Nathan Tabor.
- App code/schema/viewer are a derived prototype. Unreviewed catalog metadata is not a certified linguistic database.
