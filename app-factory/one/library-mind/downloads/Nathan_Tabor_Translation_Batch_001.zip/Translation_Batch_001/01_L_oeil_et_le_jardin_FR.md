# LIVRE UN

## L’œil et le jardin

### Un Le clignement

La réunion du mercredi soir était terminée, mais l’église n’avait pas encore fini d’être une église.

Quelqu’un cherchait le couvercle d’un plat à gratin. Quelqu’un rapportait un parapluie emprunté. Dans la salle paroissiale, un homme qui avait prié avec beaucoup de solennité vingt minutes plus tôt essayait de convaincre sa femme que le reste du gâteau avait besoin d’un foyer.

Ruth se tenait près du baptistère, la Bible de sa grand-mère calée contre la hanche.

— June, c’est toi qui as mis ça là ?

— Si c’est encore une tâche pour un comité, non.

Au-dessus de l’eau, un contour pâle semblait se former autour du reflet de la lumière.

Un œil.

Puis les lumières clignotèrent.

Pendant un instant, des mots apparurent en dessous.

**EN UN INSTANT, EN UN CLIN D’ŒIL.**

La lumière revint. À l’étage inférieur, une chaise racla le sol.

Anna regarda Lydia. Lydia regarda Ruth. June cessa de sourire.

Beth approcha son fauteuil roulant du baptistère.

— Bon, dit-elle. On peut rester là à le regarder, ou chercher d’où venait la lumière.

La Bible glissa contre la main de Ruth. Une feuille pliée en tomba.

Au recto figurait un jardin dessiné au crayon. Deux chemins se croisaient en son centre.

Au verso, de la main de sa grand-mère :

**Commence avant la peur.**

### Deux Avant de se cacher

Le samedi les retrouva autour de la table de cuisine de Ruth. Cinq tasses. Une Bible. Une boîte à boutons au sujet de laquelle Ruth refusait toute explication.

Anna ouvrit la Genèse.

Elles commencèrent par la création : la lumière, la séparation, les végétaux, les créatures, l’humanité et le repos. Elles remarquèrent que le récit qualifiait la création de bonne avant que quiconque ait accompli quoi que ce soit.

— Avant le premier bulletin de notes, dit Beth.

Ruth sourit, puis baissa les yeux vers ses propres mains.

Dans le jardin vinrent une limite, une tentation, un choix, puis la dissimulation. Adam accusa la femme. La femme parla du serpent. Les conséquences suivirent. Des vêtements leur furent donnés. La vie continua hors du jardin.

Lydia se souvint d’une image de l’école du dimanche où Ève semblait porter toute la faute à elle seule.

— Adam est dans le passage aussi, dit June. Laissons-le à sa place.

Elles lurent l’histoire de Caïn et Abel. Une offrande. La colère. Un avertissement. Un frère tué. Une question de responsabilité. Un jugement qui comprenait une marque protégeant Caïn contre ceux qui le tueraient.

Anna écrivit deux phrases sur des cartes distinctes.

**Un acte peut être condamné.**

**Une vie peut encore être protégée.**

— Les deux, dit Ruth.

Elles lurent le déluge sans en effacer les morts. Elles suivirent la sauvegarde de Noé, l’alliance, puis la défaillance ultérieure de la famille. Avoir survécu ne les avait pas rendus irréprochables.

Babel apporta une ville, une tour et la dispersion des langues.

— Même un projet commun peut demander à être examiné, dit June.

Beth tourna le dessin du jardin vers la fenêtre. Les chemins croisés s’alignaient sur les plis marqués au crayon.

Un X.

À l’intersection, un seul mot.

**REGARDE.**

### Trois La famille à la tunique

Elles suivirent Abraham et Sara à travers le départ, la promesse, l’impatience et le rire. Elles s’attardèrent auprès d’Agar assez longtemps pour remarquer une femme en détresse que l’on voyait enfin. Elles lurent la menace du sacrifice d’Isaac et son interruption sans présenter la terreur comme une expérience agréable.

Rébecca entreprit un voyage. Jacob trompa et fut trompé. Ésaü perdit, puis, plus tard, ouvrit les bras. Léa et Rachel vécurent dans une maison où l’affection et la rivalité étaient inégalement réparties. Le récit de Dina fit surgir le mal subi et la violence des représailles ; les femmes refusèrent de confondre l’un ou l’autre avec une protection qui lui aurait rendu la parole.

Puis la tunique de Joseph arriva sur la table.

— Le voilà, dit Lydia. Le préféré.

Ses frères le vendirent. Ils laissèrent leur père le croire mort. En Égypte, Joseph subit l’injustice, interpréta des rêves et finit par organiser les réserves de nourriture en prévision d’une famine. Son pouvoir aurait pu écraser ses frères à leur retour. Au lieu de cela, après un difficile cheminement d’épreuves et de révélations, il pourvut aux besoins de la famille.

— Le bien qui vient ensuite ne transforme pas cette vente en bonne action, dit Anna.

Ruth acquiesça.

— Mais cela veut dire que cette vente n’a pas eu le dernier mot.

Une coupure de journal reposait dans la Bible, près de Genèse 50. Elle décrivait un fils de prédicateur élevé dans une ferme, le petit dernier de trois enfants, dont le père avait été éleveur de porcs, puis pasteur et peintre. Il s’appelait Nathan Tabor.

La note manuscrite à côté disait :

**Demande ce que l’enfant a reçu avant de décider de ce que veut dire l’adulte.**

June la lut deux fois.

Elles avaient cherché un dispositif au-dessus du baptistère. Maintenant, elles examinaient aussi l’héritage : les mots qu’une famille répète, les rôles qu’elle distribue et les attentes qu’un enfant apprend avant de savoir que ce sont des attentes.

— Qu’est-ce que tu as reçu ? demanda Anna à Ruth.

Ruth toucha la Bible de sa grand-mère.

— La foi. Une place à table. Et le sentiment que, si j’arrêtais de travailler, je risquais de perdre les deux.

Personne ne se précipita pour répondre.

Lydia rapprocha l’assiette de gâteau de sa mère.

Dans la boîte à boutons, sous un double fond, Beth trouva une clé en laiton.

Son étiquette portait ces mots :

**LA PORTE.**

### À table

Ruth commença une page avec deux titres : **Ce que j’ai reçu** et **Ce que je choisis de garder pour la suite**. Sous les deux, elle écrivit hospitalité. Sous le premier, elle écrivit épuisement. Sous le second, elle laissa un espace, en attendant d’être prête à le remplir.

**Parcours de lecture :** Genèse 1–50. Le récit retient les épisodes principaux ; la lecture intégrale comprend les généalogies, les alliances, les voyages, les conflits familiaux, les bénédictions et les morts.
