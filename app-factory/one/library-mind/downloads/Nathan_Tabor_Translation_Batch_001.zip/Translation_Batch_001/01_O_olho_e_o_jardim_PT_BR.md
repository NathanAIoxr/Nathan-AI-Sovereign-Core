# LIVRO UM

## O olho e o jardim

### Um O piscar

A reunião de quarta-feira à noite tinha terminado, mas a igreja ainda não tinha terminado de ser igreja.

Alguém procurava a tampa de uma travessa. Alguém devolvia um guarda-chuva emprestado. No salão de convivência, um homem que havia orado com muita solenidade vinte minutos antes tentava convencer a esposa de que o bolo que sobrara precisava de um lar.

Ruth estava perto do batistério, com a Bíblia da avó apoiada no quadril.

— June, foi você que colocou aquilo ali?

— Se for mais uma tarefa de comissão, não.

Acima da água, um contorno pálido parecia se formar em torno da luz refletida.

Um olho.

Então as luzes piscaram.

Por um instante, surgiram palavras embaixo dele.

**NUM MOMENTO, NUM ABRIR E FECHAR DE OLHOS.**

A luz voltou. Lá embaixo, uma cadeira arrastou no chão.

Anna olhou para Lydia. Lydia olhou para Ruth. June parou de sorrir.

Beth aproximou sua cadeira de rodas do batistério.

— Bom — disse ela. — Podemos ficar olhando ou descobrir de onde veio a luz.

A Bíblia escorregou junto à mão de Ruth. Uma folha dobrada caiu de dentro dela.

Na frente, havia um jardim desenhado a lápis. Dois caminhos se cruzavam pelo centro.

No verso, com a letra da avó:

**Comece antes do medo.**

### Dois Antes de se esconder

O sábado as encontrou em volta da mesa da cozinha de Ruth. Cinco xícaras. Uma Bíblia. Uma lata de botões sobre a qual Ruth se recusava a dar explicações.

Anna abriu Gênesis.

Começaram pela criação: luz, separação, plantas, criaturas, humanidade e descanso. Perceberam que o relato chamava a criação de boa antes de alguém ter realizado qualquer coisa.

— Antes de existir boletim escolar — disse Beth.

Ruth sorriu e depois baixou os olhos para as próprias mãos.

No jardim vieram um limite, uma tentação, uma escolha e o ato de se esconder. Adão culpou a mulher. A mulher falou da serpente. As consequências vieram. Roupas foram providenciadas. A vida continuou fora do jardim.

Lydia se lembrou de uma ilustração da escola dominical na qual Eva parecia carregar sozinha toda a culpa.

— Adão também está na passagem — disse June. — Vamos deixá-lo lá.

Leram sobre Caim e Abel. Uma oferta. Raiva. Um aviso. Um irmão morto. Uma pergunta sobre responsabilidade. Um julgamento que incluía uma marca para proteger Caim de ser morto por outros.

Anna escreveu duas frases em cartões separados.

**Um ato pode ser condenado.**

**Uma vida ainda pode ser protegida.**

— As duas coisas — disse Ruth.

Leram o dilúvio sem apagar as mortes. Acompanharam a preservação de Noé, a aliança e, depois, a falha posterior da família. Sobreviver não os tornara perfeitos.

Babel trouxe uma cidade, uma torre e a dispersão das línguas.

— Um plano compartilhado também pode precisar de exame — disse June.

Beth virou o desenho do jardim na direção da janela. Os caminhos cruzados se alinhavam com as dobras marcadas a lápis.

Um X.

No cruzamento havia uma palavra.

**OLHE.**

### Três A família da túnica

Acompanharam Abraão e Sara pela partida, pela promessa, pela impaciência e pelo riso. Ficaram com Agar tempo suficiente para perceber uma mulher em aflição sendo vista. Leram a ameaça do sacrifício de Isaque e sua interrupção sem chamar o terror de agradável.

Rebeca fez uma viagem. Jacó enganou e foi enganado. Esaú perdeu e, mais tarde, abraçou. Lia e Raquel viveram numa casa onde o afeto e a rivalidade eram distribuídos de maneira desigual. O relato de Diná trouxe o dano e a violência da retaliação; as mulheres se recusaram a confundir qualquer um dos dois com uma proteção que devolvesse a voz a ela.

Então a túnica de José chegou à mesa.

— Aí está — disse Lydia. — O favorito.

Os irmãos o venderam. Deixaram o pai acreditar que ele estava morto. No Egito, José sofreu injustiça, interpretou sonhos e, por fim, organizou os alimentos para um período de fome. Seu poder poderia ter esmagado os irmãos quando eles voltaram. Em vez disso, depois de um processo difícil de provas e revelações, ele sustentou a família.

— O bem que vem depois não transforma a venda num ato bom — disse Anna.

Ruth assentiu.

— Mas significa que a venda não teve a última palavra.

Um recorte de jornal estava dentro da Bíblia, junto de Gênesis 50. Descrevia o filho de um pregador criado numa fazenda, o caçula de três filhos, cujo pai havia sido criador de porcos e, mais tarde, pastor e pintor. O nome era Nathan Tabor.

A anotação manuscrita ao lado dizia:

**Pergunte o que a criança recebeu antes de decidir o que o adulto quer dizer.**

June leu aquilo duas vezes.

Elas tinham procurado um aparelho acima do batistério. Agora também examinavam a herança: as palavras que uma família repete, os papéis que distribui e as expectativas que uma criança aprende antes de saber que são expectativas.

— O que você recebeu? — perguntou Anna a Ruth.

Ruth tocou a Bíblia da avó.

— Fé. Um lugar à mesa. E a sensação de que, se eu parasse de trabalhar, poderia perder as duas coisas.

Ninguém se apressou em responder.

Lydia aproximou o prato de bolo da mãe.

Dentro da lata de botões, debaixo de um fundo falso, Beth encontrou uma chave de latão.

Na etiqueta estava escrito:

**A PORTA.**

### À mesa

Ruth começou uma página com dois títulos: **O que recebi** e **O que escolho levar adiante**. Debaixo dos dois, escreveu hospitalidade. Debaixo do primeiro, escreveu esgotamento. Debaixo do segundo, deixou um espaço até estar pronta para preenchê-lo.

**Trilha de leitura:** Gênesis 1–50. A narrativa seleciona episódios principais; a leitura completa inclui genealogias, alianças, viagens, disputas familiares, bênçãos e mortes.
