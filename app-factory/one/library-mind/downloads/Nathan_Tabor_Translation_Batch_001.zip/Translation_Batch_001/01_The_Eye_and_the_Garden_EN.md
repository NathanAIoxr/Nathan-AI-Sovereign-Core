# BOOK ONE

## The Eye and the Garden

### One The blink

Wednesday night was over, but the church had not finished being a church.

Someone was looking for the lid to a casserole dish. Someone was returning a borrowed umbrella. In the fellowship hall, a man who had prayed very solemnly twenty minutes earlier was trying to convince his wife that the remaining cake needed a home.

Ruth stood near the baptistry with her grandmother’s Bible balanced against her hip.

“June, did you put that there?”

“If it’s another committee assignment, no.”

Above the water, a pale outline seemed to gather around the reflected light.

An eye.

Then the lights blinked.

For an instant, words appeared beneath it.

**IN A MOMENT, IN THE TWINKLING OF AN EYE.**

Light returned. A chair scraped downstairs.

Anna looked at Lydia. Lydia looked at Ruth. June stopped smiling.

Beth rolled closer to the baptistry.

“Well,” she said. “We can stare at it, or we can find out where the light came from.”

The Bible slipped against Ruth’s hand. A folded page fell out.

On its front was a garden drawn in pencil. Through its center ran two crossing paths.

On the back, in her grandmother’s handwriting:

**Start before the fear.**

### Two Before the hiding

Saturday found them around Ruth’s kitchen table. Five cups. One Bible. A tin of buttons Ruth refused to explain.

Anna opened Genesis.

They began with creation: light, separation, growing things, creatures, humanity, and rest. They noticed that the account called creation good before anybody had achieved anything.

“Before there was a report card,” Beth said.

Ruth smiled, then looked down at her own hands.

In the garden came a boundary, a temptation, a choice, and hiding. Adam blamed the woman. The woman spoke of the serpent. Consequences followed. Clothing was provided. Life continued outside the garden.

Lydia remembered a Sunday-school picture where Eve seemed to carry the entire failure by herself.

“Adam’s in the passage too,” June said. “Let’s leave him there.”

They read Cain and Abel. An offering. Anger. A warning. A brother killed. A question about responsibility. A judgment that included a mark protecting Cain from being killed by others.

Anna wrote two sentences on separate cards.

**An act can be condemned.**

**A life can still be protected.**

“Both,” Ruth said.

They read the flood without making the deaths disappear. They followed Noah’s preservation, the covenant, and then the family’s later failure. Survival had not made them flawless.

Babel brought a city, a tower, and scattered speech.

“A shared plan can still need examining,” June said.

Beth turned the garden drawing toward the window. Its crossing paths lined up with the penciled folds.

An X.

At the intersection was one word.

**LOOK.**

### Three The family with the coat

They followed Abraham and Sarah through departure, promise, impatience, and laughter. They stayed with Hagar long enough to notice a woman in distress being seen. They read the threatened sacrifice of Isaac and its interruption without calling the terror pleasant.

Rebekah made a journey. Jacob deceived and was deceived. Esau lost and later embraced. Leah and Rachel lived inside a household where affection and rivalry were unequally distributed. Dinah’s account brought harm and retaliatory violence; the women refused to confuse either with protection that restored her voice.

Then Joseph’s coat arrived at the table.

“There it is,” Lydia said. “The favorite.”

The brothers sold him. They let their father believe he was dead. In Egypt, Joseph suffered injustice, interpreted dreams, and eventually organized food for a famine. His power could have crushed the brothers when they returned. Instead, after a difficult process of testing and disclosure, he provided for the family.

“The good that comes later doesn’t turn the selling into a good act,” Anna said.

Ruth nodded. “But it means the selling didn’t get the last word.”

A newspaper clipping lay inside the Bible beside Genesis 50. It described a preacher’s son raised on a farm, a baby boy of three, his father a pig farmer and later a minister and painter. The name was Nathan Tabor.

The handwritten note alongside it said:

**Ask what the child received before deciding what the grown person means.**

June read that twice.

They had been looking for a device above the baptistry. Now they were also looking at inheritance: the words a family repeats, the roles it distributes, and the expectations a child learns before knowing they are expectations.

“What did you receive?” Anna asked Ruth.

Ruth touched her grandmother’s Bible.

“Faith. A place at the table. And the feeling that if I stopped working, I might lose both.”

Nobody hurried to answer.

Lydia moved the cake plate closer to her mother.

Inside the button tin, under a false bottom, Beth found a brass key.

Its label read:

**THE DOOR.**

### At the table

Ruth began a page with two headings: **What I received** and **What I choose to carry forward**. Under both, she wrote hospitality. Under the first, she wrote exhaustion. Under the second, she left a space until she was ready to fill it.

**Reading trail:** Genesis 1–50. The retelling selects major episodes; the full reading includes genealogies, covenants, journeys, family disputes, blessings, and deaths.

---

