# LIBRO UNO

## El ojo y el jardín

### Uno El parpadeo

La reunión del miércoles por la noche había terminado, pero la iglesia todavía no había terminado de ser iglesia.

Alguien buscaba la tapa de una fuente para hornear. Alguien devolvía un paraguas prestado. En el salón de reuniones, un hombre que veinte minutos antes había orado con mucha solemnidad intentaba convencer a su esposa de que el pastel que quedaba necesitaba un hogar.

Ruth estaba junto al baptisterio, con la Biblia de su abuela apoyada contra la cadera.

—June, ¿pusiste eso ahí?

—Si es otro encargo de un comité, no.

Sobre el agua, un contorno pálido parecía formarse alrededor de la luz reflejada.

Un ojo.

Entonces las luces parpadearon.

Por un instante, aparecieron unas palabras debajo.

**EN UN MOMENTO, EN UN ABRIR Y CERRAR DE OJOS.**

Volvió la luz. Abajo, una silla rozó el suelo.

Anna miró a Lydia. Lydia miró a Ruth. June dejó de sonreír.

Beth acercó su silla de ruedas al baptisterio.

—Bueno —dijo—. Podemos quedarnos mirándolo o averiguar de dónde vino la luz.

La Biblia resbaló contra la mano de Ruth. Se cayó una hoja doblada.

En el anverso había un jardín dibujado a lápiz. Dos senderos se cruzaban por el centro.

En el reverso, con la letra de su abuela:

**Empieza antes del miedo.**

### Dos Antes de esconderse

El sábado las encontró alrededor de la mesa de la cocina de Ruth. Cinco tazas. Una Biblia. Una lata de botones sobre la que Ruth se negaba a dar explicaciones.

Anna abrió Génesis.

Empezaron por la creación: la luz, la separación, las plantas, los animales, la humanidad y el descanso. Notaron que el relato llamaba buena a la creación antes de que nadie hubiera logrado nada.

—Antes de que hubiera un boletín de calificaciones —dijo Beth.

Ruth sonrió y luego bajó la mirada hacia sus propias manos.

En el jardín hubo un límite, una tentación, una decisión y un intento de esconderse. Adán culpó a la mujer. La mujer habló de la serpiente. Llegaron las consecuencias. Recibieron ropa. La vida siguió fuera del jardín.

Lydia recordó una ilustración de la escuela dominical en la que Eva parecía cargar ella sola con toda la culpa.

—Adán también está en el pasaje —dijo June—. Dejémoslo ahí.

Leyeron lo de Caín y Abel. Una ofrenda. Ira. Una advertencia. Un hermano asesinado. Una pregunta sobre la responsabilidad. Un juicio que incluía una marca para proteger a Caín de que otros lo mataran.

Anna escribió dos frases en tarjetas separadas.

**Un acto puede ser condenado.**

**Una vida todavía puede ser protegida.**

—Las dos cosas —dijo Ruth.

Leyeron el diluvio sin borrar las muertes. Siguieron la preservación de Noé, el pacto y, después, el fracaso posterior de la familia. Haber sobrevivido no los había vuelto perfectos.

Babel trajo una ciudad, una torre y la dispersión de las lenguas.

—Un plan compartido también puede necesitar un examen —dijo June.

Beth giró el dibujo del jardín hacia la ventana. Los senderos cruzados coincidían con los pliegues marcados a lápiz.

Una X.

En la intersección había una palabra.

**MIRA.**

### Tres La familia de la túnica

Siguieron a Abraham y Sara por la partida, la promesa, la impaciencia y la risa. Se detuvieron con Agar el tiempo suficiente para reconocer a una mujer angustiada que era vista. Leyeron sobre el sacrificio que amenazaba a Isaac y su interrupción sin llamar agradable al terror.

Rebeca emprendió un viaje. Jacob engañó y fue engañado. Esaú perdió y más tarde abrazó. Lea y Raquel vivieron en una casa donde el afecto y la rivalidad estaban repartidos de manera desigual. El relato de Dina trajo daño y violencia de represalia; las mujeres se negaron a confundir cualquiera de las dos cosas con una protección que le devolviera la voz.

Entonces la túnica de José llegó a la mesa.

—Ahí está —dijo Lydia—. El favorito.

Los hermanos lo vendieron. Dejaron que su padre creyera que estaba muerto. En Egipto, José sufrió injusticias, interpretó sueños y finalmente organizó las reservas de alimentos para una hambruna. Su poder habría podido aplastar a sus hermanos cuando regresaron. En cambio, después de un difícil proceso de pruebas y revelaciones, proveyó para la familia.

—El bien que llega después no convierte la venta en un acto bueno —dijo Anna.

Ruth asintió.

—Pero significa que la venta no tuvo la última palabra.

Dentro de la Biblia, junto a Génesis 50, había un recorte de periódico. Describía al hijo de un predicador criado en una granja, el menor de tres hermanos, cuyo padre había sido criador de cerdos y, después, ministro y pintor. Se llamaba Nathan Tabor.

La nota manuscrita a su lado decía:

**Pregunta qué recibió el niño antes de decidir qué quiere decir el adulto.**

June la leyó dos veces.

Habían estado buscando un aparato encima del baptisterio. Ahora también examinaban la herencia: las palabras que una familia repite, los papeles que distribuye y las expectativas que un niño aprende antes de saber que son expectativas.

—¿Qué recibiste tú? —le preguntó Anna a Ruth.

Ruth tocó la Biblia de su abuela.

—Fe. Un lugar en la mesa. Y la sensación de que, si dejaba de trabajar, podía perder las dos cosas.

Nadie se apresuró a responder.

Lydia acercó el plato de pastel a su madre.

Dentro de la lata de botones, bajo un fondo falso, Beth encontró una llave de latón.

La etiqueta decía:

**LA PUERTA.**

### En la mesa

Ruth empezó una página con dos encabezados: **Lo que recibí** y **Lo que elijo llevar conmigo**. Debajo de ambos escribió hospitalidad. Debajo del primero escribió agotamiento. Debajo del segundo dejó un espacio hasta estar lista para llenarlo.

**Ruta de lectura:** Génesis 1–50. El relato selecciona episodios principales; la lectura completa incluye genealogías, pactos, viajes, disputas familiares, bendiciones y muertes.
