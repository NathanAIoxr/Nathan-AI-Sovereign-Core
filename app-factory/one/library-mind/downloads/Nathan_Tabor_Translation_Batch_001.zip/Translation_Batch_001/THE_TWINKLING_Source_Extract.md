# THE TWINKLING

## Eight connected books

### A mystery an adventure and a journey toward understanding

Developed from Nathan Tabor’s blueprint

**Condensed first manuscript**

This manuscript contains eight connected short books with a complete central mystery, followed by a reading map covering all 66 books of the Protestant Bible. It is not yet an exhaustive scene-by-scene retelling of every biblical episode. Biblical accounts are retold in contemporary language; new dialogue belongs to the fictional characters. Direct Scripture quotations use the KJV. Historical sources appear in the research notes.

The fictional family and church are inventions. Nathan’s autobiographical material is credited when introduced and is not assigned to an invented relative. The Eye is a fictional mystery device. Memory, imagination, instinct, and attention work through the narrative as human experiences; “supra” and “sub” belong to the author’s metaphorical framework, not a clinical diagnosis or a demonstrated method of bypassing a reader’s awareness. The book invites discovery and choice.

## The eight books

1. **The Eye and the Garden** — Genesis; beginnings, inheritance, and the first question.
2. **The Door and the Wilderness** — Exodus through Deuteronomy; freedom, provision, responsibility, and the way forward.
3. **The Crown and the Kitchen Table** — Joshua through Esther; belonging, power, courage, and whose account gets heard.
4. **The Question and the Quiet** — Job through Song of Solomon; suffering, wisdom, affection, and honest speech.
5. **The Watchman and the Window** — Isaiah through Malachi; justice, warning, exile, mercy, and return.
6. **The Table and the Empty Tomb** — Matthew through John; Jesus, dignity, service, death, and resurrection.
7. **The Letter and the Open Door** — Acts through Jude; community, discernment, grace, and love made practical.
8. **The Twinkling and the Beginning** — Revelation, returning to 1 Corinthians 15; judgment, endurance, renewal, and the resolution of the Eye.

## The Five

Ruth Mercer, seventy-eight, has spent forty-five years keeping the church’s fellowship kitchen supplied. She remembers who came, who stayed, and who quietly stopped coming. Sometimes she remembers a sentence more confidently than the occasion on which she heard it.

Her daughter Lydia, fifty-six, knows how to organize a funeral meal before anyone has decided who will call the family. She is learning that being dependable includes telling people when she needs help.

Lydia’s daughter Anna, thirty-four, repairs old photographs and notices where someone has cropped the edge. She loves her family and asks questions that occasionally make the room go quiet.

Anna’s sister-in-law Beth, thirty-nine, repairs equipment for a living, uses a wheelchair, and has an excellent opinion of her own ability to find things. People who talk over her usually discover she has already found the problem.

Mrs. June Ellis, sixty-eight, is Ruth’s oldest friend. She teaches the women’s Bible class and laughs before she answers difficult questions. Her notebooks contain more questions than anyone expects.

They are three generations and two chosen family members. Other women, men, and children belong to their community, but these five carry the investigation. Their ages, relationships, and observations let an individual reader, a family, or a group enter the same mystery without needing five generations present.

---

# BOOK ONE

## The Eye and the Garden

### One The blink

Wednesday night was over, but the church had not finished being a church.

Someone was looking for the lid to a casserole dish. Someone was returning a borrowed umbrella. In the fellowship hall, a man who had prayed very solemnly twenty minutes earlier was trying to convince his wife that the remaining cake needed a home.

Ruth stood near the baptistry with her grandmother’s Bible balanced against her hip.

“June, did you put that there?”

“If it’s another committee assignment, no.”

Above the water, a pale outline seemed to gather around the reflected light.

An eye.

Then the lights blinked.

For an instant, words appeared beneath it.

**IN A MOMENT, IN THE TWINKLING OF AN EYE.**

Light returned. A chair scraped downstairs.

Anna looked at Lydia. Lydia looked at Ruth. June stopped smiling.

Beth rolled closer to the baptistry.

“Well,” she said. “We can stare at it, or we can find out where the light came from.”

The Bible slipped against Ruth’s hand. A folded page fell out.

On its front was a garden drawn in pencil. Through its center ran two crossing paths.

On the back, in her grandmother’s handwriting:

**Start before the fear.**

### Two Before the hiding

Saturday found them around Ruth’s kitchen table. Five cups. One Bible. A tin of buttons Ruth refused to explain.

Anna opened Genesis.

They began with creation: light, separation, growing things, creatures, humanity, and rest. They noticed that the account called creation good before anybody had achieved anything.

“Before there was a report card,” Beth said.

Ruth smiled, then looked down at her own hands.

In the garden came a boundary, a temptation, a choice, and hiding. Adam blamed the woman. The woman spoke of the serpent. Consequences followed. Clothing was provided. Life continued outside the garden.

Lydia remembered a Sunday-school picture where Eve seemed to carry the entire failure by herself.

“Adam’s in the passage too,” June said. “Let’s leave him there.”

They read Cain and Abel. An offering. Anger. A warning. A brother killed. A question about responsibility. A judgment that included a mark protecting Cain from being killed by others.

Anna wrote two sentences on separate cards.

**An act can be condemned.**

**A life can still be protected.**

“Both,” Ruth said.

They read the flood without making the deaths disappear. They followed Noah’s preservation, the covenant, and then the family’s later failure. Survival had not made them flawless.

Babel brought a city, a tower, and scattered speech.

“A shared plan can still need examining,” June said.

Beth turned the garden drawing toward the window. Its crossing paths lined up with the penciled folds.

An X.

At the intersection was one word.

**LOOK.**

### Three The family with the coat

They followed Abraham and Sarah through departure, promise, impatience, and laughter. They stayed with Hagar long enough to notice a woman in distress being seen. They read the threatened sacrifice of Isaac and its interruption without calling the terror pleasant.

Rebekah made a journey. Jacob deceived and was deceived. Esau lost and later embraced. Leah and Rachel lived inside a household where affection and rivalry were unequally distributed. Dinah’s account brought harm and retaliatory violence; the women refused to confuse either with protection that restored her voice.

Then Joseph’s coat arrived at the table.

“There it is,” Lydia said. “The favorite.”

The brothers sold him. They let their father believe he was dead. In Egypt, Joseph suffered injustice, interpreted dreams, and eventually organized food for a famine. His power could have crushed the brothers when they returned. Instead, after a difficult process of testing and disclosure, he provided for the family.

“The good that comes later doesn’t turn the selling into a good act,” Anna said.

Ruth nodded. “But it means the selling didn’t get the last word.”

A newspaper clipping lay inside the Bible beside Genesis 50. It described a preacher’s son raised on a farm, a baby boy of three, his father a pig farmer and later a minister and painter. The name was Nathan Tabor.

The handwritten note alongside it said:

**Ask what the child received before deciding what the grown person means.**

June read that twice.

They had been looking for a device above the baptistry. Now they were also looking at inheritance: the words a family repeats, the roles it distributes, and the expectations a child learns before knowing they are expectations.

“What did you receive?” Anna asked Ruth.

Ruth touched her grandmother’s Bible.

“Faith. A place at the table. And the feeling that if I stopped working, I might lose both.”

Nobody hurried to answer.

Lydia moved the cake plate closer to her mother.

Inside the button tin, under a false bottom, Beth found a brass key.

Its label read:

**THE DOOR.**

### At the table

Ruth began a page with two headings: **What I received** and **What I choose to carry forward**. Under both, she wrote hospitality. Under the first, she wrote exhaustion. Under the second, she left a space until she was ready to fill it.

**Reading trail:** Genesis 1–50. The retelling selects major episodes; the full reading includes genealogies, covenants, journeys, family disputes, blessings, and deaths.

---

# BOOK TWO

## The Door and the Wilderness

### One The locked cupboard

The key opened a cupboard in the old classroom behind the fellowship hall.

Inside was a model doorway with red thread fastened across its top, a basket, a folded cloth, and a map with no road marked on it.

“Your grandmother taught from these?” Beth asked.

“When I was little,” Ruth said. “I remember the basket.”

They opened Exodus.

Before Moses stood before Pharaoh, women were already acting: midwives resisted a murderous command; a mother hid her baby; a sister watched; Pharaoh’s daughter took the child in.

“Everybody remembers the man with the staff,” Lydia said.

June touched the basket. “Read who helped him live long enough to hold it.”

Moses fled after killing an Egyptian. Years later, the burning bush called him back. He protested his inadequacy. Aaron joined him. Confrontation brought plagues, Passover, departure, and the sea crossing.

They named the deliverance and the deaths. Joy for people escaping bondage did not require pretending the account contained no grief.

At the sea, Miriam sang.

In the wilderness, the people complained.

Beth leaned back. “Freedom takes you out of the old place. It still leaves you needing breakfast.”

Lydia laughed harder than the sentence seemed to require.

### Two Enough for today

Manna came with instructions about gathering. Water was needed. Counsel from Jethro helped Moses share responsibility rather than hear every dispute himself.

Lydia closed the Bible.

“I have treated being the one everybody calls as proof that I’m doing life correctly.”

“You are good at it,” Anna said.

“I know. That’s how I hid from the question.”

She opened it again.

At Sinai came covenant and commandments. Then came the golden calf, broken tablets, intercession, and renewed covenant. The people who had received a clear instruction still needed accountability and another beginning.

They reached the tabernacle and lingered over skill: weaving, carving, joining, designing, making. Worship required hands as well as words.

Beth unfolded the cloth from the cupboard. It had five pockets.

One held a little carpenter’s square. Another held a needle. The others held a spoon, a pencil, and a smooth stone.

“Different functions,” June said.

Beth put the square against the model door.

It was crooked.

“And the first function of this one is admitting something needs adjusting.”

### Three The people between the lines

Leviticus slowed them down.

Offerings, priestly responsibilities, purity rules, holy days, restitution, land, and provision for people without much. It was an ancient covenantal system, and they read it as such before making modern applications.

They noticed the instruction to leave part of a harvest for the poor and the stranger.

“You can organize holiness in a way that leaves somebody food,” Lydia said.

Numbers counted people and recorded journeys, complaints, rebellion, and losses. Scouts saw the land; fear magnified the obstacles. Balaam’s ass saw what Balaam did not. The daughters of Zelophehad brought an inheritance question to the assembly, and the law answered their case.

“The question belongs in the room,” Anna said.

Deuteronomy retold the journey. Remember. Teach. Choose. Care for the widow, the fatherless, and the stranger. Hear the blessings and the warnings. Moses saw the land but died before entering it.

Ruth looked at the map with no road.

“I thought this was missing something.”

Beth held it against the model door. Small holes in the frame cast dots onto the paper.

A route appeared when the angle was right.

“It needed another part,” Beth said.

Lydia took out her phone and called another woman from church.

She asked whether they could divide the next funeral meal between three households.

The woman agreed before Lydia finished explaining.

For a moment Lydia looked almost offended that the world had allowed this so easily.

Then she laughed.

On the map’s far edge, the dots surrounded a crown.

### At the table

They chose one responsibility each to share, teach, or reconsider. Nobody was required to surrender a task she loved. Lydia kept making soup. Someone else would collect the dishes.

**Reading trail:** Exodus 1–40; Leviticus 1–27; Numbers 1–36; Deuteronomy 1–34. Laws and lists remain part of the reading, even when the narrative gives them a human-scale application.

---

# BOOK THREE

## The Crown and the Kitchen Table

### One A name in the margin

The crown marked a portrait in the church’s oldest photo album.

Ruth’s grandmother stood beside a table with a paper crown in her hand. Behind her, a woman’s face had been cut out of the photograph.

Anna did not say scandal. She said, “We need another copy.”

While they searched, June opened Joshua.

Crossing the Jordan. Rahab sheltering the spies. Jericho. Achan’s concealed taking and its consequences. Land allotted. Covenant renewed.

They did not turn conquest accounts into instructions for attacking present-day neighbors. The violence stayed visible; the characters asked what the texts presented about allegiance, judgment, and responsibility, and where modern application required care.

Judges carried cycles of failure and rescue. Deborah judged. Gideon doubted and acted. Jephthah’s vow devastated his daughter. Samson’s strength did not guarantee sound judgment. The final chapters brought abuse and civil conflict so grave that Ruth stopped reading aloud.

“We can take a minute,” June said.

The hopeful act that morning was giving the harmed people space in the discussion rather than rushing toward an entertaining hero.

Then Ruth opened the book bearing her own name.

Naomi lost her husband and sons. Ruth stayed with her. A field offered gleaning; Boaz offered protection and acted within the community’s arrangements. Marriage and a child followed.

“The whole village matters,” Lydia said. “Food. Safety. Witnesses.”

Beth pointed to the cut photograph.

“Then let’s find the woman the village picture lost.”

### Two The crown has a job

First Samuel began with Hannah’s anguish, prayer, and Samuel’s birth. Samuel heard a call. Israel asked for a king. Saul received authority and eventually lost the dynasty’s future through disobedience. David entered the account as a young shepherd and became a fugitive before becoming king.

Second Samuel did not let the crown protect David from the truth about Bathsheba and Uriah. Nathan confronted him. The household’s later wounds included Tamar’s violation, Amnon’s death, and Absalom’s revolt.

“A title doesn’t settle the question,” Anna said. “What did the person do with the power?”

Kings brought Solomon’s wisdom, temple, wealth, and divided loyalties; the divided kingdom; prophets confronting rulers; Elijah’s contest and flight; Elisha’s ministry; coups, injustice, reform, and collapse.

The widow’s oil interested Lydia. So did the unnamed servant girl who directed Naaman toward help.

Chronicles revisited ancestry, David, temple arrangements, and Judah’s kings.

“Another telling,” June said. “We should notice what it chooses to emphasize.”

Beth found the crown’s backing board in a storage trunk. On it, Ruth’s grandmother had written three headings:

**ATTRIBUTES. CHARACTERISTICS. FUNCTIONALITIES.**

Below them:

**What is present? What keeps happening? What does it do?**

Ruth set her grandmother’s paper crown on the table.

It looked surprisingly small.

### Three The photograph returned

Ezra and Nehemiah brought return, rebuilding, worship, law, opposition, and difficult decisions about community boundaries. Some decisions affected families painfully. The women discussed those costs alongside the restoration.

Esther brought a threatened people, a queen with access, Mordecai’s appeal, a risk, prepared banquets, exposed plotting, and deliverance with violence in its aftermath.

“She used the access she had,” Anna said. “She also prepared. Courage had a calendar.”

June arrived the following week with another copy of the photograph.

The missing woman was named Ellen. A note on its back identified her as the person who had painted scenery for the Bible lessons.

Ruth remembered her now. After Ellen moved away, the album had been damaged by water. Someone had cut the warped part off rather than replace the whole picture.

There had been no conspiracy.

There had been a lost name.

Anna scanned the complete copy. She wrote Ellen’s name beneath the restored image, alongside the names already known.

“We were ready to supply a motive before we had a second photograph,” she said.

June smiled. “A useful thing to catch ourselves doing.”

Ellen’s painted backdrop contained five windows. One was open.

Through it, someone had painted a chair and a book.

On the book’s spine:

**JOB.**

### At the table

They asked who had performed a useful task without receiving credit. They added names where they could verify them. Where they could not, they left the space honestly blank.

**Reading trail:** Joshua; Judges; Ruth; 1–2 Samuel; 1–2 Kings; 1–2 Chronicles; Ezra; Nehemiah; Esther, in full.

---

# BOOK FOUR

## The Question and the Quiet

### One The chair beside the bed

Ruth missed the next meeting because June’s sister was in hospital.

There was no clue hunt that evening. There was a chair beside a bed and a long conversation about ordinary things.

Afterward, June admitted she had been afraid she ought to say something better.

“You stayed,” Ruth said.

When they returned to Job, the opening losses felt different. Job lost possessions, children, and health. His friends arrived and initially sat in silence. Later they supplied explanations that treated suffering as evidence against him.

Job argued. He lamented. He wanted an answer.

The women read the heavenly scenes, the arguments, Elihu’s speeches, the divine response, and the conclusion without collapsing them into one speaker’s opinion. They noticed Job 42:7 rebuking the friends’ speech about God.

Restoration followed. June kept a finger at the earlier losses.

“New love doesn’t erase the people who died.”

Ruth nodded.

No one improved the sentence.

### Two The hymnal without a lid

Psalms gave them praise, complaint, confession, confidence, anger, thanksgiving, and unanswered waiting.

“We’ve sung the confident ones more often,” Lydia said.

They read Psalm 13. Then Psalm 23. Then Psalm 88, which did not finish with the emotional resolution they expected.

June wrote a question inside her notebook.

**Can I speak honestly before I feel better?**

Proverbs gave observations about speech, work, generosity, anger, discipline, judgment, and wisdom. Anna compared proverbs that addressed different situations.

“The circumstance matters,” she said. “A wise sentence still needs a reader paying attention.”

They came to Proverbs 23:7 and read its surrounding warning about a host whose apparent generosity hid a calculating heart. The phrase about thinking in one’s heart had a specific scene around it; they could discuss thought and identity without making that scene disappear.

Ecclesiastes let them examine work, pleasure, mortality, limits, injustice, companionship, and seasons. Its questions did not fit on a cheerful postcard.

Ruth looked toward the garden.

“My grandmother planted that pear tree. She never tasted a pear from it.”

“You have,” Anna said.

Ruth smiled. “Yes.”

### Three Love with the lights on

Song of Solomon surprised the table into silence, then laughter, then a discussion about affection nobody had expected to have over biscuits.

They read its poetry as poetry, with imagery, longing, beauty, and mutual delight. June explained that religious readers had also approached it allegorically. Those were interpretive traditions; the imagery on the page still deserved attention.

Beth found a ribbon tucked behind the family Bible’s binding. Tiny stitched letters ran along it.

**You may read the whole sentence.**

“That seems less dramatic than a secret passage,” Lydia said.

“Depends on the sentence,” Beth answered.

Ruth remembered being told she must have joy in every circumstance. She had loved the word and sometimes used it to hurry herself past grief.

That night she called June after the hospital visit.

“How are you?”

“Tired. Sad. Glad you called.”

All three belonged in the answer.

The ribbon ended in a little embroidered window. Anna matched it to Ellen’s painting. Along the painted sill, almost hidden beneath the frame, was a verse reference.

**ISAIAH 1.**

They had reached the watchman’s window.

### At the table

Each woman chose a psalm that matched what she actually felt. Anyone could keep her choice private. They let a prayer be truthful before asking it to be eloquent.

**Reading trail:** Job; Psalms; Proverbs; Ecclesiastes; Song of Solomon, in full. The characters’ applications are not promises that changing an interpretation instantly cures illness or grief.

---

# BOOK FIVE

## The Watchman and the Window

### One What the window shows

The window in Ellen’s painting faced the church parking lot.

Through the real window, Lydia could see the place where a visitor had once waited for somebody to help her carry groceries to her car.

Lydia had been too busy arranging flowers to notice.

Isaiah confronted injustice and hollow religious performance. Its visions also spoke of comfort, restoration, a servant, and a future wider than the immediate crisis.

Jeremiah warned amid resistance and disaster. Lamentations mourned Jerusalem rather than decorating its destruction. Ezekiel carried visions, accountability, judgment, restoration, and dry bones receiving life.

“We can enjoy the impressive image and miss the people around it,” Anna said.

Daniel placed faithful people in imperial courts: food decisions, dreams, a furnace, a lions’ den, and visions of kingdoms. The women distinguished the accounts’ settings from every proposed modern timetable.

“A resemblance is a reason to examine something,” Beth said. “We still need evidence before announcing a match.”

She wrote that beneath the three headings from the crown.

### Two The small books with large questions

Hosea brought covenant betrayal and the difficult marriage imagery through which the book expressed it. Joel brought devastation, repentance, and promised outpouring. Amos confronted exploitation and worship disconnected from justice.

Obadiah condemned Edom’s conduct toward a distressed neighbor. Jonah resisted an assignment, survived the sea and the fish, preached to Nineveh, and resented mercy.

Ruth shut her eyes briefly.

“I have been Jonah after the plant died,” she said. “Upset that somebody else got kindness.”

Micah brought justice, mercy, and humility into view. Nahum announced Nineveh’s fall. Habakkuk questioned injustice and faced a difficult answer. Zephaniah warned of judgment and anticipated restoration.

Haggai addressed rebuilding and priorities. Zechariah supplied visions, encouragement, and future hope. Malachi challenged failures in worship, faithfulness, and justice, ending with a forward-looking promise.

They heard distinct books with distinct concerns. The repeated call to attend to their neighbors became clearer because they had stayed with the differences.

Lydia moved the visitor groceries onto the church’s next meeting agenda.

“We need volunteers at the door,” she said. “And a way to ask what help someone wants.”

### Three The warning that opened outward

The window frame had a narrow compartment behind it. Beth found it while checking a loose screw.

Inside lay a church newsletter and a sketch of the baptistry.

The newsletter announced a long-ago Bible exhibition called **The Twinkling**. Ruth recognized the date. She had helped wash cups afterward.

“I remember the eye now,” she said. “It was part of the last display.”

The exhibition’s purpose was written beneath the title:

**Read what came before. Read what follows. Let the whole passage speak.**

Anna brought up a digital collection of ancient manuscripts. They looked at preserved pages and fragments, realizing how much careful work lay between an old written object and a readable transcription.

No fragment said whatever they wished it to say. No gap authorized them to invent a missing sentence.

June opened the KJV at the exhibition’s final reference: 1 Corinthians 15.

“We started with half a line,” she said.

“And inherited some of the feeling around it,” Lydia said.

The sketch marked an electrical cabinet, but the cabinet’s key was missing.

On the newsletter’s back, Ellen had drawn a table with an extra place setting.

At that place she had written:

**COME AND SEE.**

### At the table

They selected one practice their church could improve and identified the person who would benefit. The first answer came from the visitor herself: a clear path, an offered hand, and permission to decline help.

**Reading trail:** Isaiah; Jeremiah; Lamentations; Ezekiel; Daniel; Hosea; Joel; Amos; Obadiah; Jonah; Micah; Nahum; Habakkuk; Zephaniah; Haggai; Zechariah; Malachi, in full.

---

# BOOK SIX

## The Table and the Empty Tomb

### One A place already set

June invited someone from the Methodist church and a friend from the Presbyterian congregation to supper. Ruth worried about the biscuits before she thought to worry about denominational differences.

The newcomers recognized more of the evening than anyone had expected: the dish brought as a gift, the inherited Bible, the concern over whether everyone had enough, the person who began clearing plates before finishing her own meal.

They opened Matthew and Luke and compared the birth narratives without pretending they were identical arrangements. Mary received an announcement. Joseph faced a decision. Elizabeth welcomed Mary. Shepherds came in Luke; wise men appeared in Matthew. Herod’s violence and the flight to Egypt remained in Matthew’s account.

They did not build an exact modern birth date from details that did not supply one.

Mark moved quickly into Jesus’ ministry. John opened with the Word and brought its own arrangement of signs and conversations.

“Four witnesses in our reading,” Anna said. “We should hear each one before combining them.”

Beth watched someone reach automatically for Ruth’s plate.

“She’s still eating,” she said gently.

The hand stopped. The plate stayed.

### Two Who is beside the road

They followed Jesus through baptism, temptation, teaching, healing, calling, disagreement, and meals.

People approached with needs. Others approached with questions. Some wanted to test him. The women noticed how often a conversation changed because somebody whom the crowd treated as an interruption became the person addressed.

The Samaritan woman had a substantial conversation. A woman touched a garment. Mary listened; Martha worked and spoke. Children were welcomed. A blind man called out. Zacchaeus came down from a tree and discussed restitution.

June told the parable of the good Samaritan in plain language: a person was harmed, others passed, someone stopped, gave care, arranged lodging, and took responsibility for its cost.

“Attributes,” Beth said.

“Characteristics,” Anna added.

Lydia set down the serving spoon. “Function. He helped.”

They read the prodigal son and stayed with the older brother too. Return was welcome; resentment still stood outside asking whether generosity was fair.

At the Transfiguration, the disciples saw a revelation that the Gospel accounts placed within Jesus’ journey toward suffering. The women could admire the mountain and still follow him down it.

Ellen’s table sketch included a tiny drawing under one chair: an ass beside a city gate.

They turned to the entry into Jerusalem.

### Three The women at the tomb

They followed the final meal, the washing of feet in John, the garden, betrayal, arrest, trials, denial, crucifixion, and burial. They did not make suffering cheerful in order to preserve the books’ hopeful direction.

Lydia remembered a grieving friend who had been told to rejoice before anyone asked whether she had slept.

“I’ll sit with her,” she said. “And let her tell me what today is like.”

Then came the resurrection accounts. Women arrived at the tomb. Announcements and encounters followed. The Gospel accounts told the events with differences in selection and detail; the group read each account rather than supplying a single invented transcript.

Thomas received an encounter amid doubt. Peter received words of restoration and responsibility. Followers received a commission.

Ruth read the Easter lesson she had saved from her grandmother’s papers.

At the bottom was a note written for a frightened reader:

**You may bring your question with you.**

Beth found the electrical-cabinet key inside the lesson folder. Someone had used it to weigh down a packet of transparencies.

They took it to church the next morning.

The door opened.

Inside was a small projector, unplugged, and a handwritten maintenance sheet.

Anna read the first entry aloud.

“Eye display. Do not connect to sanctuary lighting circuit.”

Beth looked toward the baptistry.

“Well,” she said. “Someone did.”

### At the table

They asked where they could make room for a person whose voice was usually crowded out. Their answers included listening, returning something owed, offering practical help, and receiving help themselves.

**Reading trail:** Matthew 1–28; Mark 1–16; Luke 1–24; John 1–21. Parallel accounts remain individually readable. The manuscript dramatizes responses to them rather than replacing their text.

---

# BOOK SEVEN

## The Letter and the Open Door

### One The repaired circuit

Beth called a qualified electrician. The church authorized a repair. The electrician found an old display supply connected where it should not have been; an intermittent fault explained the blink. The projector’s surviving slide explained the Eye.

The repair was ordinary, and everyone was relieved.

The question the slide had awakened still mattered.

Acts carried them into Pentecost, shared life, conflict, persecution, scattering, and journeys. Widows needed fair distribution. Stephen died. Philip met an Ethiopian traveler. Saul became a follower after a violent campaign against the church. Peter entered Cornelius’s household. Lydia opened her home. Priscilla and Aquila helped Apollos understand more accurately.

“Teaching can include being taught,” June said.

The Jerusalem meeting addressed a real disagreement about Gentile believers. Paul’s journeys included churches, arguments, danger, imprisonment, and shipwreck.

The first communities had gifts and problems.

Lydia took comfort in the combination.

### Two Letters addressed to people

Romans examined sin, faith, grace, law, Israel, and a life of service. Its discussion of governing authority in chapter 13 sat beside instructions about love; the women did not treat a passage about public authority as permission for private revenge.

First Corinthians addressed division, conduct, bodies, marriage, food, worship, spiritual gifts, love, and resurrection. Second Corinthians carried weakness, reconciliation, generosity, and contested authority.

Galatians challenged requirements being imposed on Gentile believers. Ephesians described belonging and a walk shaped by the gospel. Philippians spoke of partnership, humility, endurance, and rejoicing. Colossians centered Christ and warned against teachings that displaced that center.

First and Second Thessalonians addressed encouragement, grief, expectation, and confusion about the Lord’s coming. The women read the reassurance with the warnings. They saw why an isolated phrase could grow into a much louder message in a child’s memory.

First and Second Timothy and Titus dealt with teaching, care, leadership, conduct, and endurance. Philemon placed a request about Onesimus inside a relationship shaped by Christian brotherhood. The women named the slavery surrounding the letter rather than treating a gracious request as if it erased the institution.

June returned to 2 Timothy 2:15 and its phrase about rightly dividing the word of truth.

Her practical question was simple.

“Who is being addressed, and what are we reading?”

Anna added, “What is our application, and what did the passage actually say?”

### Three The notebook with the loose page

Hebrews called for endurance and considered priesthood, sacrifice, covenant, and faith. James made faith practical in conduct, speech, fairness, and care. First Peter addressed suffering and hope. Second Peter warned about corrupt teaching.

The letters of John examined truth, love, fellowship, and conduct. Jude warned against destructive people within the community.

Lydia came to James 1:27 and thought of the meal rota, the groceries, the people waiting for a call after a funeral.

She wrote names beside tasks. She also asked whether the people wanted the proposed help.

June produced the last of Ellen’s notebooks.

Inside, the exhibition’s working title had been crossed out.

**EVERYTHING CAN END INSTANTLY.**

Below it, another line:

**EVERYTHING CAN BEGIN INSTANTLY.**

The note beside it was careful.

**A new choice can begin in a moment. Its work may take years.**

Ruth read it and felt her shoulders lower.

She did not have to fix seventy-eight years before supper.

She could ask Anna to stay while she talked about one thing.

At the back of the notebook, Ellen had drawn seven lampstands and an open city gate.

Their last reading waited.

### At the table

They examined one inherited sentence, keeping three things separate: its actual words, what they had heard in it, and what they chose to do now. Nobody needed to agree on every conclusion to listen accurately.

**Reading trail:** Acts; Romans; 1–2 Corinthians; Galatians; Ephesians; Philippians; Colossians; 1–2 Thessalonians; 1–2 Timothy; Titus; Philemon; Hebrews; James; 1–2 Peter; 1–3 John; Jude, in full.

---

# BOOK EIGHT

## The Twinkling and the Beginning

### One Seven letters before the thunder

They began Revelation where Revelation began, with its greeting, vision, and messages to seven churches.

June read the names slowly: Ephesus, Smyrna, Pergamos, Thyatira, Sardis, Philadelphia, Laodicea.

Praise and correction. Endurance and compromise. Doors and lamps. A call to hear.

The churches were addressed before the women reached the visions that had filled so much of their childhood imagination.

They followed the throne scene, scroll, seals, trumpets, conflict, beasts, judgments, Babylon’s fall, victory, final judgment, and new creation. The imagery was intense. They acknowledged the suffering it represented instead of turning catastrophe into entertainment.

June brought three commentaries that approached Revelation differently. They compared readings without pretending that scholarly disagreement proved all interpretations equally strong, or that confidence made one interpretation indisputable.

“Let’s mark what the text says first,” Anna said. “Then we can examine what each person thinks it means.”

Ruth had once thought this kind of comparison would weaken the room.

The room became quieter and more attentive.

### Two The city with room

At Revelation 21 and 22, they read of a new heaven and earth, tears wiped away, death ended, a city, a river, and a tree whose leaves were for healing.

Ruth looked again at the first garden drawing.

“A garden at the beginning,” she said.

“And these images at the end,” Anna replied.

They laid all eight clues on the table: the garden, door, crown, chair, window, table, letter, and city gate.

The backs formed one large sheet. Ellen had drawn a room, then divided it into eight pieces for her exhibition lessons.

Five chairs surrounded a table.

At the center was an open Bible.

The Eye had been a display about reading. The verse had become a family question because of what each woman had carried into the room.

“I heard hurry,” Lydia said.

“I heard loss,” Ruth said.

“I heard a puzzle,” Beth said.

June looked at Anna.

“I heard the missing words,” Anna answered.

They opened 1 Corinthians 15 again. The passage spoke of resurrection, transformation, victory over death, and steadfast work. The twinkling belonged inside that argument. It had not been written as an instruction for a child to remain terrified of every sudden sound.

Ruth read the line about being changed.

Then she read on.

### Three The whole sentence

The women organized a new exhibition at church. The repaired projector stayed separate from the sanctuary lights. Beth checked the accessible route through every display.

They called it **THE TWINKLING**.

At each station was a passage to read, a plain-language account, and space to record a question. Historical objects appeared as photographs with source labels. The invented family mystery was identified as fiction. Their own memories were offered as memories.

Nobody was asked to surrender her faith to enter.

Nobody had to report a private hurt to complete the walk.

An older woman stayed at the chair display a long time. A younger woman read the whole chapter behind the Eye. Two men argued cheerfully about the dimensions of the model door before noticing the passage beside it.

Lydia sat down to eat while there was still food left.

Ruth watched her and smiled.

June stood at the final table. A visitor asked whether she had to come with a group.

“You can read it alone,” she said. “You can bring family. Friends. A class. The five questions fit around any table.”

She pointed to the notebook:

**What do I remember?**

**What question am I carrying?**

**What pattern do I notice?**

**Who is affected?**

**What could I do next?**

The visitor sat down.

Ruth placed her grandmother’s Bible at the center, open rather than closed.

That evening, she and Anna went through the photograph album. They added names, corrected a date, and left one uncertain entry marked uncertain.

Ordinary work.

Useful work.

Anna asked what Ruth wanted to write at the end of her new page.

Ruth thought for a moment.

Then she wrote:

**EVERYTHING CAN BEGIN INSTANTLY.**

Below it:

**Tomorrow I will ask for help before I am exhausted.**

Anna added her own sentence.

Beth had already arranged the next meeting. June would bring the questions. Lydia would bring soup, because she wanted to.

Outside, the evening settled over the church windows. Inside, five women kept talking.

The next moment belonged to them.

### At the table

Choose one next action small enough to name and real enough to do. A beginning may be a conversation, a boundary, a returned phone call, a meal, a corrected assumption, or an appointment for help. It need not erase the past to change what happens next.

**Reading trail:** Revelation 1–22; then 1 Corinthians 15 in full. The narrative’s final inversion is an application about a beginning, not a replacement translation of either passage.

---

# The complete biblical reading map

## Coverage and the next manuscript stage

Every canonical book is assigned below. “Every story” requires a finer inventory than a list of famous episodes: laws, genealogies, poetry, speeches, visions, letters, and repeated accounts also belong to the Bible. This map supplies the complete book-level reading route. A full-length expansion must add chapter-level entries and scene-level retellings before claiming exhaustive coverage.

The condensed books above dramatize selected episodes. They do not claim that mentioning a biblical book retells all its contents.

## Book One Genesis

**Genesis 1–11:** creation and rest; garden and disobedience; Cain and Abel; descendants and growing violence; Noah, flood, covenant, and later family conflict; nations; Babel.

**Genesis 12–25:** Abraham’s journeys and covenants; Sarah; Lot and Sodom; Hagar and Ishmael; Isaac and the interrupted sacrifice; Sarah’s death; Rebekah’s journey; Abraham’s later household and death.

**Genesis 25–36:** Jacob and Esau; Isaac’s household; blessing and flight; Bethel; Jacob’s work and marriages; children; departure; wrestling; reconciliation; Dinah and violence at Shechem; return to Bethel; deaths and genealogies.

**Genesis 37–50:** Joseph and his brothers; Judah and Tamar; slavery and imprisonment; dreams; famine administration; the brothers’ journeys; disclosure; migration; blessings; deaths and future hope.

## Book Two Exodus through Deuteronomy

**Exodus:** bondage, midwives, Moses’ birth and flight, call, Pharaoh, plagues, Passover, departure, sea crossing, wilderness provision, Sinai, covenant, tabernacle instructions, calf, intercession, renewal, construction.

**Leviticus:** offerings, priesthood, purity, atonement, holiness, sexual and social boundaries, festivals, land and release, blessings and penalties, vows. Retell as covenant instruction with its own context; distinguish description from modern prescription.

**Numbers:** censuses, camp, duties, dedication, journey, complaints, scouts, rebellion, priestly disputes, wilderness deaths, water, bronze serpent, Balaam, Peor, inheritance, offerings, vows, warfare, land and refuge.

**Deuteronomy:** retrospective addresses, law, covenant, memory, worship, justice, domestic and public responsibilities, blessings and curses, choice, succession, song, blessing, Moses’ death.

## Book Three Joshua through Esther

**Joshua:** spies and Rahab, crossing, conquest and its violence, covenant and failure, allotments, refuge, disputes, final addresses.

**Judges:** recurring crises; Othniel, Ehud, Shamgar, Deborah and Barak, Gideon, Abimelech, later judges, Jephthah, Samson; Micah and Dan; the Levite’s concubine and civil war. The harmed people must remain people, not props for a hero lesson.

**Ruth:** loss, migration, loyalty, gleaning, protection, kinship responsibility, witnesses, marriage, genealogy.

**1 Samuel:** Hannah and Samuel, Eli’s house, ark narratives, Saul, David, Jonathan, conflict, Abigail, flight, Saul’s death.

**2 Samuel:** kingship, ark, covenant, wars, David and Bathsheba, Uriah, confrontation, family violence, rebellion, restoration, later troubles and closing materials.

**1 Kings:** succession, Solomon, temple, divided kingdom, prophets, Elijah, Ahab and Jezebel, Naboth, war.

**2 Kings:** Elijah and Elisha, royal houses and coups, Israel’s fall, Judah’s reforms and failures, siege, exile, closing release.

**1 Chronicles:** genealogies, David, worship organization, temple preparation, succession.

**2 Chronicles:** Solomon and temple, Judah’s kings, reform and failure, exile, decree of return. Compare with Kings without erasing different emphases.

**Ezra:** return, rebuilding, opposition, dedication, Ezra’s arrival, covenant concerns, marriage decisions and family consequences.

**Nehemiah:** return, wall, opposition, economic injustice, registration, public reading, covenant, dedication, reforms.

**Esther:** royal household, Esther’s rise, conspiracy, threatened destruction, counsel, intervention, reversal, conflict, Purim.

## Book Four Job through Song of Solomon

**Job:** framing scenes, losses, lament, dialogues, wisdom poem, final defense, Elihu, divine speeches, response, rebuke, restoration. Track the speaker of every claim.

**Psalms:** all 150, including praise, lament, thanksgiving, wisdom, royal and historical psalms, penitence, imprecation, and communal prayers. Do not force every ending into the same emotional shape.

**Proverbs:** introductory instruction, collected sayings, extended counsel, final collections, household wisdom. Read individual sayings within their literary and situational setting.

**Ecclesiastes:** investigations, limits, seasons, injustice, companionship, mortality, enjoyment, wisdom, conclusion.

**Song of Solomon:** the full poetic sequence; speakers, imagery, longing, encounter, separation, delight. Note uncertainty in dividing speakers rather than inventing certainty.

## Book Five Isaiah through Malachi

**Isaiah:** judgment, holiness, political crises, nations, comfort, servant passages, restoration, justice, future visions.

**Jeremiah:** call, warnings, symbolic acts, conflict, royal decisions, siege, aftermath, new covenant, nations, historical close.

**Lamentations:** five poems mourning disaster; grief, responsibility, appeal, and unresolved pain.

**Ezekiel:** call and visions, sign acts, judgment, accountability, nations, restoration, dry bones, Gog, temple and land visions.

**Daniel:** court narratives, dreams, furnace, royal judgment, writing on wall, lions, visions, prayer, future conflict.

**Hosea:** prophetic marriage imagery, covenant betrayal, judgment, mercy and return; do not use the metaphor to prescribe tolerating domestic abuse.

**Joel:** devastation, repentance, restoration, outpouring, judgment.

**Amos:** nations, injustice, visions, confrontation, restoration.

**Obadiah:** Edom, betrayal of a distressed neighbor, judgment and deliverance.

**Jonah:** flight, sea, fish, mission, Nineveh’s response, anger, unanswered final question.

**Micah:** injustice, judgment, leadership, future hope, covenant dispute, mercy.

**Nahum:** Nineveh’s judgment in forceful poetry.

**Habakkuk:** complaint, response, watchfulness, woes, prayer and trust amid lack.

**Zephaniah:** judgment, nations, purification and restoration.

**Haggai:** rebuilding, priorities, encouragement and promise.

**Zechariah:** visions, renewal, fasting, future leadership and conflict, restoration.

**Malachi:** worship, leadership, covenant faithfulness, justice, giving, remembrance, future messenger.

## Book Six Matthew through John

**Matthew:** genealogy and infancy, baptism and temptation, teaching discourses, healings, parables, confession and Transfiguration, Jerusalem, final discourse, passion, resurrection and commission.

**Mark:** opening ministry, teaching and healing, conflict, discipleship, Transfiguration, Jerusalem, passion and resurrection. The KJV includes Mark 16:9–20; ancient manuscript discussions belong in source notes with accurate attribution.

**Luke:** infancy, ministry, journeys, distinctive parables and encounters, Jerusalem, passion, resurrection, Emmaus and ascension.

**John:** prologue, signs, conversations, festivals and conflict, Lazarus, final supper and discourses, passion, resurrection appearances and epilogue.

Retell each Gospel in its own sequence before creating any parallel comparison. Mark combined scenes explicitly as adaptations.

## Book Seven Acts through Jude

**Acts:** ascension, Pentecost, community, persecution, service disputes, Stephen, scattering, Philip, Saul, Peter and Cornelius, Antioch, journeys, Jerusalem council, trials, voyage and Rome.

**Romans:** gospel, sin, faith, Abraham, new life, law and Spirit, Israel, service and conduct, conscience, greetings.

**1 Corinthians:** division, wisdom, conduct, disputes, marriage, food, worship, gifts, love, resurrection, collection and greetings.

**2 Corinthians:** ministry, affliction, reconciliation, generosity, defense and weakness.

**Galatians:** authority, faith and law, belonging, freedom, Spirit, responsibility.

**Ephesians:** blessing, reconciliation, belonging, unity, conduct, household instructions and armor.

**Philippians:** partnership, imprisonment, humility, examples, warning, rejoicing, gratitude.

**Colossians:** Christ, reconciliation, teaching, new conduct, household and greetings.

**1 Thessalonians:** relationship, encouragement, conduct, grief, coming, watchfulness.

**2 Thessalonians:** endurance, coming, correction, work and order.

**1 Timothy:** teaching, prayer, leadership, service, widows, conduct, wealth.

**2 Timothy:** endurance, faithfulness, teaching, Scripture, testimony and closing requests.

**Titus:** leadership, teaching, grace, conduct and service.

**Philemon:** personal appeal concerning Onesimus and reception as a brother; retain the enslaved person’s stake in the discussion.

**Hebrews:** Christ, priesthood, covenant, sacrifice, endurance, faith, discipline and community.

**James:** trials, wisdom, hearing and doing, partiality, faith and works, tongue, conflict, wealth, patience, prayer.

**1 Peter:** hope, holiness, relationships, suffering and care.

**2 Peter:** growth, testimony, corrupt teachers, coming and patience.

**1 John:** fellowship, truth, conduct, love, assurance.

**2 John:** truth, love and discernment about teaching.

**3 John:** hospitality, authority and conduct.

**Jude:** warning, remembered examples, perseverance and doxology.

## Book Eight Revelation

**Revelation 1–3:** introduction, vision, seven churches.

**Revelation 4–7:** throne, scroll, seals, witnesses and multitude.

**Revelation 8–11:** trumpets, scroll, measuring and witnesses.

**Revelation 12–14:** woman, dragon, beasts, Lamb, proclamations and harvest.

**Revelation 15–18:** bowls, judgment, Babylon and lament over its fall.

**Revelation 19–20:** praise, rider, defeat, millennium and final judgment.

**Revelation 21–22:** new creation, city, river, tree, final invitations and warnings.

**Return reading:** 1 Corinthians 15, with special attention to verses 35–58. The central phrase concerns resurrection and transformation. Its narrative use as a prompt for renewed understanding is an application.

---

# Ancient collections and source notes

## The sources used for this draft

The research here consulted publicly accessible collection descriptions and selected biblical chapters. It did not inspect every manuscript, visit every ancient library, or establish a complete textual history. The ancient material broadens the investigation while the narrative’s quoted Bible remains the KJV.

**KJV anchors.** [1 Corinthians 15](https://www.kingjamesbibleonline.org/1-Corinthians-Chapter-15/) supplies the central phrase and its resurrection setting. [2 Timothy 2](https://www.kingjamesbibleonline.org/2-Timothy-Chapter-2/) supplies the instruction about rightly dividing the word of truth. The novel’s explanatory dialogue is modern interpretation, not additional Scripture.

**Dead Sea Scrolls.** The [Israel Antiquities Authority digital library](https://www.deadseascrolls.org.il/home?locale=en_US) provides access to manuscript images and contextual information. Its [discovery and publication account](https://www.deadseascrolls.org.il/learn-about-the-scrolls/discovery-and-publication?locale=en_US) describes biblical and other ancient religious writings among the finds. In this draft, that distinction supports the characters’ habit of labeling a source before applying it.

**Codex Sinaiticus.** The [British Library’s description](https://support.bl.uk/Page/Codex-Sinaiticus) introduces the manuscript and the project bringing its dispersed portions together digitally. Its age or importance does not make it an original autograph of any biblical author. An expanded scene can examine transcription and translation without asking readers to abandon their preferred English Bible.

**Mesopotamian flood traditions.** The [British Museum catalog entry for a Gilgamesh flood tablet](https://www.britishmuseum.org/collection/object/W_K-2252) identifies material from Tablet 11. The [museum entry for another Gilgamesh tablet](https://www.britishmuseum.org/collection/object/W_K-231) describes development of the epic from earlier material. These are comparative ancient sources. A resemblance between flood accounts alone does not establish direct borrowing or prove every event described.

**Vatican digitization.** [DigiVatLib](https://digi.vatlib.it/) provides a further route into digitized historical holdings. A specific claim requires a named manuscript, its catalog information, a readable passage, and suitable language expertise. The collection’s existence supplies access, not a predetermined conclusion.

## Research routes for a full expansion

Additional candidate collections include Cambridge’s Genizah holdings, the University of Chicago’s Institute for the Study of Ancient Cultures, Oxford’s manuscript collections, papyrus collections, and curated early-Christian textual repositories. They are next research routes, not sources claimed to have been exhaustively read for this draft.

The surviving evidence for ancient Alexandria is a historical research topic, not a complete ancient catalog secretly available online. Likewise, an ancient library may survive through excavated tablets or dispersed manuscripts rather than as an intact building with every book accessible.

For each future ancient-text scene, keep a source record containing collection, object identifier, approximate date with uncertainty, language, edition or translation, exact passage used, and the reason it is relevant. If a text falls outside the 66-book Protestant canon, identify it as comparative material.

## Rules for the full retellings

Keep four categories visible in the editorial notes: **the text says**, **a historical source supports**, **the characters interpret**, and **the fiction invents**. These can remain quiet in the narrative, but they must not disappear from the notes.

Read a difficult episode before selecting its hopeful direction. Preserve the harmed person, the consequences, and the unanswered question. Hope can arise through protection, accountability, assistance, mercy, endurance, or repair; it need not require declaring the original harm beneficial.

Use recurring attributes across genders. Listening, courage, tenderness, invention, endurance, and protection belong to every member of The Five. Female-centered experience supplies the setting and relationships without making a trait exclusive to women or men.

Let readers understand the self-help purpose. The fiction can carry the lesson subtly through recognition and discovery. It should not promise secret access to the mind or guaranteed healing. Memory and imagination can meet attention in the narrative while the reader retains the choice of what to accept.

---

# Reading alone or together

A reader alone can keep one notebook and use the five questions at the final table. A family can read the same passage and compare what each person remembers. A church group can meet around a chapter without requiring anyone to disclose private experiences or agree on every interpretation.

For grandparents and grandchildren, choose passages and discussions suitable to the younger reader’s age. The complete Bible contains violence and sexual harm; the adult manuscript acknowledges them without graphic description. A youth edition needs its own careful adaptation rather than merely a younger cover.

Begin a gathering with the actual passage. Continue with the retelling. Ask which details the adaptation emphasized and which remain in the fuller text. Then discuss the five questions. Close by naming one useful next action, if the reader wants to choose one.

The question can continue after the meeting.

The person can keep thinking.

And the next twinkling belongs to the reader.
