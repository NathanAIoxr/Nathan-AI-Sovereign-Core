# LIVRO TRÊS

## A coroa e a mesa da cozinha

### Um Um nome na margem

A coroa marcava um retrato no álbum de fotografias mais antigo da igreja.

A avó de Ruth estava ao lado de uma mesa, com uma coroa de papel na mão. Atrás dela, o rosto de uma mulher tinha sido recortado da fotografia.

Anna não disse escândalo. Disse:

— Precisamos de outra cópia.

Enquanto procuravam, June abriu Josué.

A travessia do Jordão. Raabe abrigando os espias. Jericó. O que Acã tomou às escondidas e suas consequências. A divisão da terra. A renovação da aliança.

Elas não transformaram os relatos de conquista em instruções para atacar os vizinhos de hoje. A violência continuou visível; as personagens perguntaram o que os textos apresentavam sobre lealdade, julgamento e responsabilidade, e em quais pontos a aplicação moderna exigia cuidado.

Juízes trazia ciclos de falha e resgate. Débora julgou. Gideão duvidou e agiu. O voto de Jefté devastou sua filha. A força de Sansão não garantia bom discernimento. Os capítulos finais trouxeram abusos e um conflito civil tão graves que Ruth parou de ler em voz alta.

— Podemos fazer uma pausa — disse June.

O ato de esperança daquela manhã foi dar espaço às pessoas feridas na conversa, em vez de correr para um herói divertido.

Então Ruth abriu o livro que levava seu próprio nome.

Noemi perdeu o marido e os filhos. Rute ficou com ela. Um campo ofereceu espigas para recolher; Boaz ofereceu proteção e agiu dentro dos acordos da comunidade. Depois vieram o casamento e uma criança.

— A aldeia inteira importa — disse Lydia. — Comida. Segurança. Testemunhas.

Beth apontou para a fotografia recortada.

— Então vamos encontrar a mulher que a foto da aldeia perdeu.

### Dois A coroa tem uma função

Primeiro Samuel começou com a angústia e a oração de Ana, e com o nascimento de Samuel. Samuel ouviu um chamado. Israel pediu um rei. Saul recebeu autoridade e acabou perdendo o futuro de sua dinastia por desobediência. Davi entrou no relato como um jovem pastor e se tornou fugitivo antes de virar rei.

Segundo Samuel não deixou a coroa proteger Davi da verdade sobre Bate-Seba e Urias. Natã o confrontou. As feridas posteriores da família incluíram o estupro de Tamar, a morte de Amnom e a revolta de Absalão.

— Um título não resolve a questão — disse Anna. — O que a pessoa fez com o poder?

Reis trouxe a sabedoria, o templo, a riqueza e as lealdades divididas de Salomão; o reino dividido; profetas confrontando governantes; o desafio e a fuga de Elias; o ministério de Eliseu; golpes, injustiça, reforma e colapso.

O azeite da viúva interessou a Lydia. A jovem serva sem nome que indicou ajuda a Naamã também.

Crônicas voltou aos antepassados, a Davi, à organização do templo e aos reis de Judá.

— Outra forma de contar — disse June. — Precisamos perceber o que ela escolhe destacar.

Beth encontrou a placa de suporte da coroa em um baú. Nela, a avó de Ruth tinha escrito três títulos:

**ATRIBUTOS. CARACTERÍSTICAS. FUNCIONALIDADES.**

Embaixo:

**O que está presente? O que continua acontecendo? O que isso faz?**

Ruth colocou a coroa de papel da avó sobre a mesa.

Ela parecia surpreendentemente pequena.

### Três A fotografia recuperada

Esdras e Neemias trouxeram retorno, reconstrução, adoração, lei, oposição e decisões difíceis sobre os limites da comunidade. Algumas decisões atingiram famílias dolorosamente. As mulheres discutiram esses custos junto com a restauração.

Ester trouxe um povo ameaçado, uma rainha com acesso ao poder, o apelo de Mordecai, um risco, banquetes preparados, uma trama revelada e uma libertação seguida de violência.

— Ela usou o acesso que tinha — disse Anna. — Também se preparou. A coragem tinha calendário.

June chegou na semana seguinte com outra cópia da fotografia.

A mulher que faltava se chamava Ellen. Uma anotação no verso a identificava como a pessoa que tinha pintado os cenários das aulas bíblicas.

Ruth se lembrava dela agora. Depois que Ellen se mudou, o álbum tinha sido danificado pela água. Alguém havia recortado a parte deformada em vez de substituir a fotografia inteira.

Não tinha havido conspiração.

Tinha havido um nome perdido.

Anna digitalizou a cópia completa. Escreveu o nome de Ellen embaixo da imagem restaurada, ao lado dos nomes já conhecidos.

— Estávamos prontas para atribuir um motivo antes de ter uma segunda fotografia — disse ela.

June sorriu.

— É útil perceber quando estamos fazendo isso.

O cenário pintado por Ellen tinha cinco janelas. Uma estava aberta.

Através dela, alguém havia pintado uma cadeira e um livro.

Na lombada do livro:

**JÓ.**

### À mesa

Elas perguntaram quem havia realizado uma tarefa útil sem receber reconhecimento. Acrescentaram os nomes que conseguiram verificar. Onde não conseguiram, deixaram o espaço honestamente em branco.

**Trilha de leitura:** Josué; Juízes; Rute; 1–2 Samuel; 1–2 Reis; 1–2 Crônicas; Esdras; Neemias; Ester, na íntegra.
