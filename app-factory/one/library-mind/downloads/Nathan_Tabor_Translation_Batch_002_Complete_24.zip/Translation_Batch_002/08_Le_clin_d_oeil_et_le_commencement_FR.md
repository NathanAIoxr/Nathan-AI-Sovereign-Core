# LIVRE HUIT

## Le clin d’œil et le commencement

### Un Sept lettres avant le tonnerre

Elles commencèrent l’Apocalypse là où l’Apocalypse commençait : par sa salutation, sa vision et ses messages à sept églises.

June lut lentement les noms : Éphèse, Smyrne, Pergame, Thyatire, Sardes, Philadelphie, Laodicée.

Éloges et corrections. Persévérance et compromis. Portes et lampes. Un appel à entendre.

Les églises recevaient leurs messages avant que les femmes atteignent les visions qui avaient tant rempli leur imagination d’enfants.

Elles suivirent la scène du trône, le rouleau, les sceaux, les trompettes, le conflit, les bêtes, les jugements, la chute de Babylone, la victoire, le jugement dernier et la nouvelle création. Les images étaient intenses. Elles reconnurent la souffrance qu’elles représentaient au lieu de transformer la catastrophe en divertissement.

June apporta trois commentaires qui abordaient l’Apocalypse différemment. Elles comparèrent les lectures sans prétendre que le désaccord entre spécialistes prouvait que toutes les interprétations étaient aussi solides, ni que l’assurance rendait une interprétation indiscutable.

— Notons d’abord ce que dit le texte, dit Anna. Ensuite, nous pourrons examiner ce que chaque personne pense qu’il signifie.

Ruth avait autrefois pensé que ce genre de comparaison fragiliserait l’assemblée.

La pièce devint plus silencieuse et plus attentive.

### Deux La ville où il y a de la place

Dans Apocalypse 21 et 22, elles lurent un ciel et une terre nouveaux, des larmes essuyées, la mort abolie, une ville, un fleuve et un arbre dont les feuilles servaient à la guérison.

Ruth regarda de nouveau le premier dessin du jardin.

— Un jardin au commencement, dit-elle.

— Et ces images à la fin, répondit Anna.

Elles posèrent les huit indices sur la table : le jardin, la porte, la couronne, la chaise, la fenêtre, la table, la lettre et la porte de la ville.

Leurs versos formaient une grande feuille. Ellen avait dessiné une pièce, puis l’avait divisée en huit morceaux pour les leçons de son exposition.

Cinq chaises entouraient une table.

Au centre se trouvait une Bible ouverte.

L’Œil avait été une installation sur la lecture. Le verset était devenu une question familiale à cause de ce que chaque femme avait apporté dans la pièce.

— J’ai entendu la précipitation, dit Lydia.

— J’ai entendu la perte, dit Ruth.

— J’ai entendu une énigme, dit Beth.

June regarda Anna.

— J’ai entendu les mots manquants, répondit Anna.

Elles ouvrirent de nouveau 1 Corinthiens 15. Le passage parlait de résurrection, de transformation, de victoire sur la mort et de travail persévérant. Le clin d’œil appartenait à ce raisonnement. Il n’avait pas été écrit comme une consigne demandant à un enfant de rester terrifié par chaque bruit soudain.

Ruth lut la ligne sur le fait d’être transformés.

Puis elle poursuivit sa lecture.

### Trois La phrase entière

Les femmes organisèrent une nouvelle exposition à l’église. Le projecteur réparé resta séparé de l’éclairage du sanctuaire. Beth vérifia l’accessibilité du parcours à travers chaque installation.

Elles l’appelèrent **LE CLIN D’ŒIL**.

À chaque étape se trouvaient un passage à lire, un récit en langage simple et un espace pour noter une question. Les objets historiques étaient présentés sous forme de photographies accompagnées de leurs sources. Le mystère de la famille inventée était identifié comme fiction. Leurs propres souvenirs étaient proposés comme souvenirs.

Personne ne devait abandonner sa foi pour entrer.

Personne n’avait à révéler une blessure intime pour terminer le parcours.

Une femme âgée resta longtemps devant l’installation de la chaise. Une femme plus jeune lut le chapitre entier derrière l’Œil. Deux hommes débattirent gaiement des dimensions de la porte miniature avant de remarquer le passage placé à côté.

Lydia s’assit pour manger alors qu’il restait encore de la nourriture.

Ruth la regarda et sourit.

June se tenait près de la dernière table. Une visiteuse demanda si elle devait venir avec un groupe.

— Vous pouvez le lire seule, dit-elle. Vous pouvez venir avec votre famille. Des amis. Une classe. Les cinq questions ont leur place autour de n’importe quelle table.

Elle désigna le carnet :

**De quoi est-ce que je me souviens ?**

**Quelle question est-ce que je porte ?**

**Quel schéma est-ce que je remarque ?**

**Qui est concerné ?**

**Que pourrais-je faire ensuite ?**

La visiteuse s’assit.

Ruth plaça la Bible de sa grand-mère au centre, ouverte plutôt que fermée.

Ce soir-là, Anna et elle parcoururent l’album de photographies. Elles ajoutèrent des noms, corrigèrent une date et laissèrent une mention incertaine signalée comme incertaine.

Un travail ordinaire.

Un travail utile.

Anna demanda ce que Ruth voulait écrire à la fin de sa nouvelle page.

Ruth réfléchit un instant.

Puis elle écrivit :

**TOUT PEUT COMMENCER EN UN INSTANT.**

En dessous :

**Demain, je demanderai de l’aide avant d’être épuisée.**

Anna ajouta sa propre phrase.

Beth avait déjà organisé la réunion suivante. June apporterait les questions. Lydia apporterait de la soupe, parce qu’elle en avait envie.

Dehors, le soir descendait sur les fenêtres de l’église. À l’intérieur, cinq femmes continuaient à parler.

L’instant suivant leur appartenait.

### À table

Choisissez une prochaine action assez petite pour la nommer et assez réelle pour l’accomplir. Un commencement peut être une conversation, une limite, un appel rendu, un repas, une supposition corrigée ou un rendez-vous pour obtenir de l’aide. Il n’a pas besoin d’effacer le passé pour changer ce qui arrive ensuite.

**Parcours de lecture :** Apocalypse 1–22 ; puis 1 Corinthiens 15 en entier. L’inversion finale du récit est une application concernant un commencement, et non une traduction de remplacement de l’un ou l’autre passage.
