# LIVRO CINCO

## O vigia e a janela

### Um O que a janela mostra

A janela na pintura de Ellen dava para o estacionamento da igreja.

Pela janela de verdade, Lydia conseguia ver o lugar onde uma visitante tinha esperado, certa vez, que alguém a ajudasse a levar as compras até o carro.

Lydia estava ocupada demais arrumando flores para perceber.

Isaías confrontava a injustiça e a prática religiosa vazia. Suas visões também falavam de consolo, restauração, um servo e um futuro mais amplo do que a crise imediata.

Jeremias advertia em meio à resistência e ao desastre. Lamentações chorava por Jerusalém em vez de enfeitar sua destruição. Ezequiel trazia visões, responsabilidade, julgamento, restauração e ossos secos recebendo vida.

— Podemos gostar da imagem impressionante e não enxergar as pessoas ao redor dela — disse Anna.

Daniel colocava pessoas fiéis em cortes imperiais: decisões sobre alimentação, sonhos, uma fornalha, uma cova de leões e visões de reinos. As mulheres distinguiram os cenários dos relatos de cada cronologia moderna proposta.

— Uma semelhança é motivo para examinar alguma coisa — disse Beth. — Ainda precisamos de evidências antes de anunciar uma correspondência.

Ela escreveu isso embaixo dos três títulos da coroa.

### Dois Os livros pequenos com perguntas grandes

Oseias trouxe a traição à aliança e as difíceis imagens do casamento pelas quais o livro a expressava. Joel trouxe devastação, arrependimento e um derramamento prometido. Amós confrontou a exploração e a adoração desligada da justiça.

Obadias condenou a conduta de Edom diante de um vizinho em aflição. Jonas resistiu a uma missão, sobreviveu ao mar e ao peixe, pregou em Nínive e se ressentiu da misericórdia.

Ruth fechou os olhos por um instante.

— Eu já fui Jonas depois que a planta morreu — disse ela. — Irritada porque outra pessoa recebeu bondade.

Miqueias trouxe justiça, misericórdia e humildade à vista. Naum anunciou a queda de Nínive. Habacuque questionou a injustiça e enfrentou uma resposta difícil. Sofonias advertiu sobre o julgamento e antecipou a restauração.

Ageu tratou de reconstrução e prioridades. Zacarias trouxe visões, encorajamento e esperança futura. Malaquias confrontou falhas na adoração, na fidelidade e na justiça, terminando com uma promessa voltada para o futuro.

Elas ouviram livros distintos, com preocupações distintas. O chamado repetido para prestar atenção aos vizinhos ficou mais claro porque elas permaneceram atentas às diferenças.

Lydia colocou a ajuda com as compras dos visitantes na pauta da reunião seguinte da igreja.

— Precisamos de voluntários na porta — disse ela. — E de um jeito de perguntar que ajuda a pessoa quer.

### Três O aviso que se abria para fora

Havia um compartimento estreito atrás da moldura da janela. Beth o encontrou ao verificar um parafuso frouxo.

Dentro estavam um boletim da igreja e um esboço do batistério.

O boletim anunciava uma antiga exposição bíblica chamada **O Piscar de Olhos**. Ruth reconheceu a data. Ela tinha ajudado a lavar as xícaras depois.

— Agora me lembro do olho — disse. — Fazia parte da última instalação.

O propósito da exposição estava escrito embaixo do título:

**Leia o que veio antes. Leia o que vem depois. Deixe a passagem inteira falar.**

Anna abriu uma coleção digital de manuscritos antigos. Elas olharam páginas e fragmentos preservados, percebendo quanto trabalho cuidadoso havia entre um objeto escrito antigo e uma transcrição legível.

Nenhum fragmento dizia tudo o que elas desejassem que dissesse. Nenhuma lacuna autorizava a invenção de uma frase ausente.

June abriu a KJV na referência final da exposição: 1 Coríntios 15.

— Começamos com meia linha — disse ela.

— E herdamos parte do sentimento ao redor dela — disse Lydia.

O esboço marcava um armário elétrico, mas a chave do armário estava faltando.

No verso do boletim, Ellen havia desenhado uma mesa com um lugar a mais.

Naquele lugar, tinha escrito:

**VENHA E VEJA.**

### À mesa

Elas escolheram uma prática que a igreja podia melhorar e identificaram quem se beneficiaria. A primeira resposta veio da própria visitante: um caminho livre, uma mão oferecida e permissão para recusar ajuda.

**Trilha de leitura:** Isaías; Jeremias; Lamentações; Ezequiel; Daniel; Oseias; Joel; Amós; Obadias; Jonas; Miqueias; Naum; Habacuque; Sofonias; Ageu; Zacarias; Malaquias, na íntegra.
