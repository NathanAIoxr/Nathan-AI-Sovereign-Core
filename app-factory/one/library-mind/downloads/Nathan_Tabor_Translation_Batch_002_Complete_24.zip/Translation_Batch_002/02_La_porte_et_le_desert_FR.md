# LIVRE DEUX

## La porte et le désert

### Un Le placard fermé

La clé ouvrit un placard dans l’ancienne salle de classe, derrière la salle paroissiale.

À l’intérieur se trouvaient une porte miniature avec un fil rouge fixé au-dessus, un panier, un tissu plié et une carte sur laquelle aucune route n’était tracée.

— Ta grand-mère enseignait avec ça ? demanda Beth.

— Quand j’étais petite, répondit Ruth. Je me souviens du panier.

Elles ouvrirent l’Exode.

Avant que Moïse se présente devant Pharaon, des femmes agissaient déjà : des sages-femmes avaient résisté à un ordre meurtrier ; une mère avait caché son bébé ; une sœur avait veillé ; la fille de Pharaon avait recueilli l’enfant.

— Tout le monde se souvient de l’homme au bâton, dit Lydia.

June toucha le panier.

— Lisez qui l’a aidé à vivre assez longtemps pour le tenir.

Moïse s’enfuit après avoir tué un Égyptien. Des années plus tard, le buisson ardent le rappela. Il protesta de son incapacité. Aaron le rejoignit. L’affrontement amena les plaies, la Pâque, le départ et la traversée de la mer.

Elles nommèrent la délivrance et les morts. Se réjouir pour les personnes qui échappaient à la servitude n’exigeait pas de prétendre que le récit ne contenait aucun chagrin.

Au bord de la mer, Miriam chanta.

Dans le désert, le peuple se plaignit.

Beth se cala contre son dossier.

— La liberté vous sort de l’ancien endroit. Elle vous laisse quand même le besoin de prendre un petit déjeuner.

Lydia rit plus fort que la phrase ne semblait le justifier.

### Deux Assez pour aujourd’hui

La manne arriva avec des instructions pour la récolte. Il fallait de l’eau. Les conseils de Jéthro aidèrent Moïse à partager les responsabilités au lieu d’entendre lui-même tous les différends.

Lydia ferma la Bible.

— J’ai pris le fait d’être celle que tout le monde appelle pour la preuve que je menais correctement ma vie.

— Tu le fais bien, dit Anna.

— Je sais. C’est comme ça que j’ai évité la question.

Elle la rouvrit.

Au Sinaï vinrent l’alliance et les commandements. Puis le veau d’or, les tables brisées, l’intercession et l’alliance renouvelée. Les personnes qui avaient reçu une instruction claire avaient encore besoin de rendre des comptes et de recommencer.

Elles arrivèrent au tabernacle et s’attardèrent sur les savoir-faire : tisser, sculpter, assembler, concevoir, fabriquer. Le culte demandait des mains autant que des paroles.

Beth déplia le tissu du placard. Il avait cinq poches.

L’une contenait une petite équerre de menuisier. Une autre, une aiguille. Les autres contenaient une cuillère, un crayon et une pierre lisse.

— Des fonctions différentes, dit June.

Beth plaça l’équerre contre la porte miniature.

Elle était de travers.

— Et la première fonction de celle-ci, c’est de reconnaître qu’un ajustement est nécessaire.

### Trois Les personnes entre les lignes

Le Lévitique les ralentit.

Offrandes, responsabilités sacerdotales, règles de pureté, jours saints, restitution, terres et dispositions pour les personnes démunies. C’était un ancien système d’alliance, et elles le lurent comme tel avant d’en tirer des applications modernes.

Elles remarquèrent l’instruction de laisser une partie de la récolte au pauvre et à l’étranger.

— On peut organiser la sainteté de façon à laisser à quelqu’un de quoi manger, dit Lydia.

Les Nombres recensaient les personnes et racontaient les voyages, les plaintes, les rébellions et les pertes. Les éclaireurs virent le pays ; la peur grossit les obstacles. L’ânesse de Balaam vit ce que Balaam ne voyait pas. Les filles de Tselophchad soumirent une question d’héritage à l’assemblée, et la loi répondit à leur cas.

— La question a sa place dans la pièce, dit Anna.

Le Deutéronome raconta de nouveau le voyage. Souviens-toi. Enseigne. Choisis. Prends soin de la veuve, de l’orphelin et de l’étranger. Écoute les bénédictions et les avertissements. Moïse vit le pays, mais mourut avant d’y entrer.

Ruth regarda la carte sans route.

— Je pensais qu’il manquait quelque chose.

Beth la tint contre la porte miniature. De petits trous dans le cadre projetèrent des points sur le papier.

Un itinéraire apparut quand l’angle fut le bon.

— Il lui fallait une autre pièce, dit Beth.

Lydia sortit son téléphone et appela une autre femme de l’église.

Elle demanda si elles pouvaient répartir le prochain repas d’obsèques entre trois foyers.

La femme accepta avant que Lydia ait fini de s’expliquer.

Un instant, Lydia parut presque offensée que le monde ait permis cela aussi facilement.

Puis elle rit.

À l’extrémité de la carte, les points entouraient une couronne.

### À table

Chacune choisit une responsabilité à partager, à transmettre ou à reconsidérer. Aucune ne dut renoncer à une tâche qu’elle aimait. Lydia continuerait à préparer la soupe. Quelqu’un d’autre ramasserait la vaisselle.

**Parcours de lecture :** Exode 1–40 ; Lévitique 1–27 ; Nombres 1–36 ; Deutéronome 1–34. Les lois et les listes restent partie intégrante de la lecture, même lorsque le récit leur donne une application à échelle humaine.
