# THE TWINKLING

## Edição em português brasileiro

**Por Nathan Tabor**

## LIVRO UM

### O olho e o jardim

#### Um O piscar

A reunião de quarta-feira à noite tinha terminado, mas a igreja ainda não tinha terminado de ser igreja.

Alguém procurava a tampa de uma travessa. Alguém devolvia um guarda-chuva emprestado. No salão de convivência, um homem que havia orado com muita solenidade vinte minutos antes tentava convencer a esposa de que o bolo que sobrara precisava de um lar.

Ruth estava perto do batistério, com a Bíblia da avó apoiada no quadril.

— June, foi você que colocou aquilo ali?

— Se for mais uma tarefa de comissão, não.

Acima da água, um contorno pálido parecia se formar em torno da luz refletida.

Um olho.

Então as luzes piscaram.

Por um instante, surgiram palavras embaixo dele.

**NUM MOMENTO, NUM ABRIR E FECHAR DE OLHOS.**

A luz voltou. Lá embaixo, uma cadeira arrastou no chão.

Anna olhou para Lydia. Lydia olhou para Ruth. June parou de sorrir.

Beth aproximou sua cadeira de rodas do batistério.

— Bom — disse ela. — Podemos ficar olhando ou descobrir de onde veio a luz.

A Bíblia escorregou junto à mão de Ruth. Uma folha dobrada caiu de dentro dela.

Na frente, havia um jardim desenhado a lápis. Dois caminhos se cruzavam pelo centro.

No verso, com a letra da avó:

**Comece antes do medo.**

#### Dois Antes de se esconder

O sábado as encontrou em volta da mesa da cozinha de Ruth. Cinco xícaras. Uma Bíblia. Uma lata de botões sobre a qual Ruth se recusava a dar explicações.

Anna abriu Gênesis.

Começaram pela criação: luz, separação, plantas, criaturas, humanidade e descanso. Perceberam que o relato chamava a criação de boa antes de alguém ter realizado qualquer coisa.

— Antes de existir boletim escolar — disse Beth.

Ruth sorriu e depois baixou os olhos para as próprias mãos.

No jardim vieram um limite, uma tentação, uma escolha e o ato de se esconder. Adão culpou a mulher. A mulher falou da serpente. As consequências vieram. Roupas foram providenciadas. A vida continuou fora do jardim.

Lydia se lembrou de uma ilustração da escola dominical na qual Eva parecia carregar sozinha toda a culpa.

— Adão também está na passagem — disse June. — Vamos deixá-lo lá.

Leram sobre Caim e Abel. Uma oferta. Raiva. Um aviso. Um irmão morto. Uma pergunta sobre responsabilidade. Um julgamento que incluía uma marca para proteger Caim de ser morto por outros.

Anna escreveu duas frases em cartões separados.

**Um ato pode ser condenado.**

**Uma vida ainda pode ser protegida.**

— As duas coisas — disse Ruth.

Leram o dilúvio sem apagar as mortes. Acompanharam a preservação de Noé, a aliança e, depois, a falha posterior da família. Sobreviver não os tornara perfeitos.

Babel trouxe uma cidade, uma torre e a dispersão das línguas.

— Um plano compartilhado também pode precisar de exame — disse June.

Beth virou o desenho do jardim na direção da janela. Os caminhos cruzados se alinhavam com as dobras marcadas a lápis.

Um X.

No cruzamento havia uma palavra.

**OLHE.**

#### Três A família da túnica

Acompanharam Abraão e Sara pela partida, pela promessa, pela impaciência e pelo riso. Ficaram com Agar tempo suficiente para perceber uma mulher em aflição sendo vista. Leram a ameaça do sacrifício de Isaque e sua interrupção sem chamar o terror de agradável.

Rebeca fez uma viagem. Jacó enganou e foi enganado. Esaú perdeu e, mais tarde, abraçou. Lia e Raquel viveram numa casa onde o afeto e a rivalidade eram distribuídos de maneira desigual. O relato de Diná trouxe o dano e a violência da retaliação; as mulheres se recusaram a confundir qualquer um dos dois com uma proteção que devolvesse a voz a ela.

Então a túnica de José chegou à mesa.

— Aí está — disse Lydia. — O favorito.

Os irmãos o venderam. Deixaram o pai acreditar que ele estava morto. No Egito, José sofreu injustiça, interpretou sonhos e, por fim, organizou os alimentos para um período de fome. Seu poder poderia ter esmagado os irmãos quando eles voltaram. Em vez disso, depois de um processo difícil de provas e revelações, ele sustentou a família.

— O bem que vem depois não transforma a venda num ato bom — disse Anna.

Ruth assentiu.

— Mas significa que a venda não teve a última palavra.

Um recorte de jornal estava dentro da Bíblia, junto de Gênesis 50. Descrevia o filho de um pregador criado numa fazenda, o caçula de três filhos, cujo pai havia sido criador de porcos e, mais tarde, pastor e pintor. O nome era Nathan Tabor.

A anotação manuscrita ao lado dizia:

**Pergunte o que a criança recebeu antes de decidir o que o adulto quer dizer.**

June leu aquilo duas vezes.

Elas tinham procurado um aparelho acima do batistério. Agora também examinavam a herança: as palavras que uma família repete, os papéis que distribui e as expectativas que uma criança aprende antes de saber que são expectativas.

— O que você recebeu? — perguntou Anna a Ruth.

Ruth tocou a Bíblia da avó.

— Fé. Um lugar à mesa. E a sensação de que, se eu parasse de trabalhar, poderia perder as duas coisas.

Ninguém se apressou em responder.

Lydia aproximou o prato de bolo da mãe.

Dentro da lata de botões, debaixo de um fundo falso, Beth encontrou uma chave de latão.

Na etiqueta estava escrito:

**A PORTA.**

#### À mesa

Ruth começou uma página com dois títulos: **O que recebi** e **O que escolho levar adiante**. Debaixo dos dois, escreveu hospitalidade. Debaixo do primeiro, escreveu esgotamento. Debaixo do segundo, deixou um espaço até estar pronta para preenchê-lo.

**Trilha de leitura:** Gênesis 1–50. A narrativa seleciona episódios principais; a leitura completa inclui genealogias, alianças, viagens, disputas familiares, bênçãos e mortes.

---

## LIVRO DOIS

### A porta e o deserto

#### Um O armário trancado

A chave abriu um armário na antiga sala de aula, atrás do salão de convivência.

Dentro havia uma porta em miniatura com uma linha vermelha presa na parte de cima, um cesto, um pano dobrado e um mapa sem nenhuma estrada marcada.

— Sua avó usava isso para ensinar? — perguntou Beth.

— Quando eu era pequena — disse Ruth. — Eu me lembro do cesto.

Elas abriram Êxodo.

Antes de Moisés se apresentar ao faraó, mulheres já estavam agindo: parteiras resistiram a uma ordem assassina; uma mãe escondeu seu bebê; uma irmã vigiou; a filha do faraó acolheu a criança.

— Todo mundo se lembra do homem com o cajado — disse Lydia.

June tocou o cesto.

— Leiam quem ajudou ele a viver tempo suficiente para segurá-lo.

Moisés fugiu depois de matar um egípcio. Anos mais tarde, a sarça ardente o chamou de volta. Ele protestou por não se considerar capaz. Arão se juntou a ele. O confronto trouxe pragas, Páscoa, partida e a travessia do mar.

Elas nomearam a libertação e as mortes. A alegria por quem escapava da escravidão não exigia fingir que o relato não continha tristeza.

À beira do mar, Miriã cantou.

No deserto, o povo reclamou.

Beth se recostou.

— A liberdade tira você do lugar antigo. Ainda deixa você precisando tomar café da manhã.

Lydia riu mais do que a frase parecia exigir.

#### Dois O suficiente para hoje

O maná veio com instruções para a coleta. Era preciso água. O conselho de Jetro ajudou Moisés a dividir a responsabilidade em vez de ouvir sozinho todas as disputas.

Lydia fechou a Bíblia.

— Eu tenho tratado o fato de ser a pessoa para quem todo mundo liga como prova de que estou vivendo direito.

— Você faz isso bem — disse Anna.

— Eu sei. Foi assim que me escondi da pergunta.

Ela abriu a Bíblia de novo.

No Sinai vieram a aliança e os mandamentos. Depois vieram o bezerro de ouro, as tábuas quebradas, a intercessão e a renovação da aliança. As pessoas que tinham recebido uma instrução clara ainda precisavam prestar contas e recomeçar.

Chegaram ao tabernáculo e se demoraram nas habilidades: tecer, entalhar, unir, projetar, fazer. A adoração exigia mãos, além de palavras.

Beth desdobrou o pano do armário. Ele tinha cinco bolsos.

Um guardava um pequeno esquadro de carpinteiro. Outro, uma agulha. Os demais guardavam uma colher, um lápis e uma pedra lisa.

— Funções diferentes — disse June.

Beth encostou o esquadro na porta em miniatura.

Ela estava torta.

— E a primeira função deste aqui é admitir que alguma coisa precisa de ajuste.

#### Três As pessoas entre as linhas

Levítico fez com que diminuíssem o ritmo.

Ofertas, responsabilidades sacerdotais, regras de pureza, dias santos, restituição, terra e provisão para quem tinha pouco. Era um antigo sistema de aliança, e elas o leram dessa forma antes de fazer aplicações modernas.

Perceberam a instrução de deixar parte da colheita para o pobre e o estrangeiro.

— Dá para organizar a santidade de um jeito que deixe comida para alguém — disse Lydia.

Números contou pessoas e registrou jornadas, reclamações, rebeliões e perdas. Os espias viram a terra; o medo aumentou os obstáculos. A jumenta de Balaão viu o que Balaão não via. As filhas de Zelofeade levaram uma questão de herança à assembleia, e a lei respondeu ao caso delas.

— A pergunta tem lugar na sala — disse Anna.

Deuteronômio contou a jornada novamente. Lembre-se. Ensine. Escolha. Cuide da viúva, do órfão e do estrangeiro. Ouça as bênçãos e os avisos. Moisés viu a terra, mas morreu antes de entrar nela.

Ruth olhou para o mapa sem estrada.

— Achei que estava faltando alguma coisa.

Beth o segurou contra a porta em miniatura. Pequenos furos na moldura projetaram pontos sobre o papel.

Uma rota apareceu quando o ângulo ficou certo.

— Precisava de outra peça — disse Beth.

Lydia pegou o celular e ligou para outra mulher da igreja.

Perguntou se poderiam dividir a próxima refeição de funeral entre três casas.

A mulher concordou antes de Lydia terminar de explicar.

Por um instante, Lydia pareceu quase ofendida por o mundo ter permitido aquilo com tanta facilidade.

Então ela riu.

Na extremidade do mapa, os pontos cercavam uma coroa.

#### À mesa

Cada uma escolheu uma responsabilidade para compartilhar, ensinar ou reconsiderar. Nenhuma foi obrigada a abrir mão de uma tarefa que amava. Lydia continuou fazendo sopa. Outra pessoa recolheria a louça.

**Trilha de leitura:** Êxodo 1–40; Levítico 1–27; Números 1–36; Deuteronômio 1–34. Leis e listas continuam fazendo parte da leitura, mesmo quando a narrativa lhes dá uma aplicação em escala humana.

---

## LIVRO TRÊS

### A coroa e a mesa da cozinha

#### Um Um nome na margem

A coroa marcava um retrato no álbum de fotografias mais antigo da igreja.

A avó de Ruth estava ao lado de uma mesa, com uma coroa de papel na mão. Atrás dela, o rosto de uma mulher tinha sido recortado da fotografia.

Anna não disse escândalo. Disse:

— Precisamos de outra cópia.

Enquanto procuravam, June abriu Josué.

A travessia do Jordão. Raabe abrigando os espias. Jericó. O que Acã tomou às escondidas e suas consequências. A divisão da terra. A renovação da aliança.

Elas não transformaram os relatos de conquista em instruções para atacar os vizinhos de hoje. A violência continuou visível; as personagens perguntaram o que os textos apresentavam sobre lealdade, julgamento e responsabilidade, e em quais pontos a aplicação moderna exigia cuidado.

Juízes trazia ciclos de falha e resgate. Débora julgou. Gideão duvidou e agiu. O voto de Jefté devastou sua filha. A força de Sansão não garantia bom discernimento. Os capítulos finais trouxeram abusos e um conflito civil tão graves que Ruth parou de ler em voz alta.

— Podemos fazer uma pausa — disse June.

O ato de esperança daquela manhã foi dar espaço às pessoas feridas na conversa, em vez de correr para um herói divertido.

Então Ruth abriu o livro que levava seu próprio nome.

Noemi perdeu o marido e os filhos. Rute ficou com ela. Um campo ofereceu espigas para recolher; Boaz ofereceu proteção e agiu dentro dos acordos da comunidade. Depois vieram o casamento e uma criança.

— A aldeia inteira importa — disse Lydia. — Comida. Segurança. Testemunhas.

Beth apontou para a fotografia recortada.

— Então vamos encontrar a mulher que a foto da aldeia perdeu.

#### Dois A coroa tem uma função

Primeiro Samuel começou com a angústia e a oração de Ana, e com o nascimento de Samuel. Samuel ouviu um chamado. Israel pediu um rei. Saul recebeu autoridade e acabou perdendo o futuro de sua dinastia por desobediência. Davi entrou no relato como um jovem pastor e se tornou fugitivo antes de virar rei.

Segundo Samuel não deixou a coroa proteger Davi da verdade sobre Bate-Seba e Urias. Natã o confrontou. As feridas posteriores da família incluíram o estupro de Tamar, a morte de Amnom e a revolta de Absalão.

— Um título não resolve a questão — disse Anna. — O que a pessoa fez com o poder?

Reis trouxe a sabedoria, o templo, a riqueza e as lealdades divididas de Salomão; o reino dividido; profetas confrontando governantes; o desafio e a fuga de Elias; o ministério de Eliseu; golpes, injustiça, reforma e colapso.

O azeite da viúva interessou a Lydia. A jovem serva sem nome que indicou ajuda a Naamã também.

Crônicas voltou aos antepassados, a Davi, à organização do templo e aos reis de Judá.

— Outra forma de contar — disse June. — Precisamos perceber o que ela escolhe destacar.

Beth encontrou a placa de suporte da coroa em um baú. Nela, a avó de Ruth tinha escrito três títulos:

**ATRIBUTOS. CARACTERÍSTICAS. FUNCIONALIDADES.**

Embaixo:

**O que está presente? O que continua acontecendo? O que isso faz?**

Ruth colocou a coroa de papel da avó sobre a mesa.

Ela parecia surpreendentemente pequena.

#### Três A fotografia recuperada

Esdras e Neemias trouxeram retorno, reconstrução, adoração, lei, oposição e decisões difíceis sobre os limites da comunidade. Algumas decisões atingiram famílias dolorosamente. As mulheres discutiram esses custos junto com a restauração.

Ester trouxe um povo ameaçado, uma rainha com acesso ao poder, o apelo de Mordecai, um risco, banquetes preparados, uma trama revelada e uma libertação seguida de violência.

— Ela usou o acesso que tinha — disse Anna. — Também se preparou. A coragem tinha calendário.

June chegou na semana seguinte com outra cópia da fotografia.

A mulher que faltava se chamava Ellen. Uma anotação no verso a identificava como a pessoa que tinha pintado os cenários das aulas bíblicas.

Ruth se lembrava dela agora. Depois que Ellen se mudou, o álbum tinha sido danificado pela água. Alguém havia recortado a parte deformada em vez de substituir a fotografia inteira.

Não tinha havido conspiração.

Tinha havido um nome perdido.

Anna digitalizou a cópia completa. Escreveu o nome de Ellen embaixo da imagem restaurada, ao lado dos nomes já conhecidos.

— Estávamos prontas para atribuir um motivo antes de ter uma segunda fotografia — disse ela.

June sorriu.

— É útil perceber quando estamos fazendo isso.

O cenário pintado por Ellen tinha cinco janelas. Uma estava aberta.

Através dela, alguém havia pintado uma cadeira e um livro.

Na lombada do livro:

**JÓ.**

#### À mesa

Elas perguntaram quem havia realizado uma tarefa útil sem receber reconhecimento. Acrescentaram os nomes que conseguiram verificar. Onde não conseguiram, deixaram o espaço honestamente em branco.

**Trilha de leitura:** Josué; Juízes; Rute; 1–2 Samuel; 1–2 Reis; 1–2 Crônicas; Esdras; Neemias; Ester, na íntegra.

---

## LIVRO QUATRO

### A pergunta e o silêncio

#### Um A cadeira ao lado da cama

Ruth faltou à reunião seguinte porque a irmã de June estava no hospital.

Não houve busca por pistas naquela noite. Houve uma cadeira ao lado de uma cama e uma longa conversa sobre coisas comuns.

Depois, June admitiu que tinha ficado com medo de que devesse dizer alguma coisa melhor.

— Você ficou — disse Ruth.

Quando voltaram a Jó, as perdas do início pareceram diferentes. Jó perdeu bens, filhos e saúde. Seus amigos chegaram e, primeiro, se sentaram em silêncio. Mais tarde, ofereceram explicações que tratavam o sofrimento como prova contra ele.

Jó discutiu. Lamentou. Queria uma resposta.

As mulheres leram as cenas celestiais, os argumentos, os discursos de Eliú, a resposta divina e a conclusão sem reduzir tudo à opinião de um único interlocutor. Perceberam que Jó 42:7 repreendia o que os amigos tinham dito sobre Deus.

A restauração veio depois. June manteve um dedo nas perdas anteriores.

— Um amor novo não apaga as pessoas que morreram.

Ruth assentiu.

Ninguém melhorou a frase.

#### Dois O hinário sem capa

Salmos lhes deu louvor, queixa, confissão, confiança, raiva, gratidão e espera sem resposta.

— Temos cantado mais os de confiança — disse Lydia.

Leram o Salmo 13. Depois o Salmo 23. Depois o Salmo 88, que não terminava com a resolução emocional que esperavam.

June escreveu uma pergunta no caderno.

**Posso falar com honestidade antes de me sentir melhor?**

Provérbios trouxe observações sobre fala, trabalho, generosidade, raiva, disciplina, julgamento e sabedoria. Anna comparou provérbios que tratavam de situações diferentes.

— A circunstância importa — disse ela. — Uma frase sábia ainda precisa de alguém lendo com atenção.

Chegaram a Provérbios 23:7 e leram o aviso ao redor dele sobre um anfitrião cuja generosidade aparente escondia um coração calculista. A frase sobre pensar no próprio coração tinha uma cena específica à sua volta; elas podiam discutir pensamento e identidade sem fazer aquela cena desaparecer.

Eclesiastes permitiu que examinassem trabalho, prazer, mortalidade, limites, injustiça, companhia e estações da vida. Suas perguntas não cabiam em um cartão-postal alegre.

Ruth olhou para o jardim.

— Minha avó plantou aquela pereira. Nunca provou uma pera dela.

— Você provou — disse Anna.

Ruth sorriu.

— Sim.

#### Três Amor com as luzes acesas

Cantares de Salomão surpreendeu a mesa, levando primeiro ao silêncio, depois ao riso e depois a uma conversa sobre afeto que ninguém esperava ter enquanto comia pãezinhos.

Elas leram sua poesia como poesia, com imagens, desejo, beleza e prazer mútuo. June explicou que leitores religiosos também a tinham abordado de forma alegórica. Aquelas eram tradições interpretativas; as imagens na página ainda mereciam atenção.

Beth encontrou uma fita escondida atrás da encadernação da Bíblia da família. Letras minúsculas bordadas percorriam a fita.

**Você pode ler a frase inteira.**

— Isso parece menos dramático do que uma passagem secreta — disse Lydia.

— Depende da frase — respondeu Beth.

Ruth se lembrou de ouvir que devia ter alegria em toda circunstância. Amara a palavra e às vezes a usara para se apressar a passar pelo luto.

Naquela noite, ligou para June depois da visita ao hospital.

— Como você está?

— Cansada. Triste. Feliz porque você ligou.

As três coisas cabiam na resposta.

A fita terminava numa pequena janela bordada. Anna a relacionou com a pintura de Ellen. Ao longo do peitoril pintado, quase escondida debaixo da moldura, havia uma referência de versículo.

**ISAÍAS 1.**

Elas tinham chegado à janela do vigia.

#### À mesa

Cada mulher escolheu um salmo que combinava com o que realmente sentia. Qualquer uma podia guardar sua escolha para si. Elas deixaram a oração ser verdadeira antes de pedir que fosse eloquente.

**Trilha de leitura:** Jó; Salmos; Provérbios; Eclesiastes; Cantares de Salomão, na íntegra. As aplicações das personagens não prometem que mudar uma interpretação cure instantaneamente uma doença ou o luto.

---

## LIVRO CINCO

### O vigia e a janela

#### Um O que a janela mostra

A janela na pintura de Ellen dava para o estacionamento da igreja.

Pela janela de verdade, Lydia conseguia ver o lugar onde uma visitante tinha esperado, certa vez, que alguém a ajudasse a levar as compras até o carro.

Lydia estava ocupada demais arrumando flores para perceber.

Isaías confrontava a injustiça e a prática religiosa vazia. Suas visões também falavam de consolo, restauração, um servo e um futuro mais amplo do que a crise imediata.

Jeremias advertia em meio à resistência e ao desastre. Lamentações chorava por Jerusalém em vez de enfeitar sua destruição. Ezequiel trazia visões, responsabilidade, julgamento, restauração e ossos secos recebendo vida.

— Podemos gostar da imagem impressionante e não enxergar as pessoas ao redor dela — disse Anna.

Daniel colocava pessoas fiéis em cortes imperiais: decisões sobre alimentação, sonhos, uma fornalha, uma cova de leões e visões de reinos. As mulheres distinguiram os cenários dos relatos de cada cronologia moderna proposta.

— Uma semelhança é motivo para examinar alguma coisa — disse Beth. — Ainda precisamos de evidências antes de anunciar uma correspondência.

Ela escreveu isso embaixo dos três títulos da coroa.

#### Dois Os livros pequenos com perguntas grandes

Oseias trouxe a traição à aliança e as difíceis imagens do casamento pelas quais o livro a expressava. Joel trouxe devastação, arrependimento e um derramamento prometido. Amós confrontou a exploração e a adoração desligada da justiça.

Obadias condenou a conduta de Edom diante de um vizinho em aflição. Jonas resistiu a uma missão, sobreviveu ao mar e ao peixe, pregou em Nínive e se ressentiu da misericórdia.

Ruth fechou os olhos por um instante.

— Eu já fui Jonas depois que a planta morreu — disse ela. — Irritada porque outra pessoa recebeu bondade.

Miqueias trouxe justiça, misericórdia e humildade à vista. Naum anunciou a queda de Nínive. Habacuque questionou a injustiça e enfrentou uma resposta difícil. Sofonias advertiu sobre o julgamento e antecipou a restauração.

Ageu tratou de reconstrução e prioridades. Zacarias trouxe visões, encorajamento e esperança futura. Malaquias confrontou falhas na adoração, na fidelidade e na justiça, terminando com uma promessa voltada para o futuro.

Elas ouviram livros distintos, com preocupações distintas. O chamado repetido para prestar atenção aos vizinhos ficou mais claro porque elas permaneceram atentas às diferenças.

Lydia colocou a ajuda com as compras dos visitantes na pauta da reunião seguinte da igreja.

— Precisamos de voluntários na porta — disse ela. — E de um jeito de perguntar que ajuda a pessoa quer.

#### Três O aviso que se abria para fora

Havia um compartimento estreito atrás da moldura da janela. Beth o encontrou ao verificar um parafuso frouxo.

Dentro estavam um boletim da igreja e um esboço do batistério.

O boletim anunciava uma antiga exposição bíblica chamada **O Piscar de Olhos**. Ruth reconheceu a data. Ela tinha ajudado a lavar as xícaras depois.

— Agora me lembro do olho — disse. — Fazia parte da última instalação.

O propósito da exposição estava escrito embaixo do título:

**Leia o que veio antes. Leia o que vem depois. Deixe a passagem inteira falar.**

Anna abriu uma coleção digital de manuscritos antigos. Elas olharam páginas e fragmentos preservados, percebendo quanto trabalho cuidadoso havia entre um objeto escrito antigo e uma transcrição legível.

Nenhum fragmento dizia tudo o que elas desejassem que dissesse. Nenhuma lacuna autorizava a invenção de uma frase ausente.

June abriu a KJV na referência final da exposição: 1 Coríntios 15.

— Começamos com meia linha — disse ela.

— E herdamos parte do sentimento ao redor dela — disse Lydia.

O esboço marcava um armário elétrico, mas a chave do armário estava faltando.

No verso do boletim, Ellen havia desenhado uma mesa com um lugar a mais.

Naquele lugar, tinha escrito:

**VENHA E VEJA.**

#### À mesa

Elas escolheram uma prática que a igreja podia melhorar e identificaram quem se beneficiaria. A primeira resposta veio da própria visitante: um caminho livre, uma mão oferecida e permissão para recusar ajuda.

**Trilha de leitura:** Isaías; Jeremias; Lamentações; Ezequiel; Daniel; Oseias; Joel; Amós; Obadias; Jonas; Miqueias; Naum; Habacuque; Sofonias; Ageu; Zacarias; Malaquias, na íntegra.

---

## LIVRO SEIS

### A mesa e o túmulo vazio

#### Um Um lugar já preparado

June convidou uma pessoa da igreja metodista e uma amiga da congregação presbiteriana para jantar. Ruth se preocupou com os pãezinhos antes de pensar em se preocupar com as diferenças entre as denominações.

As recém-chegadas reconheceram mais coisas naquela noite do que qualquer uma esperava: o prato levado como presente, a Bíblia herdada, a preocupação em garantir que todos tivessem o suficiente, a pessoa que começava a recolher os pratos antes de terminar a própria refeição.

Elas abriram Mateus e Lucas e compararam as narrativas do nascimento sem fingir que eram organizadas de forma idêntica. Maria recebeu um anúncio. José enfrentou uma decisão. Isabel acolheu Maria. Pastores vieram em Lucas; magos apareceram em Mateus. A violência de Herodes e a fuga para o Egito permaneceram no relato de Mateus.

Elas não construíram uma data moderna exata de nascimento a partir de detalhes que não forneciam uma.

Marcos avançava rapidamente para o ministério de Jesus. João começava com o Verbo e trazia sua própria organização de sinais e conversas.

— Quatro testemunhas na nossa leitura — disse Anna. — Precisamos ouvir cada uma antes de juntá-las.

Beth viu alguém estender a mão automaticamente para o prato de Ruth.

— Ela ainda está comendo — disse com delicadeza.

A mão parou. O prato ficou.

#### Dois Quem está à beira da estrada

Elas acompanharam Jesus pelo batismo, pela tentação, pelo ensino, pelas curas, pelos chamados, pelas discordâncias e pelas refeições.

Pessoas se aproximavam com necessidades. Outras se aproximavam com perguntas. Algumas queriam testá-lo. As mulheres perceberam quantas vezes uma conversa mudava porque alguém que a multidão tratava como interrupção se tornava a pessoa a quem ele se dirigia.

A mulher samaritana teve uma conversa longa. Uma mulher tocou uma roupa. Maria ouviu; Marta trabalhou e falou. Crianças foram acolhidas. Um homem cego gritou. Zaqueu desceu de uma árvore e falou de restituição.

June contou a parábola do bom samaritano em linguagem simples: uma pessoa foi ferida, outras passaram, alguém parou, prestou cuidados, providenciou hospedagem e assumiu a responsabilidade pelo custo.

— Atributos — disse Beth.

— Características — acrescentou Anna.

Lydia pousou a colher de servir.

— Função. Ele ajudou.

Elas leram o filho pródigo e também ficaram com o irmão mais velho. O retorno era bem-vindo; o ressentimento ainda estava do lado de fora, perguntando se a generosidade era justa.

Na Transfiguração, os discípulos viram uma revelação que os relatos dos Evangelhos situavam na jornada de Jesus em direção ao sofrimento. As mulheres podiam admirar a montanha e continuar seguindo Jesus quando ele descia.

O esboço da mesa de Ellen incluía um desenho minúsculo embaixo de uma cadeira: um jumento junto ao portão de uma cidade.

Elas passaram à entrada em Jerusalém.

#### Três As mulheres no túmulo

Acompanharam a última refeição, o lavar dos pés em João, o jardim, a traição, a prisão, os julgamentos, a negação, a crucificação e o sepultamento. Não tornaram o sofrimento alegre para preservar a direção esperançosa dos livros.

Lydia se lembrou de uma amiga enlutada a quem tinham mandado se alegrar antes que alguém perguntasse se ela havia dormido.

— Vou me sentar com ela — disse. — E deixar que me conte como está sendo o dia de hoje.

Depois vieram os relatos da ressurreição. Mulheres chegaram ao túmulo. Anúncios e encontros se seguiram. Os Evangelhos contavam os acontecimentos com diferenças na seleção e nos detalhes; o grupo leu cada relato em vez de fornecer uma única transcrição inventada.

Tomé recebeu um encontro em meio à dúvida. Pedro recebeu palavras de restauração e responsabilidade. Os seguidores receberam uma missão.

Ruth leu a lição de Páscoa que tinha guardado entre os papéis da avó.

No fim havia uma anotação escrita para quem lesse com medo:

**Você pode trazer sua pergunta com você.**

Beth encontrou a chave do armário elétrico dentro da pasta da lição. Alguém a tinha usado como peso sobre um pacote de transparências.

Elas a levaram à igreja na manhã seguinte.

A porta se abriu.

Dentro havia um pequeno projetor, desligado da tomada, e uma folha de manutenção escrita à mão.

Anna leu a primeira anotação em voz alta.

— Instalação do olho. Não ligar ao circuito de iluminação do santuário.

Beth olhou para o batistério.

— Bom — disse ela. — Alguém ligou.

#### À mesa

Elas perguntaram onde podiam abrir espaço para alguém cuja voz costumava ser abafada. As respostas incluíram ouvir, devolver algo devido, oferecer ajuda prática e receber ajuda também.

**Trilha de leitura:** Mateus 1–28; Marcos 1–16; Lucas 1–24; João 1–21. Os relatos paralelos continuam podendo ser lidos individualmente. O manuscrito dramatiza respostas a eles em vez de substituir seu texto.

---

## LIVRO SETE

### A carta e a porta aberta

#### Um O circuito consertado

Beth chamou um eletricista qualificado. A igreja autorizou o conserto. O eletricista encontrou a alimentação de uma antiga instalação ligada onde não deveria estar; uma falha intermitente explicava o piscar. O slide que restara no projetor explicava o Olho.

O conserto foi comum, e todos ficaram aliviados.

A pergunta que o slide despertara continuava importante.

Atos as levou ao Pentecostes, à vida compartilhada, aos conflitos, à perseguição, à dispersão e às viagens. Viúvas precisavam de uma distribuição justa. Estêvão morreu. Filipe encontrou um viajante etíope. Saulo se tornou seguidor depois de uma campanha violenta contra a igreja. Pedro entrou na casa de Cornélio. Lídia abriu seu lar. Priscila e Áquila ajudaram Apolo a compreender com mais precisão.

— Ensinar pode incluir ser ensinada — disse June.

A reunião de Jerusalém tratou de uma discordância real sobre os crentes gentios. As viagens de Paulo incluíram igrejas, discussões, perigo, prisão e naufrágio.

As primeiras comunidades tinham dons e problemas.

Lydia encontrou conforto na combinação.

#### Dois Cartas dirigidas a pessoas

Romanos examinava pecado, fé, graça, lei, Israel e uma vida de serviço. Sua discussão sobre a autoridade governante no capítulo 13 estava ao lado de instruções sobre o amor; as mulheres não trataram uma passagem sobre autoridade pública como permissão para vingança particular.

Primeira Coríntios abordava divisão, conduta, corpos, casamento, comida, adoração, dons espirituais, amor e ressurreição. Segunda Coríntios trazia fraqueza, reconciliação, generosidade e autoridade contestada.

Gálatas questionava exigências impostas aos crentes gentios. Efésios descrevia pertencimento e uma caminhada moldada pelo evangelho. Filipenses falava de parceria, humildade, perseverança e alegria. Colossenses colocava Cristo no centro e advertia contra ensinamentos que deslocavam esse centro.

Primeira e Segunda Tessalonicenses tratavam de encorajamento, luto, expectativa e confusão sobre a vinda do Senhor. As mulheres leram as palavras de consolo junto com os avisos. Viram por que uma frase isolada podia crescer e virar uma mensagem muito mais estrondosa na memória de uma criança.

Primeira e Segunda Timóteo e Tito tratavam de ensino, cuidado, liderança, conduta e perseverança. Filemom colocava um pedido sobre Onésimo dentro de uma relação moldada pela fraternidade cristã. As mulheres nomearam a escravidão ao redor da carta, em vez de tratar um pedido bondoso como se ele apagasse a instituição.

June voltou a 2 Timóteo 2:15 e à sua frase sobre dividir corretamente a palavra da verdade.

A pergunta prática dela era simples.

— A quem isso se dirige, e o que estamos lendo?

Anna acrescentou:

— Qual é a nossa aplicação, e o que a passagem realmente disse?

#### Três O caderno com a página solta

Hebreus chamava à perseverança e examinava sacerdócio, sacrifício, aliança e fé. Tiago tornava a fé prática na conduta, na fala, na justiça e no cuidado. Primeira Pedro tratava de sofrimento e esperança. Segunda Pedro advertia sobre ensinamentos corruptos.

As cartas de João examinavam verdade, amor, comunhão e conduta. Judas advertia contra pessoas destrutivas dentro da comunidade.

Lydia chegou a Tiago 1:27 e pensou na escala das refeições, nas compras e nas pessoas esperando uma ligação depois de um funeral.

Escreveu nomes ao lado das tarefas. Também perguntou se as pessoas queriam a ajuda proposta.

June apresentou o último dos cadernos de Ellen.

Dentro, o título provisório da exposição tinha sido riscado.

**TUDO PODE TERMINAR NUM INSTANTE.**

Embaixo, outra linha:

**TUDO PODE COMEÇAR NUM INSTANTE.**

A anotação ao lado era cuidadosa.

**Uma nova escolha pode começar num momento. O trabalho dela pode levar anos.**

Ruth leu e sentiu os ombros relaxarem.

Não precisava consertar setenta e oito anos antes do jantar.

Podia pedir a Anna que ficasse enquanto ela falava sobre uma coisa.

No fim do caderno, Ellen tinha desenhado sete candelabros e o portão aberto de uma cidade.

A última leitura esperava por elas.

#### À mesa

Elas examinaram uma frase herdada, mantendo três coisas separadas: suas palavras reais, o que tinham ouvido nela e o que escolhiam fazer agora. Ninguém precisava concordar com todas as conclusões para ouvir com precisão.

**Trilha de leitura:** Atos; Romanos; 1–2 Coríntios; Gálatas; Efésios; Filipenses; Colossenses; 1–2 Tessalonicenses; 1–2 Timóteo; Tito; Filemom; Hebreus; Tiago; 1–2 Pedro; 1–3 João; Judas, na íntegra.

---

## LIVRO OITO

### O piscar de olhos e o começo

#### Um Sete cartas antes do trovão

Elas começaram Apocalipse onde Apocalipse começava: com sua saudação, visão e mensagens a sete igrejas.

June leu os nomes devagar: Éfeso, Esmirna, Pérgamo, Tiatira, Sardes, Filadélfia, Laodiceia.

Elogio e correção. Perseverança e concessões. Portas e lâmpadas. Um chamado para ouvir.

As igrejas receberam suas mensagens antes de as mulheres chegarem às visões que tinham ocupado tanto da imaginação de sua infância.

Elas acompanharam a cena do trono, o rolo, os selos, as trombetas, o conflito, as bestas, os julgamentos, a queda de Babilônia, a vitória, o julgamento final e a nova criação. As imagens eram intensas. Elas reconheceram o sofrimento representado em vez de transformar a catástrofe em entretenimento.

June trouxe três comentários que abordavam Apocalipse de maneiras diferentes. Elas compararam as leituras sem fingir que a discordância entre estudiosos provava que todas as interpretações eram igualmente sólidas, ou que a confiança tornava uma interpretação indiscutível.

— Vamos marcar primeiro o que o texto diz — disse Anna. — Depois podemos examinar o que cada pessoa acha que significa.

Ruth já tinha pensado que esse tipo de comparação enfraqueceria o grupo.

A sala ficou mais quieta e mais atenta.

#### Dois A cidade com espaço

Em Apocalipse 21 e 22, elas leram sobre um novo céu e uma nova terra, lágrimas enxugadas, o fim da morte, uma cidade, um rio e uma árvore cujas folhas serviam para curar.

Ruth olhou de novo para o primeiro desenho do jardim.

— Um jardim no começo — disse ela.

— E essas imagens no fim — respondeu Anna.

Colocaram as oito pistas sobre a mesa: o jardim, a porta, a coroa, a cadeira, a janela, a mesa, a carta e o portão da cidade.

Os versos formavam uma folha grande. Ellen tinha desenhado uma sala e depois a dividido em oito partes para as lições da exposição.

Cinco cadeiras cercavam uma mesa.

No centro havia uma Bíblia aberta.

O Olho tinha sido uma instalação sobre leitura. O versículo se tornara uma questão de família por causa do que cada mulher levara para a sala.

— Eu ouvi pressa — disse Lydia.

— Eu ouvi perda — disse Ruth.

— Eu ouvi um enigma — disse Beth.

June olhou para Anna.

— Eu ouvi as palavras que faltavam — respondeu Anna.

Elas abriram 1 Coríntios 15 de novo. A passagem falava de ressurreição, transformação, vitória sobre a morte e trabalho constante. O piscar de olhos fazia parte daquele argumento. Não tinha sido escrito como instrução para uma criança permanecer aterrorizada com todo som repentino.

Ruth leu a linha sobre sermos transformados.

Depois continuou a leitura.

#### Três A frase inteira

As mulheres organizaram uma nova exposição na igreja. O projetor consertado ficou separado das luzes do santuário. Beth verificou a acessibilidade do percurso por todas as instalações.

Deram a ela o nome de **O PISCAR DE OLHOS**.

Em cada estação havia uma passagem para ler, um relato em linguagem simples e espaço para registrar uma pergunta. Os objetos históricos apareciam em fotografias com identificação das fontes. O mistério da família inventada estava identificado como ficção. As próprias lembranças eram oferecidas como lembranças.

Ninguém precisava abrir mão da fé para entrar.

Ninguém tinha de revelar uma dor íntima para completar o percurso.

Uma mulher mais velha ficou muito tempo na instalação da cadeira. Uma mulher mais nova leu o capítulo inteiro por trás do Olho. Dois homens discutiram alegremente as dimensões da porta em miniatura antes de notar a passagem ao lado.

Lydia se sentou para comer enquanto ainda havia comida.

Ruth olhou para ela e sorriu.

June estava junto à mesa final. Uma visitante perguntou se precisava vir em grupo.

— Você pode ler sozinha — disse ela. — Pode trazer a família. Amigos. Uma turma. As cinco perguntas cabem em volta de qualquer mesa.

Ela apontou para o caderno:

**Do que eu me lembro?**

**Que pergunta estou carregando?**

**Que padrão percebo?**

**Quem é afetado?**

**O que eu poderia fazer a seguir?**

A visitante se sentou.

Ruth colocou a Bíblia da avó no centro, aberta em vez de fechada.

Naquela noite, ela e Anna revisaram o álbum de fotografias. Acrescentaram nomes, corrigiram uma data e deixaram uma informação incerta marcada como incerta.

Trabalho comum.

Trabalho útil.

Anna perguntou o que Ruth queria escrever no fim da nova página.

Ruth pensou por um momento.

Então escreveu:

**TUDO PODE COMEÇAR NUM INSTANTE.**

Embaixo:

**Amanhã vou pedir ajuda antes de ficar esgotada.**

Anna acrescentou a própria frase.

Beth já tinha organizado a reunião seguinte. June levaria as perguntas. Lydia levaria sopa, porque queria.

Lá fora, o anoitecer pousava sobre as janelas da igreja. Lá dentro, cinco mulheres continuavam conversando.

O momento seguinte pertencia a elas.

#### À mesa

Escolha uma próxima ação pequena o bastante para nomear e real o bastante para fazer. Um começo pode ser uma conversa, um limite, uma ligação retornada, uma refeição, uma suposição corrigida ou uma consulta para receber ajuda. Ele não precisa apagar o passado para mudar o que acontece a seguir.

**Trilha de leitura:** Apocalipse 1–22; depois, 1 Coríntios 15 na íntegra. A inversão final da narrativa é uma aplicação sobre um começo, não uma tradução substituta de nenhuma das passagens.

---

