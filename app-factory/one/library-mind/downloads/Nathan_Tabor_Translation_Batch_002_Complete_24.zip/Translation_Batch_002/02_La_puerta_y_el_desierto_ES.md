# LIBRO DOS

## La puerta y el desierto

### Uno El armario cerrado

La llave abrió un armario del antiguo salón de clases, detrás del salón de reuniones.

Dentro había una puerta en miniatura con un hilo rojo sujeto en la parte superior, una cesta, un paño doblado y un mapa sin ningún camino señalado.

—¿Tu abuela usaba estas cosas para enseñar? —preguntó Beth.

—Cuando yo era pequeña —dijo Ruth—. Recuerdo la cesta.

Abrieron Éxodo.

Antes de que Moisés se presentara ante el faraón, las mujeres ya estaban actuando: unas parteras resistieron una orden asesina; una madre escondió a su bebé; una hermana vigiló; la hija del faraón acogió al niño.

—Todo el mundo recuerda al hombre del bastón —dijo Lydia.

June tocó la cesta.

—Lean quién lo ayudó a vivir lo suficiente para sostenerlo.

Moisés huyó después de matar a un egipcio. Años más tarde, la zarza ardiente lo llamó de regreso. Él protestó por su falta de capacidad. Aarón se unió a él. El enfrentamiento trajo plagas, Pascua, partida y el cruce del mar.

Nombraron la liberación y las muertes. La alegría por quienes escapaban de la esclavitud no exigía fingir que el relato carecía de dolor.

Junto al mar, Miriam cantó.

En el desierto, el pueblo se quejó.

Beth se recostó.

—La libertad te saca del lugar de antes. Todavía te deja necesitando desayunar.

Lydia se rio más de lo que la frase parecía justificar.

### Dos Suficiente para hoy

El maná llegó con instrucciones sobre cómo recogerlo. Hacía falta agua. El consejo de Jetro ayudó a Moisés a compartir la responsabilidad en vez de atender él solo todas las disputas.

Lydia cerró la Biblia.

—He tratado el hecho de ser la persona a la que todos llaman como prueba de que estoy viviendo correctamente.

—Se te da bien —dijo Anna.

—Lo sé. Así fue como me escondí de la pregunta.

Volvió a abrirla.

En el Sinaí llegaron el pacto y los mandamientos. Después vinieron el becerro de oro, las tablas rotas, la intercesión y la renovación del pacto. Quienes habían recibido una instrucción clara seguían necesitando rendir cuentas y comenzar de nuevo.

Llegaron al tabernáculo y se detuvieron en las habilidades: tejer, tallar, ensamblar, diseñar, construir. La adoración requería manos además de palabras.

Beth desdobló el paño del armario. Tenía cinco bolsillos.

Uno contenía una pequeña escuadra de carpintero. Otro, una aguja. Los demás contenían una cuchara, un lápiz y una piedra lisa.

—Funciones diferentes —dijo June.

Beth apoyó la escuadra contra la puerta en miniatura.

Estaba torcida.

—Y la primera función de esta es admitir que algo necesita un ajuste.

### Tres Las personas entre las líneas

Levítico las hizo avanzar más despacio.

Ofrendas, responsabilidades sacerdotales, normas de pureza, días sagrados, restitución, tierras y provisiones para quienes tenían poco. Era un antiguo sistema de pacto, y lo leyeron como tal antes de buscar aplicaciones modernas.

Se fijaron en la instrucción de dejar parte de la cosecha para el pobre y el extranjero.

—Se puede organizar la santidad de una manera que deje comida para alguien —dijo Lydia.

Números contó personas y registró viajes, quejas, rebeliones y pérdidas. Los exploradores vieron la tierra; el miedo agrandó los obstáculos. La burra de Balaam vio lo que Balaam no veía. Las hijas de Zelofehad llevaron una pregunta sobre la herencia ante la asamblea, y la ley respondió a su caso.

—La pregunta tiene un lugar en la sala —dijo Anna.

Deuteronomio volvió a contar el viaje. Recuerda. Enseña. Elige. Cuida de la viuda, del huérfano y del extranjero. Escucha las bendiciones y las advertencias. Moisés vio la tierra, pero murió antes de entrar en ella.

Ruth miró el mapa sin camino.

—Pensé que le faltaba algo.

Beth lo sostuvo contra la puerta en miniatura. Unos agujeros pequeños en el marco proyectaron puntos sobre el papel.

Cuando el ángulo fue el correcto, apareció una ruta.

—Necesitaba otra pieza —dijo Beth.

Lydia sacó el teléfono y llamó a otra mujer de la iglesia.

Le preguntó si podían repartir la siguiente comida de funeral entre tres hogares.

La mujer aceptó antes de que Lydia terminara de explicarlo.

Por un momento, Lydia pareció casi ofendida de que el mundo hubiera permitido aquello con tanta facilidad.

Después se rio.

En el extremo del mapa, los puntos rodeaban una corona.

### En la mesa

Cada una eligió una responsabilidad para compartir, enseñar o reconsiderar. Ninguna tuvo que renunciar a una tarea que amaba. Lydia siguió preparando sopa. Otra persona recogería los platos.

**Ruta de lectura:** Éxodo 1–40; Levítico 1–27; Números 1–36; Deuteronomio 1–34. Las leyes y las listas siguen formando parte de la lectura, aun cuando la narración les da una aplicación a escala humana.
