# LIBRO CUATRO

## La pregunta y el silencio

### Uno La silla junto a la cama

Ruth faltó a la siguiente reunión porque la hermana de June estaba en el hospital.

Aquella tarde no hubo búsqueda de pistas. Hubo una silla junto a una cama y una larga conversación sobre cosas corrientes.

Después, June admitió que había tenido miedo de que le correspondiera decir algo mejor.

—Te quedaste —dijo Ruth.

Cuando volvieron a Job, las pérdidas del comienzo se sintieron diferentes. Job perdió posesiones, hijos y salud. Sus amigos llegaron y al principio se sentaron en silencio. Más tarde ofrecieron explicaciones que trataban el sufrimiento como prueba en su contra.

Job discutió. Se lamentó. Quería una respuesta.

Las mujeres leyeron las escenas celestiales, las discusiones, los discursos de Eliú, la respuesta divina y la conclusión sin reducirlos a la opinión de una sola voz. Se fijaron en Job 42:7, donde se reprendía a los amigos por lo que habían dicho acerca de Dios.

Después llegó la restauración. June mantuvo un dedo sobre las pérdidas anteriores.

—El amor nuevo no borra a las personas que murieron.

Ruth asintió.

Nadie mejoró la frase.

### Dos El himnario sin tapa

Salmos les dio alabanza, queja, confesión, confianza, ira, agradecimiento y una espera sin respuesta.

—Hemos cantado más a menudo los de confianza —dijo Lydia.

Leyeron el Salmo 13. Después el Salmo 23. Después el Salmo 88, que no terminaba con la resolución emocional que esperaban.

June escribió una pregunta en su cuaderno.

**¿Puedo hablar con honestidad antes de sentirme mejor?**

Proverbios ofreció observaciones sobre el habla, el trabajo, la generosidad, la ira, la disciplina, el juicio y la sabiduría. Anna comparó proverbios que abordaban situaciones diferentes.

—Las circunstancias importan —dijo—. Una frase sabia sigue necesitando a alguien que la lea con atención.

Llegaron a Proverbios 23:7 y leyeron la advertencia que lo rodeaba, sobre un anfitrión cuya generosidad aparente ocultaba un corazón calculador. La frase sobre pensar en el corazón tenía una escena concreta a su alrededor; podían hablar del pensamiento y la identidad sin hacer desaparecer esa escena.

Eclesiastés les permitió examinar el trabajo, el placer, la mortalidad, los límites, la injusticia, la compañía y los tiempos de la vida. Sus preguntas no cabían en una postal alegre.

Ruth miró hacia el jardín.

—Mi abuela plantó ese peral. Nunca probó una pera de él.

—Tú sí —dijo Anna.

Ruth sonrió.

—Sí.

### Tres El amor con las luces encendidas

Cantar de los Cantares sorprendió a la mesa y la llevó al silencio, después a la risa y después a una conversación sobre el afecto que ninguna había esperado tener mientras comía panecillos.

Leyeron su poesía como poesía, con imágenes, anhelo, belleza y deleite mutuo. June explicó que los lectores religiosos también la habían abordado de manera alegórica. Esas eran tradiciones interpretativas; las imágenes de la página seguían mereciendo atención.

Beth encontró una cinta escondida detrás de la encuadernación de la Biblia familiar. La recorrían unas letras diminutas bordadas.

**Puedes leer la frase completa.**

—Eso parece menos dramático que un pasadizo secreto —dijo Lydia.

—Depende de la frase —respondió Beth.

Ruth recordó que le habían dicho que debía sentir gozo en toda circunstancia. Había amado la palabra y a veces la había usado para apresurarse a dejar atrás el dolor.

Aquella noche llamó a June después de la visita al hospital.

—¿Cómo estás?

—Cansada. Triste. Contentísima de que hayas llamado.

Las tres cosas tenían lugar en la respuesta.

La cinta terminaba en una ventanita bordada. Anna la relacionó con el cuadro de Ellen. En el alféizar pintado, casi oculta bajo el marco, había una referencia a un versículo.

**ISAÍAS 1.**

Habían llegado a la ventana del vigía.

### En la mesa

Cada mujer eligió un salmo que coincidía con lo que sentía de verdad. Cualquiera podía guardar su elección para sí. Dejaron que una oración fuera sincera antes de pedirle que fuera elocuente.

**Ruta de lectura:** Job; Salmos; Proverbios; Eclesiastés; Cantar de los Cantares, completos. Las aplicaciones de los personajes no prometen que un cambio de interpretación cure al instante la enfermedad o el duelo.
