# LIVRE TROIS

## La couronne et la table de cuisine

### Un Un nom dans la marge

La couronne indiquait un portrait dans le plus ancien album de photos de l’église.

La grand-mère de Ruth se tenait près d’une table, une couronne de papier à la main. Derrière elle, le visage d’une femme avait été découpé de la photographie.

Anna ne dit pas scandale. Elle dit :

— Il nous faut un autre exemplaire.

Pendant qu’elles cherchaient, June ouvrit Josué.

La traversée du Jourdain. Rahab abritant les espions. Jéricho. Ce qu’Acan avait pris en secret et les conséquences de son acte. Le partage du pays. L’alliance renouvelée.

Elles ne transformèrent pas les récits de conquête en consignes pour attaquer les voisins d’aujourd’hui. La violence resta visible ; les personnages se demandèrent ce que les textes présentaient au sujet de l’allégeance, du jugement et de la responsabilité, et à quels endroits une application moderne demandait de la prudence.

Les Juges portaient des cycles de défaillance et de délivrance. Débora jugea. Gédéon douta et agit. Le vœu de Jephté dévasta sa fille. La force de Samson ne garantissait pas un jugement sûr. Les derniers chapitres décrivaient des sévices et un conflit civil si graves que Ruth cessa de lire à voix haute.

— On peut prendre une minute, dit June.

Ce matin-là, l’acte porteur d’espoir consistait à faire une place aux personnes blessées dans la discussion, au lieu de se précipiter vers un héros divertissant.

Puis Ruth ouvrit le livre qui portait son nom.

Naomi perdit son mari et ses fils. Ruth resta auprès d’elle. Un champ offrit la possibilité de glaner ; Boaz offrit sa protection et agit dans le cadre des dispositions de la communauté. Un mariage et un enfant suivirent.

— Tout le village compte, dit Lydia. La nourriture. La sécurité. Les témoins.

Beth désigna la photographie découpée.

— Alors retrouvons la femme que la photo du village a perdue.

### Deux La couronne a un travail à faire

Le premier livre de Samuel commençait par la détresse et la prière d’Anne, puis par la naissance de Samuel. Samuel entendit un appel. Israël demanda un roi. Saül reçut l’autorité et finit par perdre, par désobéissance, l’avenir de sa dynastie. David entra dans le récit comme un jeune berger et devint un fugitif avant de devenir roi.

Le deuxième livre de Samuel ne laissa pas la couronne protéger David de la vérité sur Bath-Schéba et Urie. Nathan le confronta. Parmi les blessures qui atteignirent ensuite la maison figurèrent le viol de Tamar, la mort d’Amnon et la révolte d’Absalom.

— Un titre ne règle pas la question, dit Anna. Qu’est-ce que la personne a fait de son pouvoir ?

Les Rois apportaient la sagesse, le temple, la richesse et les fidélités partagées de Salomon ; le royaume divisé ; les prophètes affrontant les souverains ; le défi d’Élie et sa fuite ; le ministère d’Élisée ; les coups d’État, l’injustice, les réformes et l’effondrement.

L’huile de la veuve intéressa Lydia. La jeune servante sans nom qui orienta Naaman vers de l’aide aussi.

Les Chroniques revenaient sur les ancêtres, David, l’organisation du temple et les rois de Juda.

— Un autre récit, dit June. Nous devrions remarquer ce qu’il choisit de souligner.

Beth trouva le panneau qui soutenait la couronne dans une malle de rangement. La grand-mère de Ruth y avait écrit trois titres :

**ATTRIBUTS. CARACTÉRISTIQUES. FONCTIONNALITÉS.**

En dessous :

**Qu’est-ce qui est présent ? Qu’est-ce qui se répète ? Qu’est-ce que cela fait ?**

Ruth posa la couronne de papier de sa grand-mère sur la table.

Elle paraissait étonnamment petite.

### Trois La photographie retrouvée

Esdras et Néhémie apportaient le retour, la reconstruction, le culte, la loi, l’opposition et des décisions difficiles sur les limites de la communauté. Certaines décisions affectaient douloureusement des familles. Les femmes discutèrent de ces coûts en même temps que de la restauration.

Esther apportait un peuple menacé, une reine ayant accès au pouvoir, l’appel de Mardochée, un risque, des banquets préparés, un complot dévoilé et une délivrance suivie de violence.

— Elle a utilisé l’accès qu’elle avait, dit Anna. Elle s’est préparée aussi. Le courage avait un calendrier.

June arriva la semaine suivante avec un autre exemplaire de la photographie.

La femme manquante s’appelait Ellen. Une note au dos l’identifiait comme la personne qui avait peint les décors des leçons bibliques.

Ruth se souvenait maintenant d’elle. Après le déménagement d’Ellen, l’album avait été endommagé par l’eau. Quelqu’un avait découpé la partie gondolée au lieu de remplacer toute l’image.

Il n’y avait pas eu de complot.

Il y avait eu un nom perdu.

Anna numérisa l’exemplaire complet. Elle écrivit le nom d’Ellen sous l’image restaurée, à côté des noms déjà connus.

— Nous étions prêtes à attribuer un motif avant d’avoir une deuxième photographie, dit-elle.

June sourit.

— C’est utile de se surprendre à faire cela.

Le décor peint par Ellen comportait cinq fenêtres. L’une était ouverte.

À travers elle, quelqu’un avait peint une chaise et un livre.

Sur le dos du livre :

**JOB.**

### À table

Elles demandèrent qui avait accompli une tâche utile sans en recevoir le mérite. Elles ajoutèrent les noms qu’elles pouvaient vérifier. Lorsqu’elles ne le pouvaient pas, elles laissèrent honnêtement l’espace vide.

**Parcours de lecture :** Josué ; Juges ; Ruth ; 1–2 Samuel ; 1–2 Rois ; 1–2 Chroniques ; Esdras ; Néhémie ; Esther, en entier.
