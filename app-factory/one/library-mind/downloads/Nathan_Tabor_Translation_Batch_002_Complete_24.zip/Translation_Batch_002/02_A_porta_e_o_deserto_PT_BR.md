# LIVRO DOIS

## A porta e o deserto

### Um O armário trancado

A chave abriu um armário na antiga sala de aula, atrás do salão de convivência.

Dentro havia uma porta em miniatura com uma linha vermelha presa na parte de cima, um cesto, um pano dobrado e um mapa sem nenhuma estrada marcada.

— Sua avó usava isso para ensinar? — perguntou Beth.

— Quando eu era pequena — disse Ruth. — Eu me lembro do cesto.

Elas abriram Êxodo.

Antes de Moisés se apresentar ao faraó, mulheres já estavam agindo: parteiras resistiram a uma ordem assassina; uma mãe escondeu seu bebê; uma irmã vigiou; a filha do faraó acolheu a criança.

— Todo mundo se lembra do homem com o cajado — disse Lydia.

June tocou o cesto.

— Leiam quem ajudou ele a viver tempo suficiente para segurá-lo.

Moisés fugiu depois de matar um egípcio. Anos mais tarde, a sarça ardente o chamou de volta. Ele protestou por não se considerar capaz. Arão se juntou a ele. O confronto trouxe pragas, Páscoa, partida e a travessia do mar.

Elas nomearam a libertação e as mortes. A alegria por quem escapava da escravidão não exigia fingir que o relato não continha tristeza.

À beira do mar, Miriã cantou.

No deserto, o povo reclamou.

Beth se recostou.

— A liberdade tira você do lugar antigo. Ainda deixa você precisando tomar café da manhã.

Lydia riu mais do que a frase parecia exigir.

### Dois O suficiente para hoje

O maná veio com instruções para a coleta. Era preciso água. O conselho de Jetro ajudou Moisés a dividir a responsabilidade em vez de ouvir sozinho todas as disputas.

Lydia fechou a Bíblia.

— Eu tenho tratado o fato de ser a pessoa para quem todo mundo liga como prova de que estou vivendo direito.

— Você faz isso bem — disse Anna.

— Eu sei. Foi assim que me escondi da pergunta.

Ela abriu a Bíblia de novo.

No Sinai vieram a aliança e os mandamentos. Depois vieram o bezerro de ouro, as tábuas quebradas, a intercessão e a renovação da aliança. As pessoas que tinham recebido uma instrução clara ainda precisavam prestar contas e recomeçar.

Chegaram ao tabernáculo e se demoraram nas habilidades: tecer, entalhar, unir, projetar, fazer. A adoração exigia mãos, além de palavras.

Beth desdobrou o pano do armário. Ele tinha cinco bolsos.

Um guardava um pequeno esquadro de carpinteiro. Outro, uma agulha. Os demais guardavam uma colher, um lápis e uma pedra lisa.

— Funções diferentes — disse June.

Beth encostou o esquadro na porta em miniatura.

Ela estava torta.

— E a primeira função deste aqui é admitir que alguma coisa precisa de ajuste.

### Três As pessoas entre as linhas

Levítico fez com que diminuíssem o ritmo.

Ofertas, responsabilidades sacerdotais, regras de pureza, dias santos, restituição, terra e provisão para quem tinha pouco. Era um antigo sistema de aliança, e elas o leram dessa forma antes de fazer aplicações modernas.

Perceberam a instrução de deixar parte da colheita para o pobre e o estrangeiro.

— Dá para organizar a santidade de um jeito que deixe comida para alguém — disse Lydia.

Números contou pessoas e registrou jornadas, reclamações, rebeliões e perdas. Os espias viram a terra; o medo aumentou os obstáculos. A jumenta de Balaão viu o que Balaão não via. As filhas de Zelofeade levaram uma questão de herança à assembleia, e a lei respondeu ao caso delas.

— A pergunta tem lugar na sala — disse Anna.

Deuteronômio contou a jornada novamente. Lembre-se. Ensine. Escolha. Cuide da viúva, do órfão e do estrangeiro. Ouça as bênçãos e os avisos. Moisés viu a terra, mas morreu antes de entrar nela.

Ruth olhou para o mapa sem estrada.

— Achei que estava faltando alguma coisa.

Beth o segurou contra a porta em miniatura. Pequenos furos na moldura projetaram pontos sobre o papel.

Uma rota apareceu quando o ângulo ficou certo.

— Precisava de outra peça — disse Beth.

Lydia pegou o celular e ligou para outra mulher da igreja.

Perguntou se poderiam dividir a próxima refeição de funeral entre três casas.

A mulher concordou antes de Lydia terminar de explicar.

Por um instante, Lydia pareceu quase ofendida por o mundo ter permitido aquilo com tanta facilidade.

Então ela riu.

Na extremidade do mapa, os pontos cercavam uma coroa.

### À mesa

Cada uma escolheu uma responsabilidade para compartilhar, ensinar ou reconsiderar. Nenhuma foi obrigada a abrir mão de uma tarefa que amava. Lydia continuou fazendo sopa. Outra pessoa recolheria a louça.

**Trilha de leitura:** Êxodo 1–40; Levítico 1–27; Números 1–36; Deuteronômio 1–34. Leis e listas continuam fazendo parte da leitura, mesmo quando a narrativa lhes dá uma aplicação em escala humana.
