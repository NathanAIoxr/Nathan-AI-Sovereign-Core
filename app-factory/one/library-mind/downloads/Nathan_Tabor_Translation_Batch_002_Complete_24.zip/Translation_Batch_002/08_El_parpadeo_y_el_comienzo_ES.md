# LIBRO OCHO

## El parpadeo y el comienzo

### Uno Siete cartas antes del trueno

Empezaron Apocalipsis donde empezaba Apocalipsis: con su saludo, su visión y sus mensajes a siete iglesias.

June leyó despacio los nombres: Éfeso, Esmirna, Pérgamo, Tiatira, Sardis, Filadelfia, Laodicea.

Elogio y corrección. Perseverancia y concesiones. Puertas y lámparas. Un llamado a escuchar.

Las iglesias recibieron sus mensajes antes de que las mujeres llegaran a las visiones que habían ocupado tanto espacio en la imaginación de su infancia.

Siguieron la escena del trono, el rollo, los sellos, las trompetas, el conflicto, las bestias, los juicios, la caída de Babilonia, la victoria, el juicio final y la nueva creación. Las imágenes eran intensas. Reconocieron el sufrimiento que representaban en vez de convertir la catástrofe en entretenimiento.

June llevó tres comentarios que abordaban Apocalipsis de maneras diferentes. Compararon las lecturas sin fingir que el desacuerdo académico demostraba que todas las interpretaciones tenían la misma solidez, o que la confianza volvía indiscutible una interpretación.

—Primero marquemos lo que dice el texto —dijo Anna—. Después podemos examinar lo que cada persona cree que significa.

Ruth había pensado antes que este tipo de comparación debilitaría a quienes estaban en la sala.

La sala se volvió más silenciosa y más atenta.

### Dos La ciudad con espacio

En Apocalipsis 21 y 22 leyeron sobre un cielo y una tierra nuevos, lágrimas enjugadas, el fin de la muerte, una ciudad, un río y un árbol cuyas hojas servían para sanar.

Ruth volvió a mirar el primer dibujo del jardín.

—Un jardín al principio —dijo.

—Y estas imágenes al final —respondió Anna.

Pusieron las ocho pistas sobre la mesa: el jardín, la puerta, la corona, la silla, la ventana, la mesa, la carta y la puerta de la ciudad.

Los reversos formaban una sola hoja grande. Ellen había dibujado una habitación y luego la había dividido en ocho piezas para las lecciones de su exposición.

Cinco sillas rodeaban una mesa.

En el centro había una Biblia abierta.

El Ojo había sido una instalación sobre la lectura. El versículo se había convertido en una pregunta familiar por lo que cada mujer había llevado consigo a la sala.

—Yo oí prisa —dijo Lydia.

—Yo oí pérdida —dijo Ruth.

—Yo oí un acertijo —dijo Beth.

June miró a Anna.

—Yo oí las palabras que faltaban —respondió Anna.

Volvieron a abrir 1 Corintios 15. El pasaje hablaba de resurrección, transformación, victoria sobre la muerte y trabajo constante. El parpadeo pertenecía a ese razonamiento. No se había escrito como una instrucción para que un niño viviera aterrorizado ante cada sonido repentino.

Ruth leyó la línea sobre ser transformados.

Después siguió leyendo.

### Tres La frase completa

Las mujeres organizaron una nueva exposición en la iglesia. El proyector reparado quedó separado de las luces del santuario. Beth revisó que el recorrido por todas las instalaciones fuera accesible.

La llamaron **EL PARPADEO**.

En cada estación había un pasaje para leer, un relato en lenguaje sencillo y un espacio para anotar una pregunta. Los objetos históricos aparecían en fotografías con etiquetas de sus fuentes. El misterio de la familia inventada estaba identificado como ficción. Sus propios recuerdos se ofrecían como recuerdos.

A nadie se le pidió renunciar a su fe para entrar.

Nadie tuvo que contar una herida privada para completar el recorrido.

Una mujer mayor se quedó mucho tiempo junto a la instalación de la silla. Una mujer más joven leyó el capítulo completo detrás del Ojo. Dos hombres discutieron alegremente sobre las dimensiones de la puerta en miniatura antes de fijarse en el pasaje de al lado.

Lydia se sentó a comer mientras todavía quedaba comida.

Ruth la miró y sonrió.

June estaba junto a la mesa final. Una visitante preguntó si tenía que venir con un grupo.

—Puedes leerlo sola —dijo—. Puedes traer a tu familia. A tus amigos. A una clase. Las cinco preguntas caben alrededor de cualquier mesa.

Señaló el cuaderno:

**¿Qué recuerdo?**

**¿Qué pregunta llevo conmigo?**

**¿Qué patrón noto?**

**¿A quién afecta?**

**¿Qué podría hacer después?**

La visitante se sentó.

Ruth puso la Biblia de su abuela en el centro, abierta en vez de cerrada.

Aquella tarde, ella y Anna revisaron el álbum de fotografías. Añadieron nombres, corrigieron una fecha y dejaron una anotación incierta marcada como incierta.

Trabajo corriente.

Trabajo útil.

Anna preguntó qué quería escribir Ruth al final de su nueva página.

Ruth pensó un momento.

Después escribió:

**TODO PUEDE COMENZAR EN UN INSTANTE.**

Debajo:

**Mañana pediré ayuda antes de quedar agotada.**

Anna añadió su propia frase.

Beth ya había organizado la siguiente reunión. June llevaría las preguntas. Lydia llevaría sopa, porque quería hacerlo.

Afuera, el atardecer se posaba sobre las ventanas de la iglesia. Adentro, cinco mujeres seguían conversando.

El siguiente momento les pertenecía.

### En la mesa

Elige una próxima acción lo bastante pequeña para nombrarla y lo bastante real para hacerla. Un comienzo puede ser una conversación, un límite, una llamada devuelta, una comida, una suposición corregida o una cita para recibir ayuda. No necesita borrar el pasado para cambiar lo que ocurre después.

**Ruta de lectura:** Apocalipsis 1–22; después, 1 Corintios 15 completo. La inversión final de la narración es una aplicación acerca de un comienzo, no una traducción sustitutiva de ninguno de los pasajes.
