# LIBRO TRES

## La corona y la mesa de la cocina

### Uno Un nombre en el margen

La corona señalaba un retrato en el álbum de fotos más antiguo de la iglesia.

La abuela de Ruth estaba junto a una mesa con una corona de papel en la mano. Detrás de ella, habían recortado de la fotografía el rostro de una mujer.

Anna no dijo escándalo. Dijo:

—Necesitamos otra copia.

Mientras buscaban, June abrió Josué.

El cruce del Jordán. Rahab dando refugio a los espías. Jericó. El robo oculto de Acán y sus consecuencias. Tierras repartidas. El pacto renovado.

No convirtieron los relatos de conquista en instrucciones para atacar a los vecinos de hoy. La violencia permaneció visible; las protagonistas preguntaron qué presentaban los textos acerca de la lealtad, el juicio y la responsabilidad, y en qué puntos una aplicación moderna exigía cuidado.

Jueces traía ciclos de fracaso y rescate. Débora juzgó. Gedeón dudó y actuó. El voto de Jefté devastó a su hija. La fuerza de Sansón no garantizó buen juicio. Los capítulos finales trajeron abusos y un conflicto civil tan graves que Ruth dejó de leer en voz alta.

—Podemos tomarnos un minuto —dijo June.

El acto esperanzador de aquella mañana fue dar espacio en la conversación a las personas dañadas, en vez de apresurarse hacia un héroe entretenido.

Entonces Ruth abrió el libro que llevaba su propio nombre.

Noemí perdió a su esposo y a sus hijos. Rut se quedó con ella. Un campo ofreció espigas para recoger; Booz ofreció protección y actuó conforme a los acuerdos de la comunidad. Después llegaron el matrimonio y un hijo.

—Todo el pueblo importa —dijo Lydia—. Comida. Seguridad. Testigos.

Beth señaló la fotografía recortada.

—Entonces encontremos a la mujer que perdió la foto del pueblo.

### Dos La corona tiene una función

Primero de Samuel empezó con la angustia y la oración de Ana, y el nacimiento de Samuel. Samuel oyó un llamado. Israel pidió un rey. Saúl recibió autoridad y acabó perdiendo, por desobediencia, el futuro de su dinastía. David entró en el relato como un joven pastor y se convirtió en fugitivo antes de ser rey.

Segundo de Samuel no permitió que la corona protegiera a David de la verdad sobre Betsabé y Urías. Natán lo enfrentó. Entre las heridas posteriores de la casa estuvieron la violación de Tamar, la muerte de Amnón y la rebelión de Absalón.

—Un título no resuelve la cuestión —dijo Anna—. ¿Qué hizo la persona con el poder?

Reyes trajo la sabiduría, el templo, la riqueza y las lealtades divididas de Salomón; el reino dividido; profetas enfrentándose a gobernantes; el desafío y la huida de Elías; el ministerio de Eliseo; golpes de Estado, injusticia, reforma y derrumbe.

El aceite de la viuda interesó a Lydia. También la muchacha sirvienta, sin nombre en el relato, que orientó a Naamán hacia la ayuda.

Crónicas volvió a los antepasados, a David, a la organización del templo y a los reyes de Judá.

—Otra manera de contarlo —dijo June—. Debemos fijarnos en lo que decide destacar.

Beth encontró el soporte de la corona en un baúl. La abuela de Ruth había escrito tres encabezados:

**ATRIBUTOS. CARACTERÍSTICAS. FUNCIONALIDADES.**

Debajo:

**¿Qué está presente? ¿Qué sigue ocurriendo? ¿Qué hace?**

Ruth puso la corona de papel de su abuela sobre la mesa.

Parecía sorprendentemente pequeña.

### Tres La fotografía recuperada

Esdras y Nehemías trajeron el regreso, la reconstrucción, la adoración, la ley, la oposición y decisiones difíciles sobre los límites de la comunidad. Algunas decisiones afectaron dolorosamente a las familias. Las mujeres hablaron de esos costos junto con la restauración.

Ester trajo un pueblo amenazado, una reina con acceso al poder, el llamado de Mardoqueo, un riesgo, banquetes preparados, una conspiración descubierta y una liberación seguida de violencia.

—Usó el acceso que tenía —dijo Anna—. También se preparó. El valor tenía un calendario.

June llegó la semana siguiente con otra copia de la fotografía.

La mujer que faltaba se llamaba Ellen. Una nota al dorso la identificaba como la persona que había pintado los decorados para las lecciones bíblicas.

Ahora Ruth la recordaba. Después de que Ellen se mudara, el agua había dañado el álbum. Alguien había recortado la parte deformada en vez de reemplazar toda la foto.

No había habido una conspiración.

Había habido un nombre perdido.

Anna escaneó la copia completa. Escribió el nombre de Ellen debajo de la imagen restaurada, junto a los nombres que ya conocían.

—Estábamos listas para atribuir un motivo antes de tener una segunda fotografía —dijo.

June sonrió.

—Es útil darnos cuenta de que estamos haciendo eso.

El fondo pintado por Ellen tenía cinco ventanas. Una estaba abierta.

A través de ella, alguien había pintado una silla y un libro.

En el lomo del libro:

**JOB.**

### En la mesa

Preguntaron quién había realizado una tarea útil sin recibir reconocimiento. Añadieron los nombres que pudieron verificar. Donde no pudieron, dejaron el espacio honestamente en blanco.

**Ruta de lectura:** Josué; Jueces; Rut; 1–2 Samuel; 1–2 Reyes; 1–2 Crónicas; Esdras; Nehemías; Ester, completos.
