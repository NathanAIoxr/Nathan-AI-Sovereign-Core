# LIVRE SEPT

## La lettre et la porte ouverte

### Un Le circuit réparé

Beth appela un électricien qualifié. L’église autorisa une réparation. L’électricien trouva l’alimentation d’une ancienne installation raccordée là où elle n’aurait pas dû l’être ; un défaut intermittent expliquait le clignotement. La diapositive restée dans le projecteur expliquait l’Œil.

La réparation fut ordinaire, et tout le monde fut soulagé.

La question éveillée par la diapositive comptait toujours.

Les Actes les conduisirent à la Pentecôte, à la vie partagée, aux conflits, à la persécution, à la dispersion et aux voyages. Les veuves avaient besoin d’une distribution équitable. Étienne mourut. Philippe rencontra un voyageur éthiopien. Saul devint un disciple après avoir mené une campagne violente contre l’église. Pierre entra dans la maison de Corneille. Lydie ouvrit son foyer. Priscille et Aquilas aidèrent Apollos à comprendre avec davantage d’exactitude.

— Enseigner peut aussi consister à recevoir un enseignement, dit June.

La réunion de Jérusalem traita d’un véritable désaccord au sujet des croyants non juifs. Les voyages de Paul comprirent des églises, des disputes, du danger, la prison et un naufrage.

Les premières communautés avaient des dons et des problèmes.

Lydia trouva du réconfort dans cette combinaison.

### Deux Des lettres adressées à des personnes

L’épître aux Romains examinait le péché, la foi, la grâce, la loi, Israël et une vie de service. Son propos sur les autorités au chapitre 13 se trouvait à côté d’instructions sur l’amour ; les femmes ne traitèrent pas un passage sur l’autorité publique comme une permission de vengeance privée.

La première épître aux Corinthiens abordait les divisions, la conduite, les corps, le mariage, la nourriture, le culte, les dons spirituels, l’amour et la résurrection. La deuxième portait la faiblesse, la réconciliation, la générosité et une autorité contestée.

L’épître aux Galates contestait les exigences imposées aux croyants non juifs. Celle aux Éphésiens décrivait l’appartenance et une marche façonnée par l’Évangile. Celle aux Philippiens parlait de collaboration, d’humilité, de persévérance et de joie. Celle aux Colossiens plaçait le Christ au centre et mettait en garde contre les enseignements qui déplaçaient ce centre.

Les deux épîtres aux Thessaloniciens abordaient l’encouragement, le deuil, l’attente et la confusion concernant la venue du Seigneur. Les femmes lurent les paroles rassurantes avec les avertissements. Elles comprirent comment une phrase isolée pouvait devenir un message beaucoup plus retentissant dans la mémoire d’un enfant.

Les deux épîtres à Timothée et celle à Tite traitaient de l’enseignement, du soin, de la direction, de la conduite et de la persévérance. Philémon plaçait une demande concernant Onésime dans une relation façonnée par la fraternité chrétienne. Les femmes nommèrent l’esclavage qui entourait la lettre au lieu de considérer une demande bienveillante comme si elle effaçait l’institution.

June revint à 2 Timothée 2:15 et à sa formule sur le fait de dispenser droitement la parole de vérité.

Sa question pratique était simple.

— À qui s’adresse-t-on, et qu’est-ce que nous lisons ?

Anna ajouta :

— Quelle application en faisons-nous, et qu’est-ce que le passage disait réellement ?

### Trois Le carnet à la page volante

L’épître aux Hébreux appelait à la persévérance et examinait le sacerdoce, le sacrifice, l’alliance et la foi. Jacques rendait la foi concrète dans la conduite, la parole, l’équité et le soin des autres. La première épître de Pierre abordait la souffrance et l’espérance. La deuxième mettait en garde contre les enseignements corrompus.

Les lettres de Jean examinaient la vérité, l’amour, la communion et la conduite. Jude mettait en garde contre des personnes destructrices au sein de la communauté.

Lydia arriva à Jacques 1:27 et pensa au roulement des repas, aux courses, aux personnes qui attendaient un appel après des obsèques.

Elle écrivit des noms à côté des tâches. Elle demanda aussi si les personnes souhaitaient l’aide proposée.

June sortit le dernier carnet d’Ellen.

À l’intérieur, le titre de travail de l’exposition avait été barré.

**TOUT PEUT FINIR EN UN INSTANT.**

En dessous, une autre ligne :

**TOUT PEUT COMMENCER EN UN INSTANT.**

La note à côté était soigneusement formulée.

**Un nouveau choix peut commencer en un instant. Le travail qu’il demande peut prendre des années.**

Ruth la lut et sentit ses épaules se détendre.

Elle n’avait pas à réparer soixante-dix-huit années avant le dîner.

Elle pouvait demander à Anna de rester pendant qu’elle parlait d’une seule chose.

À la fin du carnet, Ellen avait dessiné sept chandeliers et une porte de ville ouverte.

Leur dernière lecture les attendait.

### À table

Elles examinèrent une phrase héritée en distinguant trois choses : ses mots réels, ce qu’elles y avaient entendu et ce qu’elles choisissaient de faire maintenant. Personne n’avait besoin d’être d’accord sur toutes les conclusions pour écouter avec justesse.

**Parcours de lecture :** Actes ; Romains ; 1–2 Corinthiens ; Galates ; Éphésiens ; Philippiens ; Colossiens ; 1–2 Thessaloniciens ; 1–2 Timothée ; Tite ; Philémon ; Hébreux ; Jacques ; 1–2 Pierre ; 1–3 Jean ; Jude, en entier.
