# THE TWINKLING

## Édition française

**Par Nathan Tabor**

## LIVRE UN

### L’œil et le jardin

#### Un Le clignement

La réunion du mercredi soir était terminée, mais l’église n’avait pas encore fini d’être une église.

Quelqu’un cherchait le couvercle d’un plat à gratin. Quelqu’un rapportait un parapluie emprunté. Dans la salle paroissiale, un homme qui avait prié avec beaucoup de solennité vingt minutes plus tôt essayait de convaincre sa femme que le reste du gâteau avait besoin d’un foyer.

Ruth se tenait près du baptistère, la Bible de sa grand-mère calée contre la hanche.

— June, c’est toi qui as mis ça là ?

— Si c’est encore une tâche pour un comité, non.

Au-dessus de l’eau, un contour pâle semblait se former autour du reflet de la lumière.

Un œil.

Puis les lumières clignotèrent.

Pendant un instant, des mots apparurent en dessous.

**EN UN INSTANT, EN UN CLIN D’ŒIL.**

La lumière revint. À l’étage inférieur, une chaise racla le sol.

Anna regarda Lydia. Lydia regarda Ruth. June cessa de sourire.

Beth approcha son fauteuil roulant du baptistère.

— Bon, dit-elle. On peut rester là à le regarder, ou chercher d’où venait la lumière.

La Bible glissa contre la main de Ruth. Une feuille pliée en tomba.

Au recto figurait un jardin dessiné au crayon. Deux chemins se croisaient en son centre.

Au verso, de la main de sa grand-mère :

**Commence avant la peur.**

#### Deux Avant de se cacher

Le samedi les retrouva autour de la table de cuisine de Ruth. Cinq tasses. Une Bible. Une boîte à boutons au sujet de laquelle Ruth refusait toute explication.

Anna ouvrit la Genèse.

Elles commencèrent par la création : la lumière, la séparation, les végétaux, les créatures, l’humanité et le repos. Elles remarquèrent que le récit qualifiait la création de bonne avant que quiconque ait accompli quoi que ce soit.

— Avant le premier bulletin de notes, dit Beth.

Ruth sourit, puis baissa les yeux vers ses propres mains.

Dans le jardin vinrent une limite, une tentation, un choix, puis la dissimulation. Adam accusa la femme. La femme parla du serpent. Les conséquences suivirent. Des vêtements leur furent donnés. La vie continua hors du jardin.

Lydia se souvint d’une image de l’école du dimanche où Ève semblait porter toute la faute à elle seule.

— Adam est dans le passage aussi, dit June. Laissons-le à sa place.

Elles lurent l’histoire de Caïn et Abel. Une offrande. La colère. Un avertissement. Un frère tué. Une question de responsabilité. Un jugement qui comprenait une marque protégeant Caïn contre ceux qui le tueraient.

Anna écrivit deux phrases sur des cartes distinctes.

**Un acte peut être condamné.**

**Une vie peut encore être protégée.**

— Les deux, dit Ruth.

Elles lurent le déluge sans en effacer les morts. Elles suivirent la sauvegarde de Noé, l’alliance, puis la défaillance ultérieure de la famille. Avoir survécu ne les avait pas rendus irréprochables.

Babel apporta une ville, une tour et la dispersion des langues.

— Même un projet commun peut demander à être examiné, dit June.

Beth tourna le dessin du jardin vers la fenêtre. Les chemins croisés s’alignaient sur les plis marqués au crayon.

Un X.

À l’intersection, un seul mot.

**REGARDE.**

#### Trois La famille à la tunique

Elles suivirent Abraham et Sara à travers le départ, la promesse, l’impatience et le rire. Elles s’attardèrent auprès d’Agar assez longtemps pour remarquer une femme en détresse que l’on voyait enfin. Elles lurent la menace du sacrifice d’Isaac et son interruption sans présenter la terreur comme une expérience agréable.

Rébecca entreprit un voyage. Jacob trompa et fut trompé. Ésaü perdit, puis, plus tard, ouvrit les bras. Léa et Rachel vécurent dans une maison où l’affection et la rivalité étaient inégalement réparties. Le récit de Dina fit surgir le mal subi et la violence des représailles ; les femmes refusèrent de confondre l’un ou l’autre avec une protection qui lui aurait rendu la parole.

Puis la tunique de Joseph arriva sur la table.

— Le voilà, dit Lydia. Le préféré.

Ses frères le vendirent. Ils laissèrent leur père le croire mort. En Égypte, Joseph subit l’injustice, interpréta des rêves et finit par organiser les réserves de nourriture en prévision d’une famine. Son pouvoir aurait pu écraser ses frères à leur retour. Au lieu de cela, après un difficile cheminement d’épreuves et de révélations, il pourvut aux besoins de la famille.

— Le bien qui vient ensuite ne transforme pas cette vente en bonne action, dit Anna.

Ruth acquiesça.

— Mais cela veut dire que cette vente n’a pas eu le dernier mot.

Une coupure de journal reposait dans la Bible, près de Genèse 50. Elle décrivait un fils de prédicateur élevé dans une ferme, le petit dernier de trois enfants, dont le père avait été éleveur de porcs, puis pasteur et peintre. Il s’appelait Nathan Tabor.

La note manuscrite à côté disait :

**Demande ce que l’enfant a reçu avant de décider de ce que veut dire l’adulte.**

June la lut deux fois.

Elles avaient cherché un dispositif au-dessus du baptistère. Maintenant, elles examinaient aussi l’héritage : les mots qu’une famille répète, les rôles qu’elle distribue et les attentes qu’un enfant apprend avant de savoir que ce sont des attentes.

— Qu’est-ce que tu as reçu ? demanda Anna à Ruth.

Ruth toucha la Bible de sa grand-mère.

— La foi. Une place à table. Et le sentiment que, si j’arrêtais de travailler, je risquais de perdre les deux.

Personne ne se précipita pour répondre.

Lydia rapprocha l’assiette de gâteau de sa mère.

Dans la boîte à boutons, sous un double fond, Beth trouva une clé en laiton.

Son étiquette portait ces mots :

**LA PORTE.**

#### À table

Ruth commença une page avec deux titres : **Ce que j’ai reçu** et **Ce que je choisis de garder pour la suite**. Sous les deux, elle écrivit hospitalité. Sous le premier, elle écrivit épuisement. Sous le second, elle laissa un espace, en attendant d’être prête à le remplir.

**Parcours de lecture :** Genèse 1–50. Le récit retient les épisodes principaux ; la lecture intégrale comprend les généalogies, les alliances, les voyages, les conflits familiaux, les bénédictions et les morts.

---

## LIVRE DEUX

### La porte et le désert

#### Un Le placard fermé

La clé ouvrit un placard dans l’ancienne salle de classe, derrière la salle paroissiale.

À l’intérieur se trouvaient une porte miniature avec un fil rouge fixé au-dessus, un panier, un tissu plié et une carte sur laquelle aucune route n’était tracée.

— Ta grand-mère enseignait avec ça ? demanda Beth.

— Quand j’étais petite, répondit Ruth. Je me souviens du panier.

Elles ouvrirent l’Exode.

Avant que Moïse se présente devant Pharaon, des femmes agissaient déjà : des sages-femmes avaient résisté à un ordre meurtrier ; une mère avait caché son bébé ; une sœur avait veillé ; la fille de Pharaon avait recueilli l’enfant.

— Tout le monde se souvient de l’homme au bâton, dit Lydia.

June toucha le panier.

— Lisez qui l’a aidé à vivre assez longtemps pour le tenir.

Moïse s’enfuit après avoir tué un Égyptien. Des années plus tard, le buisson ardent le rappela. Il protesta de son incapacité. Aaron le rejoignit. L’affrontement amena les plaies, la Pâque, le départ et la traversée de la mer.

Elles nommèrent la délivrance et les morts. Se réjouir pour les personnes qui échappaient à la servitude n’exigeait pas de prétendre que le récit ne contenait aucun chagrin.

Au bord de la mer, Miriam chanta.

Dans le désert, le peuple se plaignit.

Beth se cala contre son dossier.

— La liberté vous sort de l’ancien endroit. Elle vous laisse quand même le besoin de prendre un petit déjeuner.

Lydia rit plus fort que la phrase ne semblait le justifier.

#### Deux Assez pour aujourd’hui

La manne arriva avec des instructions pour la récolte. Il fallait de l’eau. Les conseils de Jéthro aidèrent Moïse à partager les responsabilités au lieu d’entendre lui-même tous les différends.

Lydia ferma la Bible.

— J’ai pris le fait d’être celle que tout le monde appelle pour la preuve que je menais correctement ma vie.

— Tu le fais bien, dit Anna.

— Je sais. C’est comme ça que j’ai évité la question.

Elle la rouvrit.

Au Sinaï vinrent l’alliance et les commandements. Puis le veau d’or, les tables brisées, l’intercession et l’alliance renouvelée. Les personnes qui avaient reçu une instruction claire avaient encore besoin de rendre des comptes et de recommencer.

Elles arrivèrent au tabernacle et s’attardèrent sur les savoir-faire : tisser, sculpter, assembler, concevoir, fabriquer. Le culte demandait des mains autant que des paroles.

Beth déplia le tissu du placard. Il avait cinq poches.

L’une contenait une petite équerre de menuisier. Une autre, une aiguille. Les autres contenaient une cuillère, un crayon et une pierre lisse.

— Des fonctions différentes, dit June.

Beth plaça l’équerre contre la porte miniature.

Elle était de travers.

— Et la première fonction de celle-ci, c’est de reconnaître qu’un ajustement est nécessaire.

#### Trois Les personnes entre les lignes

Le Lévitique les ralentit.

Offrandes, responsabilités sacerdotales, règles de pureté, jours saints, restitution, terres et dispositions pour les personnes démunies. C’était un ancien système d’alliance, et elles le lurent comme tel avant d’en tirer des applications modernes.

Elles remarquèrent l’instruction de laisser une partie de la récolte au pauvre et à l’étranger.

— On peut organiser la sainteté de façon à laisser à quelqu’un de quoi manger, dit Lydia.

Les Nombres recensaient les personnes et racontaient les voyages, les plaintes, les rébellions et les pertes. Les éclaireurs virent le pays ; la peur grossit les obstacles. L’ânesse de Balaam vit ce que Balaam ne voyait pas. Les filles de Tselophchad soumirent une question d’héritage à l’assemblée, et la loi répondit à leur cas.

— La question a sa place dans la pièce, dit Anna.

Le Deutéronome raconta de nouveau le voyage. Souviens-toi. Enseigne. Choisis. Prends soin de la veuve, de l’orphelin et de l’étranger. Écoute les bénédictions et les avertissements. Moïse vit le pays, mais mourut avant d’y entrer.

Ruth regarda la carte sans route.

— Je pensais qu’il manquait quelque chose.

Beth la tint contre la porte miniature. De petits trous dans le cadre projetèrent des points sur le papier.

Un itinéraire apparut quand l’angle fut le bon.

— Il lui fallait une autre pièce, dit Beth.

Lydia sortit son téléphone et appela une autre femme de l’église.

Elle demanda si elles pouvaient répartir le prochain repas d’obsèques entre trois foyers.

La femme accepta avant que Lydia ait fini de s’expliquer.

Un instant, Lydia parut presque offensée que le monde ait permis cela aussi facilement.

Puis elle rit.

À l’extrémité de la carte, les points entouraient une couronne.

#### À table

Chacune choisit une responsabilité à partager, à transmettre ou à reconsidérer. Aucune ne dut renoncer à une tâche qu’elle aimait. Lydia continuerait à préparer la soupe. Quelqu’un d’autre ramasserait la vaisselle.

**Parcours de lecture :** Exode 1–40 ; Lévitique 1–27 ; Nombres 1–36 ; Deutéronome 1–34. Les lois et les listes restent partie intégrante de la lecture, même lorsque le récit leur donne une application à échelle humaine.

---

## LIVRE TROIS

### La couronne et la table de cuisine

#### Un Un nom dans la marge

La couronne indiquait un portrait dans le plus ancien album de photos de l’église.

La grand-mère de Ruth se tenait près d’une table, une couronne de papier à la main. Derrière elle, le visage d’une femme avait été découpé de la photographie.

Anna ne dit pas scandale. Elle dit :

— Il nous faut un autre exemplaire.

Pendant qu’elles cherchaient, June ouvrit Josué.

La traversée du Jourdain. Rahab abritant les espions. Jéricho. Ce qu’Acan avait pris en secret et les conséquences de son acte. Le partage du pays. L’alliance renouvelée.

Elles ne transformèrent pas les récits de conquête en consignes pour attaquer les voisins d’aujourd’hui. La violence resta visible ; les personnages se demandèrent ce que les textes présentaient au sujet de l’allégeance, du jugement et de la responsabilité, et à quels endroits une application moderne demandait de la prudence.

Les Juges portaient des cycles de défaillance et de délivrance. Débora jugea. Gédéon douta et agit. Le vœu de Jephté dévasta sa fille. La force de Samson ne garantissait pas un jugement sûr. Les derniers chapitres décrivaient des sévices et un conflit civil si graves que Ruth cessa de lire à voix haute.

— On peut prendre une minute, dit June.

Ce matin-là, l’acte porteur d’espoir consistait à faire une place aux personnes blessées dans la discussion, au lieu de se précipiter vers un héros divertissant.

Puis Ruth ouvrit le livre qui portait son nom.

Naomi perdit son mari et ses fils. Ruth resta auprès d’elle. Un champ offrit la possibilité de glaner ; Boaz offrit sa protection et agit dans le cadre des dispositions de la communauté. Un mariage et un enfant suivirent.

— Tout le village compte, dit Lydia. La nourriture. La sécurité. Les témoins.

Beth désigna la photographie découpée.

— Alors retrouvons la femme que la photo du village a perdue.

#### Deux La couronne a un travail à faire

Le premier livre de Samuel commençait par la détresse et la prière d’Anne, puis par la naissance de Samuel. Samuel entendit un appel. Israël demanda un roi. Saül reçut l’autorité et finit par perdre, par désobéissance, l’avenir de sa dynastie. David entra dans le récit comme un jeune berger et devint un fugitif avant de devenir roi.

Le deuxième livre de Samuel ne laissa pas la couronne protéger David de la vérité sur Bath-Schéba et Urie. Nathan le confronta. Parmi les blessures qui atteignirent ensuite la maison figurèrent le viol de Tamar, la mort d’Amnon et la révolte d’Absalom.

— Un titre ne règle pas la question, dit Anna. Qu’est-ce que la personne a fait de son pouvoir ?

Les Rois apportaient la sagesse, le temple, la richesse et les fidélités partagées de Salomon ; le royaume divisé ; les prophètes affrontant les souverains ; le défi d’Élie et sa fuite ; le ministère d’Élisée ; les coups d’État, l’injustice, les réformes et l’effondrement.

L’huile de la veuve intéressa Lydia. La jeune servante sans nom qui orienta Naaman vers de l’aide aussi.

Les Chroniques revenaient sur les ancêtres, David, l’organisation du temple et les rois de Juda.

— Un autre récit, dit June. Nous devrions remarquer ce qu’il choisit de souligner.

Beth trouva le panneau qui soutenait la couronne dans une malle de rangement. La grand-mère de Ruth y avait écrit trois titres :

**ATTRIBUTS. CARACTÉRISTIQUES. FONCTIONNALITÉS.**

En dessous :

**Qu’est-ce qui est présent ? Qu’est-ce qui se répète ? Qu’est-ce que cela fait ?**

Ruth posa la couronne de papier de sa grand-mère sur la table.

Elle paraissait étonnamment petite.

#### Trois La photographie retrouvée

Esdras et Néhémie apportaient le retour, la reconstruction, le culte, la loi, l’opposition et des décisions difficiles sur les limites de la communauté. Certaines décisions affectaient douloureusement des familles. Les femmes discutèrent de ces coûts en même temps que de la restauration.

Esther apportait un peuple menacé, une reine ayant accès au pouvoir, l’appel de Mardochée, un risque, des banquets préparés, un complot dévoilé et une délivrance suivie de violence.

— Elle a utilisé l’accès qu’elle avait, dit Anna. Elle s’est préparée aussi. Le courage avait un calendrier.

June arriva la semaine suivante avec un autre exemplaire de la photographie.

La femme manquante s’appelait Ellen. Une note au dos l’identifiait comme la personne qui avait peint les décors des leçons bibliques.

Ruth se souvenait maintenant d’elle. Après le déménagement d’Ellen, l’album avait été endommagé par l’eau. Quelqu’un avait découpé la partie gondolée au lieu de remplacer toute l’image.

Il n’y avait pas eu de complot.

Il y avait eu un nom perdu.

Anna numérisa l’exemplaire complet. Elle écrivit le nom d’Ellen sous l’image restaurée, à côté des noms déjà connus.

— Nous étions prêtes à attribuer un motif avant d’avoir une deuxième photographie, dit-elle.

June sourit.

— C’est utile de se surprendre à faire cela.

Le décor peint par Ellen comportait cinq fenêtres. L’une était ouverte.

À travers elle, quelqu’un avait peint une chaise et un livre.

Sur le dos du livre :

**JOB.**

#### À table

Elles demandèrent qui avait accompli une tâche utile sans en recevoir le mérite. Elles ajoutèrent les noms qu’elles pouvaient vérifier. Lorsqu’elles ne le pouvaient pas, elles laissèrent honnêtement l’espace vide.

**Parcours de lecture :** Josué ; Juges ; Ruth ; 1–2 Samuel ; 1–2 Rois ; 1–2 Chroniques ; Esdras ; Néhémie ; Esther, en entier.

---

## LIVRE QUATRE

### La question et le silence

#### Un La chaise près du lit

Ruth manqua la réunion suivante parce que la sœur de June était à l’hôpital.

Il n’y eut pas de chasse aux indices ce soir-là. Il y eut une chaise près d’un lit et une longue conversation sur des choses ordinaires.

Ensuite, June admit qu’elle avait craint de devoir dire quelque chose de mieux.

— Tu es restée, dit Ruth.

Lorsqu’elles revinrent à Job, les pertes du début résonnèrent autrement. Job perdit ses biens, ses enfants et sa santé. Ses amis arrivèrent et s’assirent d’abord en silence. Plus tard, ils fournirent des explications qui traitaient sa souffrance comme une preuve contre lui.

Job contesta. Il se lamenta. Il voulait une réponse.

Les femmes lurent les scènes célestes, les débats, les discours d’Élihu, la réponse divine et la conclusion sans tout réduire à l’opinion d’un seul interlocuteur. Elles remarquèrent qu’en Job 42:7, les amis étaient repris pour leurs paroles au sujet de Dieu.

La restauration suivit. June garda un doigt posé sur les pertes antérieures.

— Un amour nouveau n’efface pas les personnes qui sont mortes.

Ruth acquiesça.

Personne ne perfectionna la phrase.

#### Deux Le recueil de cantiques sans couverture

Les Psaumes leur donnèrent la louange, la plainte, la confession, la confiance, la colère, la reconnaissance et l’attente sans réponse.

— Nous avons chanté plus souvent ceux qui expriment la confiance, dit Lydia.

Elles lurent le Psaume 13. Puis le Psaume 23. Puis le Psaume 88, qui ne se terminait pas par l’apaisement émotionnel qu’elles attendaient.

June écrivit une question dans son carnet.

**Puis-je parler honnêtement avant de me sentir mieux ?**

Les Proverbes offraient des observations sur la parole, le travail, la générosité, la colère, la discipline, le jugement et la sagesse. Anna compara des proverbes qui traitaient de situations différentes.

— Les circonstances comptent, dit-elle. Une phrase sage a toujours besoin de quelqu’un qui la lise avec attention.

Elles arrivèrent à Proverbes 23:7 et lurent l’avertissement qui l’entourait, au sujet d’un hôte dont la générosité apparente cachait un cœur calculateur. La phrase sur ce que l’on pense en son cœur avait une scène précise autour d’elle ; elles pouvaient discuter de la pensée et de l’identité sans faire disparaître cette scène.

L’Ecclésiaste leur permit d’examiner le travail, le plaisir, la mortalité, les limites, l’injustice, la compagnie des autres et les saisons de la vie. Ses questions ne tenaient pas sur une carte postale joyeuse.

Ruth regarda vers le jardin.

— Ma grand-mère a planté ce poirier. Elle n’en a jamais goûté une poire.

— Toi, si, dit Anna.

Ruth sourit.

— Oui.

#### Trois L’amour, lumières allumées

Le Cantique des cantiques surprit la tablée au point de la plonger dans le silence, puis dans le rire, puis dans une discussion sur l’affection que personne n’avait prévu d’avoir autour de petits pains.

Elles lurent sa poésie comme de la poésie, avec ses images, son désir, sa beauté et son plaisir partagé. June expliqua que des lecteurs religieux l’avaient aussi abordée de manière allégorique. C’étaient des traditions d’interprétation ; les images sur la page méritaient toujours leur attention.

Beth trouva un ruban glissé derrière la reliure de la Bible familiale. De minuscules lettres brodées couraient le long du tissu.

**Tu peux lire la phrase entière.**

— Ça paraît moins spectaculaire qu’un passage secret, dit Lydia.

— Ça dépend de la phrase, répondit Beth.

Ruth se souvint qu’on lui avait dit de garder la joie en toute circonstance. Elle avait aimé ce mot et s’en était parfois servie pour se presser de dépasser son chagrin.

Ce soir-là, elle appela June après la visite à l’hôpital.

— Comment vas-tu ?

— Fatiguée. Triste. Contente que tu aies appelé.

Les trois avaient leur place dans la réponse.

Le ruban se terminait par une petite fenêtre brodée. Anna la rapprocha du tableau d’Ellen. Sur le rebord peint, presque dissimulée sous le cadre, figurait une référence de verset.

**ÉSAÏE 1.**

Elles avaient atteint la fenêtre du guetteur.

#### À table

Chaque femme choisit un psaume qui correspondait à ce qu’elle ressentait vraiment. Chacune pouvait garder son choix pour elle. Elles laissèrent une prière être sincère avant de lui demander d’être éloquente.

**Parcours de lecture :** Job ; Psaumes ; Proverbes ; Ecclésiaste ; Cantique des cantiques, en entier. Les applications des personnages ne promettent pas qu’un changement d’interprétation guérisse instantanément la maladie ou le deuil.

---

## LIVRE CINQ

### Le guetteur et la fenêtre

#### Un Ce que montre la fenêtre

La fenêtre du tableau d’Ellen donnait sur le parking de l’église.

Par la véritable fenêtre, Lydia voyait l’endroit où une visiteuse avait un jour attendu que quelqu’un l’aide à porter ses courses jusqu’à sa voiture.

Lydia avait été trop occupée à disposer des fleurs pour le remarquer.

Ésaïe confrontait l’injustice et les pratiques religieuses vides. Ses visions parlaient aussi de consolation, de restauration, d’un serviteur et d’un avenir plus vaste que la crise immédiate.

Jérémie avertissait au milieu de la résistance et du désastre. Les Lamentations pleuraient Jérusalem au lieu d’embellir sa destruction. Ézéchiel portait des visions, la responsabilité, le jugement, la restauration et des ossements desséchés recevant la vie.

— Nous pouvons apprécier l’image impressionnante et manquer les personnes qui l’entourent, dit Anna.

Daniel plaçait des personnes fidèles dans les cours impériales : choix alimentaires, rêves, fournaise, fosse aux lions et visions de royaumes. Les femmes distinguèrent les cadres des récits de tous les calendriers modernes proposés.

— Une ressemblance donne une raison d’examiner quelque chose, dit Beth. Il nous faut encore des preuves avant d’annoncer une correspondance.

Elle l’écrivit sous les trois titres de la couronne.

#### Deux Les petits livres aux grandes questions

Osée apportait la trahison de l’alliance et les images conjugales difficiles par lesquelles le livre l’exprimait. Joël apportait la dévastation, la repentance et une effusion promise. Amos confrontait l’exploitation et un culte détaché de la justice.

Abdias condamnait la conduite d’Édom envers un voisin dans la détresse. Jonas résistait à une mission, survivait à la mer et au poisson, prêchait à Ninive et s’irritait de la miséricorde.

Ruth ferma brièvement les yeux.

— J’ai été Jonas après la mort de la plante, dit-elle. Contrariée que quelqu’un d’autre reçoive de la bonté.

Michée mettait en lumière la justice, la miséricorde et l’humilité. Nahum annonçait la chute de Ninive. Habakuk interrogeait l’injustice et affrontait une réponse difficile. Sophonie avertissait du jugement et annonçait la restauration.

Aggée parlait de reconstruction et de priorités. Zacharie apportait des visions, des encouragements et une espérance future. Malachie dénonçait les défaillances dans le culte, la fidélité et la justice, et se terminait par une promesse tournée vers l’avenir.

Elles entendirent des livres distincts avec des préoccupations distinctes. L’appel répété à prendre soin de leurs voisins devint plus clair parce qu’elles étaient restées attentives aux différences.

Lydia inscrivit l’aide aux visiteurs pour leurs courses à l’ordre du jour de la prochaine réunion de l’église.

— Il nous faut des bénévoles à la porte, dit-elle. Et un moyen de demander aux personnes quelle aide elles souhaitent.

#### Trois L’avertissement qui ouvrait vers l’extérieur

Derrière le cadre de la fenêtre se trouvait un étroit compartiment. Beth le découvrit en vérifiant une vis desserrée.

À l’intérieur reposaient un bulletin de l’église et un croquis du baptistère.

Le bulletin annonçait une ancienne exposition biblique intitulée **Le Clin d’œil**. Ruth reconnut la date. Elle avait aidé à laver les tasses après la visite.

— Je me souviens de l’œil maintenant, dit-elle. Il faisait partie de la dernière installation.

Le but de l’exposition était écrit sous le titre :

**Lisez ce qui précède. Lisez ce qui suit. Laissez parler le passage entier.**

Anna ouvrit une collection numérique de manuscrits anciens. Elles regardèrent des pages et des fragments conservés, prenant conscience de tout le travail minutieux qui séparait un ancien objet écrit d’une transcription lisible.

Aucun fragment ne disait tout ce qu’elles souhaitaient lui faire dire. Aucune lacune ne les autorisait à inventer une phrase manquante.

June ouvrit la KJV à la dernière référence de l’exposition : 1 Corinthiens 15.

— Nous avons commencé par une demi-ligne, dit-elle.

— Et hérité d’une partie de l’émotion qui l’entourait, dit Lydia.

Le croquis indiquait une armoire électrique, mais sa clé manquait.

Au dos du bulletin, Ellen avait dessiné une table avec un couvert supplémentaire.

À cette place, elle avait écrit :

**VIENS ET VOIS.**

#### À table

Elles choisirent une pratique que leur église pouvait améliorer et identifièrent la personne qui en bénéficierait. La première réponse vint de la visiteuse elle-même : un passage dégagé, une main proposée et la permission de refuser l’aide.

**Parcours de lecture :** Ésaïe ; Jérémie ; Lamentations ; Ézéchiel ; Daniel ; Osée ; Joël ; Amos ; Abdias ; Jonas ; Michée ; Nahum ; Habakuk ; Sophonie ; Aggée ; Zacharie ; Malachie, en entier.

---

## LIVRE SIX

### La table et le tombeau vide

#### Un Une place déjà mise

June invita à dîner une personne de l’église méthodiste et une amie de la communauté presbytérienne. Ruth s’inquiéta des petits pains avant de songer à s’inquiéter des différences entre confessions.

Les nouvelles venues reconnurent davantage de choses dans cette soirée que personne ne l’avait prévu : le plat apporté en cadeau, la Bible héritée, le souci que tout le monde ait assez à manger, la personne qui commençait à débarrasser les assiettes avant d’avoir terminé son propre repas.

Elles ouvrirent Matthieu et Luc et comparèrent les récits de la naissance sans prétendre qu’ils étaient organisés de façon identique. Marie reçut une annonce. Joseph dut prendre une décision. Élisabeth accueillit Marie. Des bergers vinrent dans Luc ; des mages apparurent dans Matthieu. La violence d’Hérode et la fuite en Égypte restèrent dans le récit de Matthieu.

Elles ne construisirent pas une date moderne exacte de naissance à partir de détails qui n’en donnaient pas.

Marc entrait rapidement dans le ministère de Jésus. Jean s’ouvrait sur la Parole et proposait sa propre organisation de signes et de conversations.

— Quatre témoins dans notre lecture, dit Anna. Nous devrions entendre chacun avant de les réunir.

Beth vit quelqu’un tendre automatiquement la main vers l’assiette de Ruth.

— Elle mange encore, dit-elle doucement.

La main s’arrêta. L’assiette resta.

#### Deux Qui est au bord du chemin

Elles suivirent Jésus à travers le baptême, la tentation, l’enseignement, les guérisons, les appels, les désaccords et les repas.

Des personnes s’approchaient avec des besoins. D’autres avec des questions. Certaines voulaient le mettre à l’épreuve. Les femmes remarquèrent combien de fois une conversation changeait parce que quelqu’un que la foule considérait comme une interruption devenait la personne à laquelle il s’adressait.

La Samaritaine eut une longue conversation. Une femme toucha un vêtement. Marie écouta ; Marthe travailla et parla. Des enfants furent accueillis. Un aveugle cria. Zachée descendit d’un arbre et parla de restitution.

June raconta la parabole du bon Samaritain en termes simples : une personne avait été blessée, d’autres étaient passées, quelqu’un s’était arrêté, avait donné des soins, trouvé un hébergement et pris en charge son coût.

— Attributs, dit Beth.

— Caractéristiques, ajouta Anna.

Lydia posa la cuillère de service.

— Fonction. Il a aidé.

Elles lurent le fils prodigue et s’attardèrent aussi auprès du frère aîné. Le retour était bien accueilli ; le ressentiment restait dehors à demander si la générosité était juste.

Lors de la Transfiguration, les disciples virent une révélation que les récits évangéliques situaient dans le cheminement de Jésus vers la souffrance. Les femmes pouvaient admirer la montagne et le suivre aussi lorsqu’il en descendait.

Le croquis de la table d’Ellen comportait un petit dessin sous une chaise : un âne près d’une porte de ville.

Elles passèrent à l’entrée dans Jérusalem.

#### Trois Les femmes au tombeau

Elles suivirent le dernier repas, le lavement des pieds dans Jean, le jardin, la trahison, l’arrestation, les procès, le reniement, la crucifixion et l’ensevelissement. Elles ne rendirent pas la souffrance joyeuse pour préserver l’orientation pleine d’espoir des livres.

Lydia se souvint d’une amie en deuil à qui l’on avait dit de se réjouir avant que quiconque lui demande si elle avait dormi.

— Je vais m’asseoir avec elle, dit-elle. Et la laisser me raconter ce qu’est cette journée pour elle.

Puis vinrent les récits de la résurrection. Des femmes arrivèrent au tombeau. Des annonces et des rencontres suivirent. Les Évangiles racontaient les événements avec des différences de sélection et de détail ; le groupe lut chaque récit au lieu de fournir une seule transcription inventée.

Thomas reçut une rencontre au milieu du doute. Pierre reçut des paroles de restauration et de responsabilité. Les disciples reçurent une mission.

Ruth lut la leçon de Pâques qu’elle avait gardée parmi les papiers de sa grand-mère.

Tout en bas figurait une note destinée à une personne qui lisait avec crainte :

**Tu peux apporter ta question avec toi.**

Beth trouva la clé de l’armoire électrique dans le dossier de la leçon. Quelqu’un l’avait utilisée pour maintenir un paquet de transparents.

Elles l’emportèrent à l’église le lendemain matin.

La porte s’ouvrit.

À l’intérieur se trouvaient un petit projecteur débranché et une feuille d’entretien manuscrite.

Anna lut la première inscription à voix haute.

— Installation de l’Œil. Ne pas raccorder au circuit d’éclairage du sanctuaire.

Beth regarda vers le baptistère.

— Eh bien, dit-elle. Quelqu’un l’a fait.

#### À table

Elles se demandèrent où elles pouvaient faire une place à une personne dont la voix était habituellement étouffée par les autres. Leurs réponses comprenaient l’écoute, la restitution de ce qui était dû, l’aide concrète et le fait d’accepter elles-mêmes de l’aide.

**Parcours de lecture :** Matthieu 1–28 ; Marc 1–16 ; Luc 1–24 ; Jean 1–21. Les récits parallèles restent lisibles séparément. Le manuscrit met en scène les réactions qu’ils suscitent plutôt que de remplacer leur texte.

---

## LIVRE SEPT

### La lettre et la porte ouverte

#### Un Le circuit réparé

Beth appela un électricien qualifié. L’église autorisa une réparation. L’électricien trouva l’alimentation d’une ancienne installation raccordée là où elle n’aurait pas dû l’être ; un défaut intermittent expliquait le clignotement. La diapositive restée dans le projecteur expliquait l’Œil.

La réparation fut ordinaire, et tout le monde fut soulagé.

La question éveillée par la diapositive comptait toujours.

Les Actes les conduisirent à la Pentecôte, à la vie partagée, aux conflits, à la persécution, à la dispersion et aux voyages. Les veuves avaient besoin d’une distribution équitable. Étienne mourut. Philippe rencontra un voyageur éthiopien. Saul devint un disciple après avoir mené une campagne violente contre l’église. Pierre entra dans la maison de Corneille. Lydie ouvrit son foyer. Priscille et Aquilas aidèrent Apollos à comprendre avec davantage d’exactitude.

— Enseigner peut aussi consister à recevoir un enseignement, dit June.

La réunion de Jérusalem traita d’un véritable désaccord au sujet des croyants non juifs. Les voyages de Paul comprirent des églises, des disputes, du danger, la prison et un naufrage.

Les premières communautés avaient des dons et des problèmes.

Lydia trouva du réconfort dans cette combinaison.

#### Deux Des lettres adressées à des personnes

L’épître aux Romains examinait le péché, la foi, la grâce, la loi, Israël et une vie de service. Son propos sur les autorités au chapitre 13 se trouvait à côté d’instructions sur l’amour ; les femmes ne traitèrent pas un passage sur l’autorité publique comme une permission de vengeance privée.

La première épître aux Corinthiens abordait les divisions, la conduite, les corps, le mariage, la nourriture, le culte, les dons spirituels, l’amour et la résurrection. La deuxième portait la faiblesse, la réconciliation, la générosité et une autorité contestée.

L’épître aux Galates contestait les exigences imposées aux croyants non juifs. Celle aux Éphésiens décrivait l’appartenance et une marche façonnée par l’Évangile. Celle aux Philippiens parlait de collaboration, d’humilité, de persévérance et de joie. Celle aux Colossiens plaçait le Christ au centre et mettait en garde contre les enseignements qui déplaçaient ce centre.

Les deux épîtres aux Thessaloniciens abordaient l’encouragement, le deuil, l’attente et la confusion concernant la venue du Seigneur. Les femmes lurent les paroles rassurantes avec les avertissements. Elles comprirent comment une phrase isolée pouvait devenir un message beaucoup plus retentissant dans la mémoire d’un enfant.

Les deux épîtres à Timothée et celle à Tite traitaient de l’enseignement, du soin, de la direction, de la conduite et de la persévérance. Philémon plaçait une demande concernant Onésime dans une relation façonnée par la fraternité chrétienne. Les femmes nommèrent l’esclavage qui entourait la lettre au lieu de considérer une demande bienveillante comme si elle effaçait l’institution.

June revint à 2 Timothée 2:15 et à sa formule sur le fait de dispenser droitement la parole de vérité.

Sa question pratique était simple.

— À qui s’adresse-t-on, et qu’est-ce que nous lisons ?

Anna ajouta :

— Quelle application en faisons-nous, et qu’est-ce que le passage disait réellement ?

#### Trois Le carnet à la page volante

L’épître aux Hébreux appelait à la persévérance et examinait le sacerdoce, le sacrifice, l’alliance et la foi. Jacques rendait la foi concrète dans la conduite, la parole, l’équité et le soin des autres. La première épître de Pierre abordait la souffrance et l’espérance. La deuxième mettait en garde contre les enseignements corrompus.

Les lettres de Jean examinaient la vérité, l’amour, la communion et la conduite. Jude mettait en garde contre des personnes destructrices au sein de la communauté.

Lydia arriva à Jacques 1:27 et pensa au roulement des repas, aux courses, aux personnes qui attendaient un appel après des obsèques.

Elle écrivit des noms à côté des tâches. Elle demanda aussi si les personnes souhaitaient l’aide proposée.

June sortit le dernier carnet d’Ellen.

À l’intérieur, le titre de travail de l’exposition avait été barré.

**TOUT PEUT FINIR EN UN INSTANT.**

En dessous, une autre ligne :

**TOUT PEUT COMMENCER EN UN INSTANT.**

La note à côté était soigneusement formulée.

**Un nouveau choix peut commencer en un instant. Le travail qu’il demande peut prendre des années.**

Ruth la lut et sentit ses épaules se détendre.

Elle n’avait pas à réparer soixante-dix-huit années avant le dîner.

Elle pouvait demander à Anna de rester pendant qu’elle parlait d’une seule chose.

À la fin du carnet, Ellen avait dessiné sept chandeliers et une porte de ville ouverte.

Leur dernière lecture les attendait.

#### À table

Elles examinèrent une phrase héritée en distinguant trois choses : ses mots réels, ce qu’elles y avaient entendu et ce qu’elles choisissaient de faire maintenant. Personne n’avait besoin d’être d’accord sur toutes les conclusions pour écouter avec justesse.

**Parcours de lecture :** Actes ; Romains ; 1–2 Corinthiens ; Galates ; Éphésiens ; Philippiens ; Colossiens ; 1–2 Thessaloniciens ; 1–2 Timothée ; Tite ; Philémon ; Hébreux ; Jacques ; 1–2 Pierre ; 1–3 Jean ; Jude, en entier.

---

## LIVRE HUIT

### Le clin d’œil et le commencement

#### Un Sept lettres avant le tonnerre

Elles commencèrent l’Apocalypse là où l’Apocalypse commençait : par sa salutation, sa vision et ses messages à sept églises.

June lut lentement les noms : Éphèse, Smyrne, Pergame, Thyatire, Sardes, Philadelphie, Laodicée.

Éloges et corrections. Persévérance et compromis. Portes et lampes. Un appel à entendre.

Les églises recevaient leurs messages avant que les femmes atteignent les visions qui avaient tant rempli leur imagination d’enfants.

Elles suivirent la scène du trône, le rouleau, les sceaux, les trompettes, le conflit, les bêtes, les jugements, la chute de Babylone, la victoire, le jugement dernier et la nouvelle création. Les images étaient intenses. Elles reconnurent la souffrance qu’elles représentaient au lieu de transformer la catastrophe en divertissement.

June apporta trois commentaires qui abordaient l’Apocalypse différemment. Elles comparèrent les lectures sans prétendre que le désaccord entre spécialistes prouvait que toutes les interprétations étaient aussi solides, ni que l’assurance rendait une interprétation indiscutable.

— Notons d’abord ce que dit le texte, dit Anna. Ensuite, nous pourrons examiner ce que chaque personne pense qu’il signifie.

Ruth avait autrefois pensé que ce genre de comparaison fragiliserait l’assemblée.

La pièce devint plus silencieuse et plus attentive.

#### Deux La ville où il y a de la place

Dans Apocalypse 21 et 22, elles lurent un ciel et une terre nouveaux, des larmes essuyées, la mort abolie, une ville, un fleuve et un arbre dont les feuilles servaient à la guérison.

Ruth regarda de nouveau le premier dessin du jardin.

— Un jardin au commencement, dit-elle.

— Et ces images à la fin, répondit Anna.

Elles posèrent les huit indices sur la table : le jardin, la porte, la couronne, la chaise, la fenêtre, la table, la lettre et la porte de la ville.

Leurs versos formaient une grande feuille. Ellen avait dessiné une pièce, puis l’avait divisée en huit morceaux pour les leçons de son exposition.

Cinq chaises entouraient une table.

Au centre se trouvait une Bible ouverte.

L’Œil avait été une installation sur la lecture. Le verset était devenu une question familiale à cause de ce que chaque femme avait apporté dans la pièce.

— J’ai entendu la précipitation, dit Lydia.

— J’ai entendu la perte, dit Ruth.

— J’ai entendu une énigme, dit Beth.

June regarda Anna.

— J’ai entendu les mots manquants, répondit Anna.

Elles ouvrirent de nouveau 1 Corinthiens 15. Le passage parlait de résurrection, de transformation, de victoire sur la mort et de travail persévérant. Le clin d’œil appartenait à ce raisonnement. Il n’avait pas été écrit comme une consigne demandant à un enfant de rester terrifié par chaque bruit soudain.

Ruth lut la ligne sur le fait d’être transformés.

Puis elle poursuivit sa lecture.

#### Trois La phrase entière

Les femmes organisèrent une nouvelle exposition à l’église. Le projecteur réparé resta séparé de l’éclairage du sanctuaire. Beth vérifia l’accessibilité du parcours à travers chaque installation.

Elles l’appelèrent **LE CLIN D’ŒIL**.

À chaque étape se trouvaient un passage à lire, un récit en langage simple et un espace pour noter une question. Les objets historiques étaient présentés sous forme de photographies accompagnées de leurs sources. Le mystère de la famille inventée était identifié comme fiction. Leurs propres souvenirs étaient proposés comme souvenirs.

Personne ne devait abandonner sa foi pour entrer.

Personne n’avait à révéler une blessure intime pour terminer le parcours.

Une femme âgée resta longtemps devant l’installation de la chaise. Une femme plus jeune lut le chapitre entier derrière l’Œil. Deux hommes débattirent gaiement des dimensions de la porte miniature avant de remarquer le passage placé à côté.

Lydia s’assit pour manger alors qu’il restait encore de la nourriture.

Ruth la regarda et sourit.

June se tenait près de la dernière table. Une visiteuse demanda si elle devait venir avec un groupe.

— Vous pouvez le lire seule, dit-elle. Vous pouvez venir avec votre famille. Des amis. Une classe. Les cinq questions ont leur place autour de n’importe quelle table.

Elle désigna le carnet :

**De quoi est-ce que je me souviens ?**

**Quelle question est-ce que je porte ?**

**Quel schéma est-ce que je remarque ?**

**Qui est concerné ?**

**Que pourrais-je faire ensuite ?**

La visiteuse s’assit.

Ruth plaça la Bible de sa grand-mère au centre, ouverte plutôt que fermée.

Ce soir-là, Anna et elle parcoururent l’album de photographies. Elles ajoutèrent des noms, corrigèrent une date et laissèrent une mention incertaine signalée comme incertaine.

Un travail ordinaire.

Un travail utile.

Anna demanda ce que Ruth voulait écrire à la fin de sa nouvelle page.

Ruth réfléchit un instant.

Puis elle écrivit :

**TOUT PEUT COMMENCER EN UN INSTANT.**

En dessous :

**Demain, je demanderai de l’aide avant d’être épuisée.**

Anna ajouta sa propre phrase.

Beth avait déjà organisé la réunion suivante. June apporterait les questions. Lydia apporterait de la soupe, parce qu’elle en avait envie.

Dehors, le soir descendait sur les fenêtres de l’église. À l’intérieur, cinq femmes continuaient à parler.

L’instant suivant leur appartenait.

#### À table

Choisissez une prochaine action assez petite pour la nommer et assez réelle pour l’accomplir. Un commencement peut être une conversation, une limite, un appel rendu, un repas, une supposition corrigée ou un rendez-vous pour obtenir de l’aide. Il n’a pas besoin d’effacer le passé pour changer ce qui arrive ensuite.

**Parcours de lecture :** Apocalypse 1–22 ; puis 1 Corinthiens 15 en entier. L’inversion finale du récit est une application concernant un commencement, et non une traduction de remplacement de l’un ou l’autre passage.

---

