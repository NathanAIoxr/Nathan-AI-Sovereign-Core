# LIVRE SIX

## La table et le tombeau vide

### Un Une place déjà mise

June invita à dîner une personne de l’église méthodiste et une amie de la communauté presbytérienne. Ruth s’inquiéta des petits pains avant de songer à s’inquiéter des différences entre confessions.

Les nouvelles venues reconnurent davantage de choses dans cette soirée que personne ne l’avait prévu : le plat apporté en cadeau, la Bible héritée, le souci que tout le monde ait assez à manger, la personne qui commençait à débarrasser les assiettes avant d’avoir terminé son propre repas.

Elles ouvrirent Matthieu et Luc et comparèrent les récits de la naissance sans prétendre qu’ils étaient organisés de façon identique. Marie reçut une annonce. Joseph dut prendre une décision. Élisabeth accueillit Marie. Des bergers vinrent dans Luc ; des mages apparurent dans Matthieu. La violence d’Hérode et la fuite en Égypte restèrent dans le récit de Matthieu.

Elles ne construisirent pas une date moderne exacte de naissance à partir de détails qui n’en donnaient pas.

Marc entrait rapidement dans le ministère de Jésus. Jean s’ouvrait sur la Parole et proposait sa propre organisation de signes et de conversations.

— Quatre témoins dans notre lecture, dit Anna. Nous devrions entendre chacun avant de les réunir.

Beth vit quelqu’un tendre automatiquement la main vers l’assiette de Ruth.

— Elle mange encore, dit-elle doucement.

La main s’arrêta. L’assiette resta.

### Deux Qui est au bord du chemin

Elles suivirent Jésus à travers le baptême, la tentation, l’enseignement, les guérisons, les appels, les désaccords et les repas.

Des personnes s’approchaient avec des besoins. D’autres avec des questions. Certaines voulaient le mettre à l’épreuve. Les femmes remarquèrent combien de fois une conversation changeait parce que quelqu’un que la foule considérait comme une interruption devenait la personne à laquelle il s’adressait.

La Samaritaine eut une longue conversation. Une femme toucha un vêtement. Marie écouta ; Marthe travailla et parla. Des enfants furent accueillis. Un aveugle cria. Zachée descendit d’un arbre et parla de restitution.

June raconta la parabole du bon Samaritain en termes simples : une personne avait été blessée, d’autres étaient passées, quelqu’un s’était arrêté, avait donné des soins, trouvé un hébergement et pris en charge son coût.

— Attributs, dit Beth.

— Caractéristiques, ajouta Anna.

Lydia posa la cuillère de service.

— Fonction. Il a aidé.

Elles lurent le fils prodigue et s’attardèrent aussi auprès du frère aîné. Le retour était bien accueilli ; le ressentiment restait dehors à demander si la générosité était juste.

Lors de la Transfiguration, les disciples virent une révélation que les récits évangéliques situaient dans le cheminement de Jésus vers la souffrance. Les femmes pouvaient admirer la montagne et le suivre aussi lorsqu’il en descendait.

Le croquis de la table d’Ellen comportait un petit dessin sous une chaise : un âne près d’une porte de ville.

Elles passèrent à l’entrée dans Jérusalem.

### Trois Les femmes au tombeau

Elles suivirent le dernier repas, le lavement des pieds dans Jean, le jardin, la trahison, l’arrestation, les procès, le reniement, la crucifixion et l’ensevelissement. Elles ne rendirent pas la souffrance joyeuse pour préserver l’orientation pleine d’espoir des livres.

Lydia se souvint d’une amie en deuil à qui l’on avait dit de se réjouir avant que quiconque lui demande si elle avait dormi.

— Je vais m’asseoir avec elle, dit-elle. Et la laisser me raconter ce qu’est cette journée pour elle.

Puis vinrent les récits de la résurrection. Des femmes arrivèrent au tombeau. Des annonces et des rencontres suivirent. Les Évangiles racontaient les événements avec des différences de sélection et de détail ; le groupe lut chaque récit au lieu de fournir une seule transcription inventée.

Thomas reçut une rencontre au milieu du doute. Pierre reçut des paroles de restauration et de responsabilité. Les disciples reçurent une mission.

Ruth lut la leçon de Pâques qu’elle avait gardée parmi les papiers de sa grand-mère.

Tout en bas figurait une note destinée à une personne qui lisait avec crainte :

**Tu peux apporter ta question avec toi.**

Beth trouva la clé de l’armoire électrique dans le dossier de la leçon. Quelqu’un l’avait utilisée pour maintenir un paquet de transparents.

Elles l’emportèrent à l’église le lendemain matin.

La porte s’ouvrit.

À l’intérieur se trouvaient un petit projecteur débranché et une feuille d’entretien manuscrite.

Anna lut la première inscription à voix haute.

— Installation de l’Œil. Ne pas raccorder au circuit d’éclairage du sanctuaire.

Beth regarda vers le baptistère.

— Eh bien, dit-elle. Quelqu’un l’a fait.

### À table

Elles se demandèrent où elles pouvaient faire une place à une personne dont la voix était habituellement étouffée par les autres. Leurs réponses comprenaient l’écoute, la restitution de ce qui était dû, l’aide concrète et le fait d’accepter elles-mêmes de l’aide.

**Parcours de lecture :** Matthieu 1–28 ; Marc 1–16 ; Luc 1–24 ; Jean 1–21. Les récits parallèles restent lisibles séparément. Le manuscrit met en scène les réactions qu’ils suscitent plutôt que de remplacer leur texte.
