# LIVRO SEIS

## A mesa e o túmulo vazio

### Um Um lugar já preparado

June convidou uma pessoa da igreja metodista e uma amiga da congregação presbiteriana para jantar. Ruth se preocupou com os pãezinhos antes de pensar em se preocupar com as diferenças entre as denominações.

As recém-chegadas reconheceram mais coisas naquela noite do que qualquer uma esperava: o prato levado como presente, a Bíblia herdada, a preocupação em garantir que todos tivessem o suficiente, a pessoa que começava a recolher os pratos antes de terminar a própria refeição.

Elas abriram Mateus e Lucas e compararam as narrativas do nascimento sem fingir que eram organizadas de forma idêntica. Maria recebeu um anúncio. José enfrentou uma decisão. Isabel acolheu Maria. Pastores vieram em Lucas; magos apareceram em Mateus. A violência de Herodes e a fuga para o Egito permaneceram no relato de Mateus.

Elas não construíram uma data moderna exata de nascimento a partir de detalhes que não forneciam uma.

Marcos avançava rapidamente para o ministério de Jesus. João começava com o Verbo e trazia sua própria organização de sinais e conversas.

— Quatro testemunhas na nossa leitura — disse Anna. — Precisamos ouvir cada uma antes de juntá-las.

Beth viu alguém estender a mão automaticamente para o prato de Ruth.

— Ela ainda está comendo — disse com delicadeza.

A mão parou. O prato ficou.

### Dois Quem está à beira da estrada

Elas acompanharam Jesus pelo batismo, pela tentação, pelo ensino, pelas curas, pelos chamados, pelas discordâncias e pelas refeições.

Pessoas se aproximavam com necessidades. Outras se aproximavam com perguntas. Algumas queriam testá-lo. As mulheres perceberam quantas vezes uma conversa mudava porque alguém que a multidão tratava como interrupção se tornava a pessoa a quem ele se dirigia.

A mulher samaritana teve uma conversa longa. Uma mulher tocou uma roupa. Maria ouviu; Marta trabalhou e falou. Crianças foram acolhidas. Um homem cego gritou. Zaqueu desceu de uma árvore e falou de restituição.

June contou a parábola do bom samaritano em linguagem simples: uma pessoa foi ferida, outras passaram, alguém parou, prestou cuidados, providenciou hospedagem e assumiu a responsabilidade pelo custo.

— Atributos — disse Beth.

— Características — acrescentou Anna.

Lydia pousou a colher de servir.

— Função. Ele ajudou.

Elas leram o filho pródigo e também ficaram com o irmão mais velho. O retorno era bem-vindo; o ressentimento ainda estava do lado de fora, perguntando se a generosidade era justa.

Na Transfiguração, os discípulos viram uma revelação que os relatos dos Evangelhos situavam na jornada de Jesus em direção ao sofrimento. As mulheres podiam admirar a montanha e continuar seguindo Jesus quando ele descia.

O esboço da mesa de Ellen incluía um desenho minúsculo embaixo de uma cadeira: um jumento junto ao portão de uma cidade.

Elas passaram à entrada em Jerusalém.

### Três As mulheres no túmulo

Acompanharam a última refeição, o lavar dos pés em João, o jardim, a traição, a prisão, os julgamentos, a negação, a crucificação e o sepultamento. Não tornaram o sofrimento alegre para preservar a direção esperançosa dos livros.

Lydia se lembrou de uma amiga enlutada a quem tinham mandado se alegrar antes que alguém perguntasse se ela havia dormido.

— Vou me sentar com ela — disse. — E deixar que me conte como está sendo o dia de hoje.

Depois vieram os relatos da ressurreição. Mulheres chegaram ao túmulo. Anúncios e encontros se seguiram. Os Evangelhos contavam os acontecimentos com diferenças na seleção e nos detalhes; o grupo leu cada relato em vez de fornecer uma única transcrição inventada.

Tomé recebeu um encontro em meio à dúvida. Pedro recebeu palavras de restauração e responsabilidade. Os seguidores receberam uma missão.

Ruth leu a lição de Páscoa que tinha guardado entre os papéis da avó.

No fim havia uma anotação escrita para quem lesse com medo:

**Você pode trazer sua pergunta com você.**

Beth encontrou a chave do armário elétrico dentro da pasta da lição. Alguém a tinha usado como peso sobre um pacote de transparências.

Elas a levaram à igreja na manhã seguinte.

A porta se abriu.

Dentro havia um pequeno projetor, desligado da tomada, e uma folha de manutenção escrita à mão.

Anna leu a primeira anotação em voz alta.

— Instalação do olho. Não ligar ao circuito de iluminação do santuário.

Beth olhou para o batistério.

— Bom — disse ela. — Alguém ligou.

### À mesa

Elas perguntaram onde podiam abrir espaço para alguém cuja voz costumava ser abafada. As respostas incluíram ouvir, devolver algo devido, oferecer ajuda prática e receber ajuda também.

**Trilha de leitura:** Mateus 1–28; Marcos 1–16; Lucas 1–24; João 1–21. Os relatos paralelos continuam podendo ser lidos individualmente. O manuscrito dramatiza respostas a eles em vez de substituir seu texto.
