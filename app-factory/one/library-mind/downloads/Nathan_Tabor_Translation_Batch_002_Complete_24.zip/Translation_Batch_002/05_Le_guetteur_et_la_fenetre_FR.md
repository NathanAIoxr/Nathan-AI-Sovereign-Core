# LIVRE CINQ

## Le guetteur et la fenêtre

### Un Ce que montre la fenêtre

La fenêtre du tableau d’Ellen donnait sur le parking de l’église.

Par la véritable fenêtre, Lydia voyait l’endroit où une visiteuse avait un jour attendu que quelqu’un l’aide à porter ses courses jusqu’à sa voiture.

Lydia avait été trop occupée à disposer des fleurs pour le remarquer.

Ésaïe confrontait l’injustice et les pratiques religieuses vides. Ses visions parlaient aussi de consolation, de restauration, d’un serviteur et d’un avenir plus vaste que la crise immédiate.

Jérémie avertissait au milieu de la résistance et du désastre. Les Lamentations pleuraient Jérusalem au lieu d’embellir sa destruction. Ézéchiel portait des visions, la responsabilité, le jugement, la restauration et des ossements desséchés recevant la vie.

— Nous pouvons apprécier l’image impressionnante et manquer les personnes qui l’entourent, dit Anna.

Daniel plaçait des personnes fidèles dans les cours impériales : choix alimentaires, rêves, fournaise, fosse aux lions et visions de royaumes. Les femmes distinguèrent les cadres des récits de tous les calendriers modernes proposés.

— Une ressemblance donne une raison d’examiner quelque chose, dit Beth. Il nous faut encore des preuves avant d’annoncer une correspondance.

Elle l’écrivit sous les trois titres de la couronne.

### Deux Les petits livres aux grandes questions

Osée apportait la trahison de l’alliance et les images conjugales difficiles par lesquelles le livre l’exprimait. Joël apportait la dévastation, la repentance et une effusion promise. Amos confrontait l’exploitation et un culte détaché de la justice.

Abdias condamnait la conduite d’Édom envers un voisin dans la détresse. Jonas résistait à une mission, survivait à la mer et au poisson, prêchait à Ninive et s’irritait de la miséricorde.

Ruth ferma brièvement les yeux.

— J’ai été Jonas après la mort de la plante, dit-elle. Contrariée que quelqu’un d’autre reçoive de la bonté.

Michée mettait en lumière la justice, la miséricorde et l’humilité. Nahum annonçait la chute de Ninive. Habakuk interrogeait l’injustice et affrontait une réponse difficile. Sophonie avertissait du jugement et annonçait la restauration.

Aggée parlait de reconstruction et de priorités. Zacharie apportait des visions, des encouragements et une espérance future. Malachie dénonçait les défaillances dans le culte, la fidélité et la justice, et se terminait par une promesse tournée vers l’avenir.

Elles entendirent des livres distincts avec des préoccupations distinctes. L’appel répété à prendre soin de leurs voisins devint plus clair parce qu’elles étaient restées attentives aux différences.

Lydia inscrivit l’aide aux visiteurs pour leurs courses à l’ordre du jour de la prochaine réunion de l’église.

— Il nous faut des bénévoles à la porte, dit-elle. Et un moyen de demander aux personnes quelle aide elles souhaitent.

### Trois L’avertissement qui ouvrait vers l’extérieur

Derrière le cadre de la fenêtre se trouvait un étroit compartiment. Beth le découvrit en vérifiant une vis desserrée.

À l’intérieur reposaient un bulletin de l’église et un croquis du baptistère.

Le bulletin annonçait une ancienne exposition biblique intitulée **Le Clin d’œil**. Ruth reconnut la date. Elle avait aidé à laver les tasses après la visite.

— Je me souviens de l’œil maintenant, dit-elle. Il faisait partie de la dernière installation.

Le but de l’exposition était écrit sous le titre :

**Lisez ce qui précède. Lisez ce qui suit. Laissez parler le passage entier.**

Anna ouvrit une collection numérique de manuscrits anciens. Elles regardèrent des pages et des fragments conservés, prenant conscience de tout le travail minutieux qui séparait un ancien objet écrit d’une transcription lisible.

Aucun fragment ne disait tout ce qu’elles souhaitaient lui faire dire. Aucune lacune ne les autorisait à inventer une phrase manquante.

June ouvrit la KJV à la dernière référence de l’exposition : 1 Corinthiens 15.

— Nous avons commencé par une demi-ligne, dit-elle.

— Et hérité d’une partie de l’émotion qui l’entourait, dit Lydia.

Le croquis indiquait une armoire électrique, mais sa clé manquait.

Au dos du bulletin, Ellen avait dessiné une table avec un couvert supplémentaire.

À cette place, elle avait écrit :

**VIENS ET VOIS.**

### À table

Elles choisirent une pratique que leur église pouvait améliorer et identifièrent la personne qui en bénéficierait. La première réponse vint de la visiteuse elle-même : un passage dégagé, une main proposée et la permission de refuser l’aide.

**Parcours de lecture :** Ésaïe ; Jérémie ; Lamentations ; Ézéchiel ; Daniel ; Osée ; Joël ; Amos ; Abdias ; Jonas ; Michée ; Nahum ; Habakuk ; Sophonie ; Aggée ; Zacharie ; Malachie, en entier.
