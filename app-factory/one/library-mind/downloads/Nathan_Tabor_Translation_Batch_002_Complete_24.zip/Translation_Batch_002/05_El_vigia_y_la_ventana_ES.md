# LIBRO CINCO

## El vigía y la ventana

### Uno Lo que muestra la ventana

La ventana del cuadro de Ellen daba al estacionamiento de la iglesia.

A través de la ventana real, Lydia veía el lugar donde una visitante había esperado una vez que alguien la ayudara a llevar las compras hasta su coche.

Lydia había estado demasiado ocupada arreglando flores para darse cuenta.

Isaías confrontaba la injusticia y la práctica religiosa vacía. Sus visiones también hablaban de consuelo, restauración, un siervo y un futuro más amplio que la crisis inmediata.

Jeremías advertía en medio de la resistencia y el desastre. Lamentaciones lloraba por Jerusalén en vez de adornar su destrucción. Ezequiel traía visiones, rendición de cuentas, juicio, restauración y huesos secos que recibían vida.

—Podemos disfrutar de la imagen impresionante y pasar por alto a las personas que la rodean —dijo Anna.

Daniel situaba a personas fieles en las cortes imperiales: decisiones sobre la comida, sueños, un horno, un foso de leones y visiones de reinos. Las mujeres distinguieron los escenarios de los relatos de cada cronología moderna propuesta.

—Un parecido es una razón para examinar algo —dijo Beth—. Todavía necesitamos pruebas antes de anunciar una correspondencia.

Lo escribió debajo de los tres encabezados de la corona.

### Dos Los libros pequeños con preguntas grandes

Oseas trajo la traición al pacto y las difíciles imágenes matrimoniales con las que el libro la expresaba. Joel trajo devastación, arrepentimiento y una efusión prometida. Amós confrontó la explotación y la adoración desconectada de la justicia.

Abdías condenó la conducta de Edom hacia un vecino en apuros. Jonás se resistió a una misión, sobrevivió al mar y al pez, predicó en Nínive y se resintió ante la misericordia.

Ruth cerró los ojos un momento.

—Yo he sido Jonás después de que muriera la planta —dijo—. Molesta porque alguien más recibió bondad.

Miqueas puso a la vista la justicia, la misericordia y la humildad. Nahúm anunció la caída de Nínive. Habacuc cuestionó la injusticia y enfrentó una respuesta difícil. Sofonías advirtió del juicio y anticipó la restauración.

Hageo abordó la reconstrucción y las prioridades. Zacarías aportó visiones, ánimo y esperanza futura. Malaquías cuestionó las fallas en la adoración, la fidelidad y la justicia, y terminó con una promesa dirigida al futuro.

Escucharon libros distintos con preocupaciones distintas. El llamado repetido a atender a sus vecinos se hizo más claro porque habían permanecido atentas a las diferencias.

Lydia añadió la ayuda con las compras de los visitantes al orden del día de la siguiente reunión de la iglesia.

—Necesitamos voluntarios en la puerta —dijo—. Y una manera de preguntar qué ayuda quiere cada persona.

### Tres La advertencia que se abría hacia afuera

Detrás del marco de la ventana había un compartimento estrecho. Beth lo encontró mientras revisaba un tornillo flojo.

Dentro había un boletín de la iglesia y un boceto del baptisterio.

El boletín anunciaba una antigua exposición bíblica titulada **El parpadeo**. Ruth reconoció la fecha. Ella había ayudado a lavar las tazas al terminar.

—Ahora recuerdo el ojo —dijo—. Formaba parte de la última instalación.

Debajo del título estaba escrito el propósito de la exposición:

**Lee lo que vino antes. Lee lo que sigue. Deja hablar al pasaje completo.**

Anna abrió una colección digital de manuscritos antiguos. Miraron páginas y fragmentos conservados y comprendieron cuánto trabajo minucioso separaba un objeto escrito antiguo de una transcripción legible.

Ningún fragmento decía lo que a ellas se les antojara. Ninguna laguna las autorizaba a inventar una frase que faltaba.

June abrió la KJV en la referencia final de la exposición: 1 Corintios 15.

—Empezamos con media línea —dijo.

—Y heredamos parte de la emoción que la rodeaba —dijo Lydia.

El boceto señalaba un armario eléctrico, pero faltaba su llave.

En el reverso del boletín, Ellen había dibujado una mesa con un puesto extra.

En ese lugar había escrito:

**VEN Y VE.**

### En la mesa

Eligieron una práctica que su iglesia podía mejorar e identificaron a la persona que se beneficiaría. La primera respuesta vino de la propia visitante: un paso despejado, una mano ofrecida y permiso para rechazar la ayuda.

**Ruta de lectura:** Isaías; Jeremías; Lamentaciones; Ezequiel; Daniel; Oseas; Joel; Amós; Abdías; Jonás; Miqueas; Nahúm; Habacuc; Sofonías; Hageo; Zacarías; Malaquías, completos.
