# THE TWINKLING

## Edición en español

**Por Nathan Tabor**

## LIBRO UNO

### El ojo y el jardín

#### Uno El parpadeo

La reunión del miércoles por la noche había terminado, pero la iglesia todavía no había terminado de ser iglesia.

Alguien buscaba la tapa de una fuente para hornear. Alguien devolvía un paraguas prestado. En el salón de reuniones, un hombre que veinte minutos antes había orado con mucha solemnidad intentaba convencer a su esposa de que el pastel que quedaba necesitaba un hogar.

Ruth estaba junto al baptisterio, con la Biblia de su abuela apoyada contra la cadera.

—June, ¿pusiste eso ahí?

—Si es otro encargo de un comité, no.

Sobre el agua, un contorno pálido parecía formarse alrededor de la luz reflejada.

Un ojo.

Entonces las luces parpadearon.

Por un instante, aparecieron unas palabras debajo.

**EN UN MOMENTO, EN UN ABRIR Y CERRAR DE OJOS.**

Volvió la luz. Abajo, una silla rozó el suelo.

Anna miró a Lydia. Lydia miró a Ruth. June dejó de sonreír.

Beth acercó su silla de ruedas al baptisterio.

—Bueno —dijo—. Podemos quedarnos mirándolo o averiguar de dónde vino la luz.

La Biblia resbaló contra la mano de Ruth. Se cayó una hoja doblada.

En el anverso había un jardín dibujado a lápiz. Dos senderos se cruzaban por el centro.

En el reverso, con la letra de su abuela:

**Empieza antes del miedo.**

#### Dos Antes de esconderse

El sábado las encontró alrededor de la mesa de la cocina de Ruth. Cinco tazas. Una Biblia. Una lata de botones sobre la que Ruth se negaba a dar explicaciones.

Anna abrió Génesis.

Empezaron por la creación: la luz, la separación, las plantas, los animales, la humanidad y el descanso. Notaron que el relato llamaba buena a la creación antes de que nadie hubiera logrado nada.

—Antes de que hubiera un boletín de calificaciones —dijo Beth.

Ruth sonrió y luego bajó la mirada hacia sus propias manos.

En el jardín hubo un límite, una tentación, una decisión y un intento de esconderse. Adán culpó a la mujer. La mujer habló de la serpiente. Llegaron las consecuencias. Recibieron ropa. La vida siguió fuera del jardín.

Lydia recordó una ilustración de la escuela dominical en la que Eva parecía cargar ella sola con toda la culpa.

—Adán también está en el pasaje —dijo June—. Dejémoslo ahí.

Leyeron lo de Caín y Abel. Una ofrenda. Ira. Una advertencia. Un hermano asesinado. Una pregunta sobre la responsabilidad. Un juicio que incluía una marca para proteger a Caín de que otros lo mataran.

Anna escribió dos frases en tarjetas separadas.

**Un acto puede ser condenado.**

**Una vida todavía puede ser protegida.**

—Las dos cosas —dijo Ruth.

Leyeron el diluvio sin borrar las muertes. Siguieron la preservación de Noé, el pacto y, después, el fracaso posterior de la familia. Haber sobrevivido no los había vuelto perfectos.

Babel trajo una ciudad, una torre y la dispersión de las lenguas.

—Un plan compartido también puede necesitar un examen —dijo June.

Beth giró el dibujo del jardín hacia la ventana. Los senderos cruzados coincidían con los pliegues marcados a lápiz.

Una X.

En la intersección había una palabra.

**MIRA.**

#### Tres La familia de la túnica

Siguieron a Abraham y Sara por la partida, la promesa, la impaciencia y la risa. Se detuvieron con Agar el tiempo suficiente para reconocer a una mujer angustiada que era vista. Leyeron sobre el sacrificio que amenazaba a Isaac y su interrupción sin llamar agradable al terror.

Rebeca emprendió un viaje. Jacob engañó y fue engañado. Esaú perdió y más tarde abrazó. Lea y Raquel vivieron en una casa donde el afecto y la rivalidad estaban repartidos de manera desigual. El relato de Dina trajo daño y violencia de represalia; las mujeres se negaron a confundir cualquiera de las dos cosas con una protección que le devolviera la voz.

Entonces la túnica de José llegó a la mesa.

—Ahí está —dijo Lydia—. El favorito.

Los hermanos lo vendieron. Dejaron que su padre creyera que estaba muerto. En Egipto, José sufrió injusticias, interpretó sueños y finalmente organizó las reservas de alimentos para una hambruna. Su poder habría podido aplastar a sus hermanos cuando regresaron. En cambio, después de un difícil proceso de pruebas y revelaciones, proveyó para la familia.

—El bien que llega después no convierte la venta en un acto bueno —dijo Anna.

Ruth asintió.

—Pero significa que la venta no tuvo la última palabra.

Dentro de la Biblia, junto a Génesis 50, había un recorte de periódico. Describía al hijo de un predicador criado en una granja, el menor de tres hermanos, cuyo padre había sido criador de cerdos y, después, ministro y pintor. Se llamaba Nathan Tabor.

La nota manuscrita a su lado decía:

**Pregunta qué recibió el niño antes de decidir qué quiere decir el adulto.**

June la leyó dos veces.

Habían estado buscando un aparato encima del baptisterio. Ahora también examinaban la herencia: las palabras que una familia repite, los papeles que distribuye y las expectativas que un niño aprende antes de saber que son expectativas.

—¿Qué recibiste tú? —le preguntó Anna a Ruth.

Ruth tocó la Biblia de su abuela.

—Fe. Un lugar en la mesa. Y la sensación de que, si dejaba de trabajar, podía perder las dos cosas.

Nadie se apresuró a responder.

Lydia acercó el plato de pastel a su madre.

Dentro de la lata de botones, bajo un fondo falso, Beth encontró una llave de latón.

La etiqueta decía:

**LA PUERTA.**

#### En la mesa

Ruth empezó una página con dos encabezados: **Lo que recibí** y **Lo que elijo llevar conmigo**. Debajo de ambos escribió hospitalidad. Debajo del primero escribió agotamiento. Debajo del segundo dejó un espacio hasta estar lista para llenarlo.

**Ruta de lectura:** Génesis 1–50. El relato selecciona episodios principales; la lectura completa incluye genealogías, pactos, viajes, disputas familiares, bendiciones y muertes.

---

## LIBRO DOS

### La puerta y el desierto

#### Uno El armario cerrado

La llave abrió un armario del antiguo salón de clases, detrás del salón de reuniones.

Dentro había una puerta en miniatura con un hilo rojo sujeto en la parte superior, una cesta, un paño doblado y un mapa sin ningún camino señalado.

—¿Tu abuela usaba estas cosas para enseñar? —preguntó Beth.

—Cuando yo era pequeña —dijo Ruth—. Recuerdo la cesta.

Abrieron Éxodo.

Antes de que Moisés se presentara ante el faraón, las mujeres ya estaban actuando: unas parteras resistieron una orden asesina; una madre escondió a su bebé; una hermana vigiló; la hija del faraón acogió al niño.

—Todo el mundo recuerda al hombre del bastón —dijo Lydia.

June tocó la cesta.

—Lean quién lo ayudó a vivir lo suficiente para sostenerlo.

Moisés huyó después de matar a un egipcio. Años más tarde, la zarza ardiente lo llamó de regreso. Él protestó por su falta de capacidad. Aarón se unió a él. El enfrentamiento trajo plagas, Pascua, partida y el cruce del mar.

Nombraron la liberación y las muertes. La alegría por quienes escapaban de la esclavitud no exigía fingir que el relato carecía de dolor.

Junto al mar, Miriam cantó.

En el desierto, el pueblo se quejó.

Beth se recostó.

—La libertad te saca del lugar de antes. Todavía te deja necesitando desayunar.

Lydia se rio más de lo que la frase parecía justificar.

#### Dos Suficiente para hoy

El maná llegó con instrucciones sobre cómo recogerlo. Hacía falta agua. El consejo de Jetro ayudó a Moisés a compartir la responsabilidad en vez de atender él solo todas las disputas.

Lydia cerró la Biblia.

—He tratado el hecho de ser la persona a la que todos llaman como prueba de que estoy viviendo correctamente.

—Se te da bien —dijo Anna.

—Lo sé. Así fue como me escondí de la pregunta.

Volvió a abrirla.

En el Sinaí llegaron el pacto y los mandamientos. Después vinieron el becerro de oro, las tablas rotas, la intercesión y la renovación del pacto. Quienes habían recibido una instrucción clara seguían necesitando rendir cuentas y comenzar de nuevo.

Llegaron al tabernáculo y se detuvieron en las habilidades: tejer, tallar, ensamblar, diseñar, construir. La adoración requería manos además de palabras.

Beth desdobló el paño del armario. Tenía cinco bolsillos.

Uno contenía una pequeña escuadra de carpintero. Otro, una aguja. Los demás contenían una cuchara, un lápiz y una piedra lisa.

—Funciones diferentes —dijo June.

Beth apoyó la escuadra contra la puerta en miniatura.

Estaba torcida.

—Y la primera función de esta es admitir que algo necesita un ajuste.

#### Tres Las personas entre las líneas

Levítico las hizo avanzar más despacio.

Ofrendas, responsabilidades sacerdotales, normas de pureza, días sagrados, restitución, tierras y provisiones para quienes tenían poco. Era un antiguo sistema de pacto, y lo leyeron como tal antes de buscar aplicaciones modernas.

Se fijaron en la instrucción de dejar parte de la cosecha para el pobre y el extranjero.

—Se puede organizar la santidad de una manera que deje comida para alguien —dijo Lydia.

Números contó personas y registró viajes, quejas, rebeliones y pérdidas. Los exploradores vieron la tierra; el miedo agrandó los obstáculos. La burra de Balaam vio lo que Balaam no veía. Las hijas de Zelofehad llevaron una pregunta sobre la herencia ante la asamblea, y la ley respondió a su caso.

—La pregunta tiene un lugar en la sala —dijo Anna.

Deuteronomio volvió a contar el viaje. Recuerda. Enseña. Elige. Cuida de la viuda, del huérfano y del extranjero. Escucha las bendiciones y las advertencias. Moisés vio la tierra, pero murió antes de entrar en ella.

Ruth miró el mapa sin camino.

—Pensé que le faltaba algo.

Beth lo sostuvo contra la puerta en miniatura. Unos agujeros pequeños en el marco proyectaron puntos sobre el papel.

Cuando el ángulo fue el correcto, apareció una ruta.

—Necesitaba otra pieza —dijo Beth.

Lydia sacó el teléfono y llamó a otra mujer de la iglesia.

Le preguntó si podían repartir la siguiente comida de funeral entre tres hogares.

La mujer aceptó antes de que Lydia terminara de explicarlo.

Por un momento, Lydia pareció casi ofendida de que el mundo hubiera permitido aquello con tanta facilidad.

Después se rio.

En el extremo del mapa, los puntos rodeaban una corona.

#### En la mesa

Cada una eligió una responsabilidad para compartir, enseñar o reconsiderar. Ninguna tuvo que renunciar a una tarea que amaba. Lydia siguió preparando sopa. Otra persona recogería los platos.

**Ruta de lectura:** Éxodo 1–40; Levítico 1–27; Números 1–36; Deuteronomio 1–34. Las leyes y las listas siguen formando parte de la lectura, aun cuando la narración les da una aplicación a escala humana.

---

## LIBRO TRES

### La corona y la mesa de la cocina

#### Uno Un nombre en el margen

La corona señalaba un retrato en el álbum de fotos más antiguo de la iglesia.

La abuela de Ruth estaba junto a una mesa con una corona de papel en la mano. Detrás de ella, habían recortado de la fotografía el rostro de una mujer.

Anna no dijo escándalo. Dijo:

—Necesitamos otra copia.

Mientras buscaban, June abrió Josué.

El cruce del Jordán. Rahab dando refugio a los espías. Jericó. El robo oculto de Acán y sus consecuencias. Tierras repartidas. El pacto renovado.

No convirtieron los relatos de conquista en instrucciones para atacar a los vecinos de hoy. La violencia permaneció visible; las protagonistas preguntaron qué presentaban los textos acerca de la lealtad, el juicio y la responsabilidad, y en qué puntos una aplicación moderna exigía cuidado.

Jueces traía ciclos de fracaso y rescate. Débora juzgó. Gedeón dudó y actuó. El voto de Jefté devastó a su hija. La fuerza de Sansón no garantizó buen juicio. Los capítulos finales trajeron abusos y un conflicto civil tan graves que Ruth dejó de leer en voz alta.

—Podemos tomarnos un minuto —dijo June.

El acto esperanzador de aquella mañana fue dar espacio en la conversación a las personas dañadas, en vez de apresurarse hacia un héroe entretenido.

Entonces Ruth abrió el libro que llevaba su propio nombre.

Noemí perdió a su esposo y a sus hijos. Rut se quedó con ella. Un campo ofreció espigas para recoger; Booz ofreció protección y actuó conforme a los acuerdos de la comunidad. Después llegaron el matrimonio y un hijo.

—Todo el pueblo importa —dijo Lydia—. Comida. Seguridad. Testigos.

Beth señaló la fotografía recortada.

—Entonces encontremos a la mujer que perdió la foto del pueblo.

#### Dos La corona tiene una función

Primero de Samuel empezó con la angustia y la oración de Ana, y el nacimiento de Samuel. Samuel oyó un llamado. Israel pidió un rey. Saúl recibió autoridad y acabó perdiendo, por desobediencia, el futuro de su dinastía. David entró en el relato como un joven pastor y se convirtió en fugitivo antes de ser rey.

Segundo de Samuel no permitió que la corona protegiera a David de la verdad sobre Betsabé y Urías. Natán lo enfrentó. Entre las heridas posteriores de la casa estuvieron la violación de Tamar, la muerte de Amnón y la rebelión de Absalón.

—Un título no resuelve la cuestión —dijo Anna—. ¿Qué hizo la persona con el poder?

Reyes trajo la sabiduría, el templo, la riqueza y las lealtades divididas de Salomón; el reino dividido; profetas enfrentándose a gobernantes; el desafío y la huida de Elías; el ministerio de Eliseo; golpes de Estado, injusticia, reforma y derrumbe.

El aceite de la viuda interesó a Lydia. También la muchacha sirvienta, sin nombre en el relato, que orientó a Naamán hacia la ayuda.

Crónicas volvió a los antepasados, a David, a la organización del templo y a los reyes de Judá.

—Otra manera de contarlo —dijo June—. Debemos fijarnos en lo que decide destacar.

Beth encontró el soporte de la corona en un baúl. La abuela de Ruth había escrito tres encabezados:

**ATRIBUTOS. CARACTERÍSTICAS. FUNCIONALIDADES.**

Debajo:

**¿Qué está presente? ¿Qué sigue ocurriendo? ¿Qué hace?**

Ruth puso la corona de papel de su abuela sobre la mesa.

Parecía sorprendentemente pequeña.

#### Tres La fotografía recuperada

Esdras y Nehemías trajeron el regreso, la reconstrucción, la adoración, la ley, la oposición y decisiones difíciles sobre los límites de la comunidad. Algunas decisiones afectaron dolorosamente a las familias. Las mujeres hablaron de esos costos junto con la restauración.

Ester trajo un pueblo amenazado, una reina con acceso al poder, el llamado de Mardoqueo, un riesgo, banquetes preparados, una conspiración descubierta y una liberación seguida de violencia.

—Usó el acceso que tenía —dijo Anna—. También se preparó. El valor tenía un calendario.

June llegó la semana siguiente con otra copia de la fotografía.

La mujer que faltaba se llamaba Ellen. Una nota al dorso la identificaba como la persona que había pintado los decorados para las lecciones bíblicas.

Ahora Ruth la recordaba. Después de que Ellen se mudara, el agua había dañado el álbum. Alguien había recortado la parte deformada en vez de reemplazar toda la foto.

No había habido una conspiración.

Había habido un nombre perdido.

Anna escaneó la copia completa. Escribió el nombre de Ellen debajo de la imagen restaurada, junto a los nombres que ya conocían.

—Estábamos listas para atribuir un motivo antes de tener una segunda fotografía —dijo.

June sonrió.

—Es útil darnos cuenta de que estamos haciendo eso.

El fondo pintado por Ellen tenía cinco ventanas. Una estaba abierta.

A través de ella, alguien había pintado una silla y un libro.

En el lomo del libro:

**JOB.**

#### En la mesa

Preguntaron quién había realizado una tarea útil sin recibir reconocimiento. Añadieron los nombres que pudieron verificar. Donde no pudieron, dejaron el espacio honestamente en blanco.

**Ruta de lectura:** Josué; Jueces; Rut; 1–2 Samuel; 1–2 Reyes; 1–2 Crónicas; Esdras; Nehemías; Ester, completos.

---

## LIBRO CUATRO

### La pregunta y el silencio

#### Uno La silla junto a la cama

Ruth faltó a la siguiente reunión porque la hermana de June estaba en el hospital.

Aquella tarde no hubo búsqueda de pistas. Hubo una silla junto a una cama y una larga conversación sobre cosas corrientes.

Después, June admitió que había tenido miedo de que le correspondiera decir algo mejor.

—Te quedaste —dijo Ruth.

Cuando volvieron a Job, las pérdidas del comienzo se sintieron diferentes. Job perdió posesiones, hijos y salud. Sus amigos llegaron y al principio se sentaron en silencio. Más tarde ofrecieron explicaciones que trataban el sufrimiento como prueba en su contra.

Job discutió. Se lamentó. Quería una respuesta.

Las mujeres leyeron las escenas celestiales, las discusiones, los discursos de Eliú, la respuesta divina y la conclusión sin reducirlos a la opinión de una sola voz. Se fijaron en Job 42:7, donde se reprendía a los amigos por lo que habían dicho acerca de Dios.

Después llegó la restauración. June mantuvo un dedo sobre las pérdidas anteriores.

—El amor nuevo no borra a las personas que murieron.

Ruth asintió.

Nadie mejoró la frase.

#### Dos El himnario sin tapa

Salmos les dio alabanza, queja, confesión, confianza, ira, agradecimiento y una espera sin respuesta.

—Hemos cantado más a menudo los de confianza —dijo Lydia.

Leyeron el Salmo 13. Después el Salmo 23. Después el Salmo 88, que no terminaba con la resolución emocional que esperaban.

June escribió una pregunta en su cuaderno.

**¿Puedo hablar con honestidad antes de sentirme mejor?**

Proverbios ofreció observaciones sobre el habla, el trabajo, la generosidad, la ira, la disciplina, el juicio y la sabiduría. Anna comparó proverbios que abordaban situaciones diferentes.

—Las circunstancias importan —dijo—. Una frase sabia sigue necesitando a alguien que la lea con atención.

Llegaron a Proverbios 23:7 y leyeron la advertencia que lo rodeaba, sobre un anfitrión cuya generosidad aparente ocultaba un corazón calculador. La frase sobre pensar en el corazón tenía una escena concreta a su alrededor; podían hablar del pensamiento y la identidad sin hacer desaparecer esa escena.

Eclesiastés les permitió examinar el trabajo, el placer, la mortalidad, los límites, la injusticia, la compañía y los tiempos de la vida. Sus preguntas no cabían en una postal alegre.

Ruth miró hacia el jardín.

—Mi abuela plantó ese peral. Nunca probó una pera de él.

—Tú sí —dijo Anna.

Ruth sonrió.

—Sí.

#### Tres El amor con las luces encendidas

Cantar de los Cantares sorprendió a la mesa y la llevó al silencio, después a la risa y después a una conversación sobre el afecto que ninguna había esperado tener mientras comía panecillos.

Leyeron su poesía como poesía, con imágenes, anhelo, belleza y deleite mutuo. June explicó que los lectores religiosos también la habían abordado de manera alegórica. Esas eran tradiciones interpretativas; las imágenes de la página seguían mereciendo atención.

Beth encontró una cinta escondida detrás de la encuadernación de la Biblia familiar. La recorrían unas letras diminutas bordadas.

**Puedes leer la frase completa.**

—Eso parece menos dramático que un pasadizo secreto —dijo Lydia.

—Depende de la frase —respondió Beth.

Ruth recordó que le habían dicho que debía sentir gozo en toda circunstancia. Había amado la palabra y a veces la había usado para apresurarse a dejar atrás el dolor.

Aquella noche llamó a June después de la visita al hospital.

—¿Cómo estás?

—Cansada. Triste. Contentísima de que hayas llamado.

Las tres cosas tenían lugar en la respuesta.

La cinta terminaba en una ventanita bordada. Anna la relacionó con el cuadro de Ellen. En el alféizar pintado, casi oculta bajo el marco, había una referencia a un versículo.

**ISAÍAS 1.**

Habían llegado a la ventana del vigía.

#### En la mesa

Cada mujer eligió un salmo que coincidía con lo que sentía de verdad. Cualquiera podía guardar su elección para sí. Dejaron que una oración fuera sincera antes de pedirle que fuera elocuente.

**Ruta de lectura:** Job; Salmos; Proverbios; Eclesiastés; Cantar de los Cantares, completos. Las aplicaciones de los personajes no prometen que un cambio de interpretación cure al instante la enfermedad o el duelo.

---

## LIBRO CINCO

### El vigía y la ventana

#### Uno Lo que muestra la ventana

La ventana del cuadro de Ellen daba al estacionamiento de la iglesia.

A través de la ventana real, Lydia veía el lugar donde una visitante había esperado una vez que alguien la ayudara a llevar las compras hasta su coche.

Lydia había estado demasiado ocupada arreglando flores para darse cuenta.

Isaías confrontaba la injusticia y la práctica religiosa vacía. Sus visiones también hablaban de consuelo, restauración, un siervo y un futuro más amplio que la crisis inmediata.

Jeremías advertía en medio de la resistencia y el desastre. Lamentaciones lloraba por Jerusalén en vez de adornar su destrucción. Ezequiel traía visiones, rendición de cuentas, juicio, restauración y huesos secos que recibían vida.

—Podemos disfrutar de la imagen impresionante y pasar por alto a las personas que la rodean —dijo Anna.

Daniel situaba a personas fieles en las cortes imperiales: decisiones sobre la comida, sueños, un horno, un foso de leones y visiones de reinos. Las mujeres distinguieron los escenarios de los relatos de cada cronología moderna propuesta.

—Un parecido es una razón para examinar algo —dijo Beth—. Todavía necesitamos pruebas antes de anunciar una correspondencia.

Lo escribió debajo de los tres encabezados de la corona.

#### Dos Los libros pequeños con preguntas grandes

Oseas trajo la traición al pacto y las difíciles imágenes matrimoniales con las que el libro la expresaba. Joel trajo devastación, arrepentimiento y una efusión prometida. Amós confrontó la explotación y la adoración desconectada de la justicia.

Abdías condenó la conducta de Edom hacia un vecino en apuros. Jonás se resistió a una misión, sobrevivió al mar y al pez, predicó en Nínive y se resintió ante la misericordia.

Ruth cerró los ojos un momento.

—Yo he sido Jonás después de que muriera la planta —dijo—. Molesta porque alguien más recibió bondad.

Miqueas puso a la vista la justicia, la misericordia y la humildad. Nahúm anunció la caída de Nínive. Habacuc cuestionó la injusticia y enfrentó una respuesta difícil. Sofonías advirtió del juicio y anticipó la restauración.

Hageo abordó la reconstrucción y las prioridades. Zacarías aportó visiones, ánimo y esperanza futura. Malaquías cuestionó las fallas en la adoración, la fidelidad y la justicia, y terminó con una promesa dirigida al futuro.

Escucharon libros distintos con preocupaciones distintas. El llamado repetido a atender a sus vecinos se hizo más claro porque habían permanecido atentas a las diferencias.

Lydia añadió la ayuda con las compras de los visitantes al orden del día de la siguiente reunión de la iglesia.

—Necesitamos voluntarios en la puerta —dijo—. Y una manera de preguntar qué ayuda quiere cada persona.

#### Tres La advertencia que se abría hacia afuera

Detrás del marco de la ventana había un compartimento estrecho. Beth lo encontró mientras revisaba un tornillo flojo.

Dentro había un boletín de la iglesia y un boceto del baptisterio.

El boletín anunciaba una antigua exposición bíblica titulada **El parpadeo**. Ruth reconoció la fecha. Ella había ayudado a lavar las tazas al terminar.

—Ahora recuerdo el ojo —dijo—. Formaba parte de la última instalación.

Debajo del título estaba escrito el propósito de la exposición:

**Lee lo que vino antes. Lee lo que sigue. Deja hablar al pasaje completo.**

Anna abrió una colección digital de manuscritos antiguos. Miraron páginas y fragmentos conservados y comprendieron cuánto trabajo minucioso separaba un objeto escrito antiguo de una transcripción legible.

Ningún fragmento decía lo que a ellas se les antojara. Ninguna laguna las autorizaba a inventar una frase que faltaba.

June abrió la KJV en la referencia final de la exposición: 1 Corintios 15.

—Empezamos con media línea —dijo.

—Y heredamos parte de la emoción que la rodeaba —dijo Lydia.

El boceto señalaba un armario eléctrico, pero faltaba su llave.

En el reverso del boletín, Ellen había dibujado una mesa con un puesto extra.

En ese lugar había escrito:

**VEN Y VE.**

#### En la mesa

Eligieron una práctica que su iglesia podía mejorar e identificaron a la persona que se beneficiaría. La primera respuesta vino de la propia visitante: un paso despejado, una mano ofrecida y permiso para rechazar la ayuda.

**Ruta de lectura:** Isaías; Jeremías; Lamentaciones; Ezequiel; Daniel; Oseas; Joel; Amós; Abdías; Jonás; Miqueas; Nahúm; Habacuc; Sofonías; Hageo; Zacarías; Malaquías, completos.

---

## LIBRO SEIS

### La mesa y la tumba vacía

#### Uno Un lugar ya preparado

June invitó a cenar a una persona de la iglesia metodista y a una amiga de la congregación presbiteriana. Ruth se preocupó por los panecillos antes de que se le ocurriera preocuparse por las diferencias entre denominaciones.

Las recién llegadas reconocieron más cosas de aquella tarde de las que cualquiera había esperado: el plato llevado como regalo, la Biblia heredada, la preocupación por que todos tuvieran suficiente, la persona que empezaba a recoger los platos antes de terminar su propia comida.

Abrieron Mateo y Lucas y compararon los relatos del nacimiento sin fingir que estaban organizados de forma idéntica. María recibió un anuncio. José enfrentó una decisión. Elisabet acogió a María. En Lucas llegaron pastores; en Mateo aparecieron sabios. La violencia de Herodes y la huida a Egipto permanecieron en el relato de Mateo.

No construyeron una fecha moderna exacta del nacimiento a partir de detalles que no la proporcionaban.

Marcos entraba rápidamente en el ministerio de Jesús. Juan comenzaba con el Verbo y aportaba su propia organización de señales y conversaciones.

—Cuatro testigos en nuestra lectura —dijo Anna—. Debemos escuchar a cada uno antes de combinarlos.

Beth vio a alguien alargar automáticamente la mano hacia el plato de Ruth.

—Todavía está comiendo —dijo con suavidad.

La mano se detuvo. El plato se quedó.

#### Dos Quién está junto al camino

Siguieron a Jesús por el bautismo, la tentación, la enseñanza, la sanación, el llamado, los desacuerdos y las comidas.

La gente se acercaba con necesidades. Otros se acercaban con preguntas. Algunos querían ponerlo a prueba. Las mujeres notaron cuántas veces cambiaba una conversación porque alguien a quien la multitud trataba como una interrupción se convertía en la persona a la que él se dirigía.

La mujer samaritana tuvo una conversación extensa. Una mujer tocó una prenda. María escuchó; Marta trabajó y habló. Los niños fueron recibidos. Un ciego gritó. Zaqueo bajó de un árbol y habló de restitución.

June contó la parábola del buen samaritano con palabras sencillas: una persona fue herida, otros pasaron de largo, alguien se detuvo, la atendió, consiguió alojamiento y se hizo responsable del costo.

—Atributos —dijo Beth.

—Características —añadió Anna.

Lydia dejó la cuchara de servir.

—Función. Ayudó.

Leyeron al hijo pródigo y también se quedaron con el hermano mayor. El regreso era bienvenido; el resentimiento seguía afuera preguntando si la generosidad era justa.

En la Transfiguración, los discípulos vieron una revelación que los relatos evangélicos situaban dentro del camino de Jesús hacia el sufrimiento. Las mujeres podían admirar la montaña y seguirlo también cuando descendía.

El boceto de la mesa de Ellen incluía un dibujo diminuto debajo de una silla: un asno junto a la puerta de una ciudad.

Pasaron a la entrada en Jerusalén.

#### Tres Las mujeres en la tumba

Siguieron la última cena, el lavamiento de pies en Juan, el jardín, la traición, el arresto, los juicios, la negación, la crucifixión y la sepultura. No volvieron alegre el sufrimiento para conservar la dirección esperanzadora de los libros.

Lydia recordó a una amiga en duelo a la que le habían dicho que se regocijara antes de que nadie le preguntara si había dormido.

—Me sentaré con ella —dijo—. Y la dejaré contarme cómo es el día de hoy.

Después llegaron los relatos de la resurrección. Unas mujeres llegaron a la tumba. Siguieron anuncios y encuentros. Los Evangelios narraban los hechos con diferencias de selección y detalle; el grupo leyó cada relato en vez de suministrar una única transcripción inventada.

Tomás recibió un encuentro en medio de la duda. Pedro recibió palabras de restauración y responsabilidad. Los seguidores recibieron una misión.

Ruth leyó la lección de Pascua que había guardado entre los papeles de su abuela.

Al pie había una nota escrita para una persona que leía con miedo:

**Puedes traer tu pregunta contigo.**

Beth encontró la llave del armario eléctrico dentro de la carpeta de la lección. Alguien la había usado para sujetar un paquete de transparencias.

La llevaron a la iglesia a la mañana siguiente.

La puerta se abrió.

Dentro había un proyector pequeño, desenchufado, y una hoja de mantenimiento escrita a mano.

Anna leyó la primera anotación en voz alta.

—Instalación del ojo. No conectar al circuito de iluminación del santuario.

Beth miró hacia el baptisterio.

—Bueno —dijo—. Alguien lo hizo.

#### En la mesa

Preguntaron dónde podían hacer espacio a una persona cuya voz solía quedar ahogada por las demás. Sus respuestas incluyeron escuchar, devolver algo debido, ofrecer ayuda práctica y recibir ayuda ellas mismas.

**Ruta de lectura:** Mateo 1–28; Marcos 1–16; Lucas 1–24; Juan 1–21. Los relatos paralelos siguen pudiendo leerse individualmente. El manuscrito dramatiza las respuestas a ellos en vez de reemplazar su texto.

---

## LIBRO SIETE

### La carta y la puerta abierta

#### Uno El circuito reparado

Beth llamó a un electricista cualificado. La iglesia autorizó una reparación. El electricista encontró la alimentación de una antigua instalación conectada donde no debía; una falla intermitente explicaba el parpadeo. La diapositiva que aún conservaba el proyector explicaba el Ojo.

La reparación fue corriente, y todos sintieron alivio.

La pregunta que había despertado la diapositiva seguía importando.

Hechos las llevó a Pentecostés, la vida compartida, los conflictos, la persecución, la dispersión y los viajes. Las viudas necesitaban una distribución justa. Esteban murió. Felipe conoció a un viajero etíope. Saulo se convirtió en seguidor después de una campaña violenta contra la iglesia. Pedro entró en la casa de Cornelio. Lidia abrió su hogar. Priscila y Aquila ayudaron a Apolos a comprender con más precisión.

—Enseñar puede incluir recibir enseñanza —dijo June.

La reunión de Jerusalén abordó un desacuerdo real sobre los creyentes gentiles. Los viajes de Pablo incluyeron iglesias, discusiones, peligro, encarcelamiento y naufragio.

Las primeras comunidades tenían dones y problemas.

Lydia encontró consuelo en esa combinación.

#### Dos Cartas dirigidas a personas

Romanos examinaba el pecado, la fe, la gracia, la ley, Israel y una vida de servicio. Su exposición sobre la autoridad gobernante en el capítulo 13 se encontraba junto a instrucciones sobre el amor; las mujeres no trataron un pasaje sobre la autoridad pública como permiso para la venganza privada.

Primero de Corintios abordaba la división, la conducta, los cuerpos, el matrimonio, la comida, la adoración, los dones espirituales, el amor y la resurrección. Segundo de Corintios traía debilidad, reconciliación, generosidad y una autoridad cuestionada.

Gálatas cuestionaba las exigencias impuestas a los creyentes gentiles. Efesios describía la pertenencia y una manera de caminar moldeada por el evangelio. Filipenses hablaba de colaboración, humildad, perseverancia y gozo. Colosenses ponía a Cristo en el centro y advertía contra las enseñanzas que desplazaban ese centro.

Primero y Segundo de Tesalonicenses abordaban el ánimo, el duelo, la expectativa y la confusión sobre la venida del Señor. Las mujeres leyeron el consuelo junto con las advertencias. Vieron cómo una frase aislada podía convertirse en un mensaje mucho más estruendoso en la memoria de un niño.

Primero y Segundo de Timoteo y Tito trataban la enseñanza, el cuidado, el liderazgo, la conducta y la perseverancia. Filemón situaba una petición acerca de Onésimo dentro de una relación moldeada por la hermandad cristiana. Las mujeres nombraron la esclavitud que rodeaba la carta, en vez de tratar una petición bondadosa como si borrara la institución.

June volvió a 2 Timoteo 2:15 y a su frase sobre dividir correctamente la palabra de verdad.

Su pregunta práctica era sencilla.

—¿A quién se dirige, y qué estamos leyendo?

Anna añadió:

—¿Cuál es nuestra aplicación, y qué dijo realmente el pasaje?

#### Tres El cuaderno de la página suelta

Hebreos llamaba a perseverar y consideraba el sacerdocio, el sacrificio, el pacto y la fe. Santiago hacía práctica la fe en la conducta, el habla, la equidad y el cuidado. Primero de Pedro abordaba el sufrimiento y la esperanza. Segundo de Pedro advertía sobre las enseñanzas corruptas.

Las cartas de Juan examinaban la verdad, el amor, la comunión y la conducta. Judas advertía contra las personas destructivas dentro de la comunidad.

Lydia llegó a Santiago 1:27 y pensó en los turnos para preparar comidas, en las compras, en las personas que esperaban una llamada después de un funeral.

Escribió nombres junto a las tareas. También preguntó si esas personas querían la ayuda propuesta.

June presentó el último de los cuadernos de Ellen.

Dentro, el título provisional de la exposición estaba tachado.

**TODO PUEDE TERMINAR EN UN INSTANTE.**

Debajo, otra línea:

**TODO PUEDE COMENZAR EN UN INSTANTE.**

La nota de al lado era cuidadosa.

**Una nueva elección puede comenzar en un momento. Su trabajo puede llevar años.**

Ruth la leyó y sintió que se le relajaban los hombros.

No tenía que arreglar setenta y ocho años antes de la cena.

Podía pedirle a Anna que se quedara mientras hablaba de una cosa.

Al final del cuaderno, Ellen había dibujado siete candelabros y la puerta abierta de una ciudad.

Su última lectura esperaba.

#### En la mesa

Examinaron una frase heredada y mantuvieron separadas tres cosas: sus palabras reales, lo que habían oído en ellas y lo que elegían hacer ahora. Ninguna necesitaba estar de acuerdo con todas las conclusiones para escuchar con precisión.

**Ruta de lectura:** Hechos; Romanos; 1–2 Corintios; Gálatas; Efesios; Filipenses; Colosenses; 1–2 Tesalonicenses; 1–2 Timoteo; Tito; Filemón; Hebreos; Santiago; 1–2 Pedro; 1–3 Juan; Judas, completos.

---

## LIBRO OCHO

### El parpadeo y el comienzo

#### Uno Siete cartas antes del trueno

Empezaron Apocalipsis donde empezaba Apocalipsis: con su saludo, su visión y sus mensajes a siete iglesias.

June leyó despacio los nombres: Éfeso, Esmirna, Pérgamo, Tiatira, Sardis, Filadelfia, Laodicea.

Elogio y corrección. Perseverancia y concesiones. Puertas y lámparas. Un llamado a escuchar.

Las iglesias recibieron sus mensajes antes de que las mujeres llegaran a las visiones que habían ocupado tanto espacio en la imaginación de su infancia.

Siguieron la escena del trono, el rollo, los sellos, las trompetas, el conflicto, las bestias, los juicios, la caída de Babilonia, la victoria, el juicio final y la nueva creación. Las imágenes eran intensas. Reconocieron el sufrimiento que representaban en vez de convertir la catástrofe en entretenimiento.

June llevó tres comentarios que abordaban Apocalipsis de maneras diferentes. Compararon las lecturas sin fingir que el desacuerdo académico demostraba que todas las interpretaciones tenían la misma solidez, o que la confianza volvía indiscutible una interpretación.

—Primero marquemos lo que dice el texto —dijo Anna—. Después podemos examinar lo que cada persona cree que significa.

Ruth había pensado antes que este tipo de comparación debilitaría a quienes estaban en la sala.

La sala se volvió más silenciosa y más atenta.

#### Dos La ciudad con espacio

En Apocalipsis 21 y 22 leyeron sobre un cielo y una tierra nuevos, lágrimas enjugadas, el fin de la muerte, una ciudad, un río y un árbol cuyas hojas servían para sanar.

Ruth volvió a mirar el primer dibujo del jardín.

—Un jardín al principio —dijo.

—Y estas imágenes al final —respondió Anna.

Pusieron las ocho pistas sobre la mesa: el jardín, la puerta, la corona, la silla, la ventana, la mesa, la carta y la puerta de la ciudad.

Los reversos formaban una sola hoja grande. Ellen había dibujado una habitación y luego la había dividido en ocho piezas para las lecciones de su exposición.

Cinco sillas rodeaban una mesa.

En el centro había una Biblia abierta.

El Ojo había sido una instalación sobre la lectura. El versículo se había convertido en una pregunta familiar por lo que cada mujer había llevado consigo a la sala.

—Yo oí prisa —dijo Lydia.

—Yo oí pérdida —dijo Ruth.

—Yo oí un acertijo —dijo Beth.

June miró a Anna.

—Yo oí las palabras que faltaban —respondió Anna.

Volvieron a abrir 1 Corintios 15. El pasaje hablaba de resurrección, transformación, victoria sobre la muerte y trabajo constante. El parpadeo pertenecía a ese razonamiento. No se había escrito como una instrucción para que un niño viviera aterrorizado ante cada sonido repentino.

Ruth leyó la línea sobre ser transformados.

Después siguió leyendo.

#### Tres La frase completa

Las mujeres organizaron una nueva exposición en la iglesia. El proyector reparado quedó separado de las luces del santuario. Beth revisó que el recorrido por todas las instalaciones fuera accesible.

La llamaron **EL PARPADEO**.

En cada estación había un pasaje para leer, un relato en lenguaje sencillo y un espacio para anotar una pregunta. Los objetos históricos aparecían en fotografías con etiquetas de sus fuentes. El misterio de la familia inventada estaba identificado como ficción. Sus propios recuerdos se ofrecían como recuerdos.

A nadie se le pidió renunciar a su fe para entrar.

Nadie tuvo que contar una herida privada para completar el recorrido.

Una mujer mayor se quedó mucho tiempo junto a la instalación de la silla. Una mujer más joven leyó el capítulo completo detrás del Ojo. Dos hombres discutieron alegremente sobre las dimensiones de la puerta en miniatura antes de fijarse en el pasaje de al lado.

Lydia se sentó a comer mientras todavía quedaba comida.

Ruth la miró y sonrió.

June estaba junto a la mesa final. Una visitante preguntó si tenía que venir con un grupo.

—Puedes leerlo sola —dijo—. Puedes traer a tu familia. A tus amigos. A una clase. Las cinco preguntas caben alrededor de cualquier mesa.

Señaló el cuaderno:

**¿Qué recuerdo?**

**¿Qué pregunta llevo conmigo?**

**¿Qué patrón noto?**

**¿A quién afecta?**

**¿Qué podría hacer después?**

La visitante se sentó.

Ruth puso la Biblia de su abuela en el centro, abierta en vez de cerrada.

Aquella tarde, ella y Anna revisaron el álbum de fotografías. Añadieron nombres, corrigieron una fecha y dejaron una anotación incierta marcada como incierta.

Trabajo corriente.

Trabajo útil.

Anna preguntó qué quería escribir Ruth al final de su nueva página.

Ruth pensó un momento.

Después escribió:

**TODO PUEDE COMENZAR EN UN INSTANTE.**

Debajo:

**Mañana pediré ayuda antes de quedar agotada.**

Anna añadió su propia frase.

Beth ya había organizado la siguiente reunión. June llevaría las preguntas. Lydia llevaría sopa, porque quería hacerlo.

Afuera, el atardecer se posaba sobre las ventanas de la iglesia. Adentro, cinco mujeres seguían conversando.

El siguiente momento les pertenecía.

#### En la mesa

Elige una próxima acción lo bastante pequeña para nombrarla y lo bastante real para hacerla. Un comienzo puede ser una conversación, un límite, una llamada devuelta, una comida, una suposición corregida o una cita para recibir ayuda. No necesita borrar el pasado para cambiar lo que ocurre después.

**Ruta de lectura:** Apocalipsis 1–22; después, 1 Corintios 15 completo. La inversión final de la narración es una aplicación acerca de un comienzo, no una traducción sustitutiva de ninguno de los pasajes.

---

