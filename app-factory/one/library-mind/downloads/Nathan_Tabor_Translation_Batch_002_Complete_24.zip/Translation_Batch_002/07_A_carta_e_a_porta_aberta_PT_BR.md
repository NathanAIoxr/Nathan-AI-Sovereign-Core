# LIVRO SETE

## A carta e a porta aberta

### Um O circuito consertado

Beth chamou um eletricista qualificado. A igreja autorizou o conserto. O eletricista encontrou a alimentação de uma antiga instalação ligada onde não deveria estar; uma falha intermitente explicava o piscar. O slide que restara no projetor explicava o Olho.

O conserto foi comum, e todos ficaram aliviados.

A pergunta que o slide despertara continuava importante.

Atos as levou ao Pentecostes, à vida compartilhada, aos conflitos, à perseguição, à dispersão e às viagens. Viúvas precisavam de uma distribuição justa. Estêvão morreu. Filipe encontrou um viajante etíope. Saulo se tornou seguidor depois de uma campanha violenta contra a igreja. Pedro entrou na casa de Cornélio. Lídia abriu seu lar. Priscila e Áquila ajudaram Apolo a compreender com mais precisão.

— Ensinar pode incluir ser ensinada — disse June.

A reunião de Jerusalém tratou de uma discordância real sobre os crentes gentios. As viagens de Paulo incluíram igrejas, discussões, perigo, prisão e naufrágio.

As primeiras comunidades tinham dons e problemas.

Lydia encontrou conforto na combinação.

### Dois Cartas dirigidas a pessoas

Romanos examinava pecado, fé, graça, lei, Israel e uma vida de serviço. Sua discussão sobre a autoridade governante no capítulo 13 estava ao lado de instruções sobre o amor; as mulheres não trataram uma passagem sobre autoridade pública como permissão para vingança particular.

Primeira Coríntios abordava divisão, conduta, corpos, casamento, comida, adoração, dons espirituais, amor e ressurreição. Segunda Coríntios trazia fraqueza, reconciliação, generosidade e autoridade contestada.

Gálatas questionava exigências impostas aos crentes gentios. Efésios descrevia pertencimento e uma caminhada moldada pelo evangelho. Filipenses falava de parceria, humildade, perseverança e alegria. Colossenses colocava Cristo no centro e advertia contra ensinamentos que deslocavam esse centro.

Primeira e Segunda Tessalonicenses tratavam de encorajamento, luto, expectativa e confusão sobre a vinda do Senhor. As mulheres leram as palavras de consolo junto com os avisos. Viram por que uma frase isolada podia crescer e virar uma mensagem muito mais estrondosa na memória de uma criança.

Primeira e Segunda Timóteo e Tito tratavam de ensino, cuidado, liderança, conduta e perseverança. Filemom colocava um pedido sobre Onésimo dentro de uma relação moldada pela fraternidade cristã. As mulheres nomearam a escravidão ao redor da carta, em vez de tratar um pedido bondoso como se ele apagasse a instituição.

June voltou a 2 Timóteo 2:15 e à sua frase sobre dividir corretamente a palavra da verdade.

A pergunta prática dela era simples.

— A quem isso se dirige, e o que estamos lendo?

Anna acrescentou:

— Qual é a nossa aplicação, e o que a passagem realmente disse?

### Três O caderno com a página solta

Hebreus chamava à perseverança e examinava sacerdócio, sacrifício, aliança e fé. Tiago tornava a fé prática na conduta, na fala, na justiça e no cuidado. Primeira Pedro tratava de sofrimento e esperança. Segunda Pedro advertia sobre ensinamentos corruptos.

As cartas de João examinavam verdade, amor, comunhão e conduta. Judas advertia contra pessoas destrutivas dentro da comunidade.

Lydia chegou a Tiago 1:27 e pensou na escala das refeições, nas compras e nas pessoas esperando uma ligação depois de um funeral.

Escreveu nomes ao lado das tarefas. Também perguntou se as pessoas queriam a ajuda proposta.

June apresentou o último dos cadernos de Ellen.

Dentro, o título provisório da exposição tinha sido riscado.

**TUDO PODE TERMINAR NUM INSTANTE.**

Embaixo, outra linha:

**TUDO PODE COMEÇAR NUM INSTANTE.**

A anotação ao lado era cuidadosa.

**Uma nova escolha pode começar num momento. O trabalho dela pode levar anos.**

Ruth leu e sentiu os ombros relaxarem.

Não precisava consertar setenta e oito anos antes do jantar.

Podia pedir a Anna que ficasse enquanto ela falava sobre uma coisa.

No fim do caderno, Ellen tinha desenhado sete candelabros e o portão aberto de uma cidade.

A última leitura esperava por elas.

### À mesa

Elas examinaram uma frase herdada, mantendo três coisas separadas: suas palavras reais, o que tinham ouvido nela e o que escolhiam fazer agora. Ninguém precisava concordar com todas as conclusões para ouvir com precisão.

**Trilha de leitura:** Atos; Romanos; 1–2 Coríntios; Gálatas; Efésios; Filipenses; Colossenses; 1–2 Tessalonicenses; 1–2 Timóteo; Tito; Filemom; Hebreus; Tiago; 1–2 Pedro; 1–3 João; Judas, na íntegra.
