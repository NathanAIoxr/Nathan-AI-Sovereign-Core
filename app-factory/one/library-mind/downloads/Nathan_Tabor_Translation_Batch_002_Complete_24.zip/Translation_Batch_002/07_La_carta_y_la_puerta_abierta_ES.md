# LIBRO SIETE

## La carta y la puerta abierta

### Uno El circuito reparado

Beth llamó a un electricista cualificado. La iglesia autorizó una reparación. El electricista encontró la alimentación de una antigua instalación conectada donde no debía; una falla intermitente explicaba el parpadeo. La diapositiva que aún conservaba el proyector explicaba el Ojo.

La reparación fue corriente, y todos sintieron alivio.

La pregunta que había despertado la diapositiva seguía importando.

Hechos las llevó a Pentecostés, la vida compartida, los conflictos, la persecución, la dispersión y los viajes. Las viudas necesitaban una distribución justa. Esteban murió. Felipe conoció a un viajero etíope. Saulo se convirtió en seguidor después de una campaña violenta contra la iglesia. Pedro entró en la casa de Cornelio. Lidia abrió su hogar. Priscila y Aquila ayudaron a Apolos a comprender con más precisión.

—Enseñar puede incluir recibir enseñanza —dijo June.

La reunión de Jerusalén abordó un desacuerdo real sobre los creyentes gentiles. Los viajes de Pablo incluyeron iglesias, discusiones, peligro, encarcelamiento y naufragio.

Las primeras comunidades tenían dones y problemas.

Lydia encontró consuelo en esa combinación.

### Dos Cartas dirigidas a personas

Romanos examinaba el pecado, la fe, la gracia, la ley, Israel y una vida de servicio. Su exposición sobre la autoridad gobernante en el capítulo 13 se encontraba junto a instrucciones sobre el amor; las mujeres no trataron un pasaje sobre la autoridad pública como permiso para la venganza privada.

Primero de Corintios abordaba la división, la conducta, los cuerpos, el matrimonio, la comida, la adoración, los dones espirituales, el amor y la resurrección. Segundo de Corintios traía debilidad, reconciliación, generosidad y una autoridad cuestionada.

Gálatas cuestionaba las exigencias impuestas a los creyentes gentiles. Efesios describía la pertenencia y una manera de caminar moldeada por el evangelio. Filipenses hablaba de colaboración, humildad, perseverancia y gozo. Colosenses ponía a Cristo en el centro y advertía contra las enseñanzas que desplazaban ese centro.

Primero y Segundo de Tesalonicenses abordaban el ánimo, el duelo, la expectativa y la confusión sobre la venida del Señor. Las mujeres leyeron el consuelo junto con las advertencias. Vieron cómo una frase aislada podía convertirse en un mensaje mucho más estruendoso en la memoria de un niño.

Primero y Segundo de Timoteo y Tito trataban la enseñanza, el cuidado, el liderazgo, la conducta y la perseverancia. Filemón situaba una petición acerca de Onésimo dentro de una relación moldeada por la hermandad cristiana. Las mujeres nombraron la esclavitud que rodeaba la carta, en vez de tratar una petición bondadosa como si borrara la institución.

June volvió a 2 Timoteo 2:15 y a su frase sobre dividir correctamente la palabra de verdad.

Su pregunta práctica era sencilla.

—¿A quién se dirige, y qué estamos leyendo?

Anna añadió:

—¿Cuál es nuestra aplicación, y qué dijo realmente el pasaje?

### Tres El cuaderno de la página suelta

Hebreos llamaba a perseverar y consideraba el sacerdocio, el sacrificio, el pacto y la fe. Santiago hacía práctica la fe en la conducta, el habla, la equidad y el cuidado. Primero de Pedro abordaba el sufrimiento y la esperanza. Segundo de Pedro advertía sobre las enseñanzas corruptas.

Las cartas de Juan examinaban la verdad, el amor, la comunión y la conducta. Judas advertía contra las personas destructivas dentro de la comunidad.

Lydia llegó a Santiago 1:27 y pensó en los turnos para preparar comidas, en las compras, en las personas que esperaban una llamada después de un funeral.

Escribió nombres junto a las tareas. También preguntó si esas personas querían la ayuda propuesta.

June presentó el último de los cuadernos de Ellen.

Dentro, el título provisional de la exposición estaba tachado.

**TODO PUEDE TERMINAR EN UN INSTANTE.**

Debajo, otra línea:

**TODO PUEDE COMENZAR EN UN INSTANTE.**

La nota de al lado era cuidadosa.

**Una nueva elección puede comenzar en un momento. Su trabajo puede llevar años.**

Ruth la leyó y sintió que se le relajaban los hombros.

No tenía que arreglar setenta y ocho años antes de la cena.

Podía pedirle a Anna que se quedara mientras hablaba de una cosa.

Al final del cuaderno, Ellen había dibujado siete candelabros y la puerta abierta de una ciudad.

Su última lectura esperaba.

### En la mesa

Examinaron una frase heredada y mantuvieron separadas tres cosas: sus palabras reales, lo que habían oído en ellas y lo que elegían hacer ahora. Ninguna necesitaba estar de acuerdo con todas las conclusiones para escuchar con precisión.

**Ruta de lectura:** Hechos; Romanos; 1–2 Corintios; Gálatas; Efesios; Filipenses; Colosenses; 1–2 Tesalonicenses; 1–2 Timoteo; Tito; Filemón; Hebreos; Santiago; 1–2 Pedro; 1–3 Juan; Judas, completos.
