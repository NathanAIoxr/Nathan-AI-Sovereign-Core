# LIVRO OITO

## O piscar de olhos e o começo

### Um Sete cartas antes do trovão

Elas começaram Apocalipse onde Apocalipse começava: com sua saudação, visão e mensagens a sete igrejas.

June leu os nomes devagar: Éfeso, Esmirna, Pérgamo, Tiatira, Sardes, Filadélfia, Laodiceia.

Elogio e correção. Perseverança e concessões. Portas e lâmpadas. Um chamado para ouvir.

As igrejas receberam suas mensagens antes de as mulheres chegarem às visões que tinham ocupado tanto da imaginação de sua infância.

Elas acompanharam a cena do trono, o rolo, os selos, as trombetas, o conflito, as bestas, os julgamentos, a queda de Babilônia, a vitória, o julgamento final e a nova criação. As imagens eram intensas. Elas reconheceram o sofrimento representado em vez de transformar a catástrofe em entretenimento.

June trouxe três comentários que abordavam Apocalipse de maneiras diferentes. Elas compararam as leituras sem fingir que a discordância entre estudiosos provava que todas as interpretações eram igualmente sólidas, ou que a confiança tornava uma interpretação indiscutível.

— Vamos marcar primeiro o que o texto diz — disse Anna. — Depois podemos examinar o que cada pessoa acha que significa.

Ruth já tinha pensado que esse tipo de comparação enfraqueceria o grupo.

A sala ficou mais quieta e mais atenta.

### Dois A cidade com espaço

Em Apocalipse 21 e 22, elas leram sobre um novo céu e uma nova terra, lágrimas enxugadas, o fim da morte, uma cidade, um rio e uma árvore cujas folhas serviam para curar.

Ruth olhou de novo para o primeiro desenho do jardim.

— Um jardim no começo — disse ela.

— E essas imagens no fim — respondeu Anna.

Colocaram as oito pistas sobre a mesa: o jardim, a porta, a coroa, a cadeira, a janela, a mesa, a carta e o portão da cidade.

Os versos formavam uma folha grande. Ellen tinha desenhado uma sala e depois a dividido em oito partes para as lições da exposição.

Cinco cadeiras cercavam uma mesa.

No centro havia uma Bíblia aberta.

O Olho tinha sido uma instalação sobre leitura. O versículo se tornara uma questão de família por causa do que cada mulher levara para a sala.

— Eu ouvi pressa — disse Lydia.

— Eu ouvi perda — disse Ruth.

— Eu ouvi um enigma — disse Beth.

June olhou para Anna.

— Eu ouvi as palavras que faltavam — respondeu Anna.

Elas abriram 1 Coríntios 15 de novo. A passagem falava de ressurreição, transformação, vitória sobre a morte e trabalho constante. O piscar de olhos fazia parte daquele argumento. Não tinha sido escrito como instrução para uma criança permanecer aterrorizada com todo som repentino.

Ruth leu a linha sobre sermos transformados.

Depois continuou a leitura.

### Três A frase inteira

As mulheres organizaram uma nova exposição na igreja. O projetor consertado ficou separado das luzes do santuário. Beth verificou a acessibilidade do percurso por todas as instalações.

Deram a ela o nome de **O PISCAR DE OLHOS**.

Em cada estação havia uma passagem para ler, um relato em linguagem simples e espaço para registrar uma pergunta. Os objetos históricos apareciam em fotografias com identificação das fontes. O mistério da família inventada estava identificado como ficção. As próprias lembranças eram oferecidas como lembranças.

Ninguém precisava abrir mão da fé para entrar.

Ninguém tinha de revelar uma dor íntima para completar o percurso.

Uma mulher mais velha ficou muito tempo na instalação da cadeira. Uma mulher mais nova leu o capítulo inteiro por trás do Olho. Dois homens discutiram alegremente as dimensões da porta em miniatura antes de notar a passagem ao lado.

Lydia se sentou para comer enquanto ainda havia comida.

Ruth olhou para ela e sorriu.

June estava junto à mesa final. Uma visitante perguntou se precisava vir em grupo.

— Você pode ler sozinha — disse ela. — Pode trazer a família. Amigos. Uma turma. As cinco perguntas cabem em volta de qualquer mesa.

Ela apontou para o caderno:

**Do que eu me lembro?**

**Que pergunta estou carregando?**

**Que padrão percebo?**

**Quem é afetado?**

**O que eu poderia fazer a seguir?**

A visitante se sentou.

Ruth colocou a Bíblia da avó no centro, aberta em vez de fechada.

Naquela noite, ela e Anna revisaram o álbum de fotografias. Acrescentaram nomes, corrigiram uma data e deixaram uma informação incerta marcada como incerta.

Trabalho comum.

Trabalho útil.

Anna perguntou o que Ruth queria escrever no fim da nova página.

Ruth pensou por um momento.

Então escreveu:

**TUDO PODE COMEÇAR NUM INSTANTE.**

Embaixo:

**Amanhã vou pedir ajuda antes de ficar esgotada.**

Anna acrescentou a própria frase.

Beth já tinha organizado a reunião seguinte. June levaria as perguntas. Lydia levaria sopa, porque queria.

Lá fora, o anoitecer pousava sobre as janelas da igreja. Lá dentro, cinco mulheres continuavam conversando.

O momento seguinte pertencia a elas.

### À mesa

Escolha uma próxima ação pequena o bastante para nomear e real o bastante para fazer. Um começo pode ser uma conversa, um limite, uma ligação retornada, uma refeição, uma suposição corrigida ou uma consulta para receber ajuda. Ele não precisa apagar o passado para mudar o que acontece a seguir.

**Trilha de leitura:** Apocalipse 1–22; depois, 1 Coríntios 15 na íntegra. A inversão final da narrativa é uma aplicação sobre um começo, não uma tradução substituta de nenhuma das passagens.
