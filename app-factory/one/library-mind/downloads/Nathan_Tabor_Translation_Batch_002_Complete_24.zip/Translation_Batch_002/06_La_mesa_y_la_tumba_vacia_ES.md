# LIBRO SEIS

## La mesa y la tumba vacía

### Uno Un lugar ya preparado

June invitó a cenar a una persona de la iglesia metodista y a una amiga de la congregación presbiteriana. Ruth se preocupó por los panecillos antes de que se le ocurriera preocuparse por las diferencias entre denominaciones.

Las recién llegadas reconocieron más cosas de aquella tarde de las que cualquiera había esperado: el plato llevado como regalo, la Biblia heredada, la preocupación por que todos tuvieran suficiente, la persona que empezaba a recoger los platos antes de terminar su propia comida.

Abrieron Mateo y Lucas y compararon los relatos del nacimiento sin fingir que estaban organizados de forma idéntica. María recibió un anuncio. José enfrentó una decisión. Elisabet acogió a María. En Lucas llegaron pastores; en Mateo aparecieron sabios. La violencia de Herodes y la huida a Egipto permanecieron en el relato de Mateo.

No construyeron una fecha moderna exacta del nacimiento a partir de detalles que no la proporcionaban.

Marcos entraba rápidamente en el ministerio de Jesús. Juan comenzaba con el Verbo y aportaba su propia organización de señales y conversaciones.

—Cuatro testigos en nuestra lectura —dijo Anna—. Debemos escuchar a cada uno antes de combinarlos.

Beth vio a alguien alargar automáticamente la mano hacia el plato de Ruth.

—Todavía está comiendo —dijo con suavidad.

La mano se detuvo. El plato se quedó.

### Dos Quién está junto al camino

Siguieron a Jesús por el bautismo, la tentación, la enseñanza, la sanación, el llamado, los desacuerdos y las comidas.

La gente se acercaba con necesidades. Otros se acercaban con preguntas. Algunos querían ponerlo a prueba. Las mujeres notaron cuántas veces cambiaba una conversación porque alguien a quien la multitud trataba como una interrupción se convertía en la persona a la que él se dirigía.

La mujer samaritana tuvo una conversación extensa. Una mujer tocó una prenda. María escuchó; Marta trabajó y habló. Los niños fueron recibidos. Un ciego gritó. Zaqueo bajó de un árbol y habló de restitución.

June contó la parábola del buen samaritano con palabras sencillas: una persona fue herida, otros pasaron de largo, alguien se detuvo, la atendió, consiguió alojamiento y se hizo responsable del costo.

—Atributos —dijo Beth.

—Características —añadió Anna.

Lydia dejó la cuchara de servir.

—Función. Ayudó.

Leyeron al hijo pródigo y también se quedaron con el hermano mayor. El regreso era bienvenido; el resentimiento seguía afuera preguntando si la generosidad era justa.

En la Transfiguración, los discípulos vieron una revelación que los relatos evangélicos situaban dentro del camino de Jesús hacia el sufrimiento. Las mujeres podían admirar la montaña y seguirlo también cuando descendía.

El boceto de la mesa de Ellen incluía un dibujo diminuto debajo de una silla: un asno junto a la puerta de una ciudad.

Pasaron a la entrada en Jerusalén.

### Tres Las mujeres en la tumba

Siguieron la última cena, el lavamiento de pies en Juan, el jardín, la traición, el arresto, los juicios, la negación, la crucifixión y la sepultura. No volvieron alegre el sufrimiento para conservar la dirección esperanzadora de los libros.

Lydia recordó a una amiga en duelo a la que le habían dicho que se regocijara antes de que nadie le preguntara si había dormido.

—Me sentaré con ella —dijo—. Y la dejaré contarme cómo es el día de hoy.

Después llegaron los relatos de la resurrección. Unas mujeres llegaron a la tumba. Siguieron anuncios y encuentros. Los Evangelios narraban los hechos con diferencias de selección y detalle; el grupo leyó cada relato en vez de suministrar una única transcripción inventada.

Tomás recibió un encuentro en medio de la duda. Pedro recibió palabras de restauración y responsabilidad. Los seguidores recibieron una misión.

Ruth leyó la lección de Pascua que había guardado entre los papeles de su abuela.

Al pie había una nota escrita para una persona que leía con miedo:

**Puedes traer tu pregunta contigo.**

Beth encontró la llave del armario eléctrico dentro de la carpeta de la lección. Alguien la había usado para sujetar un paquete de transparencias.

La llevaron a la iglesia a la mañana siguiente.

La puerta se abrió.

Dentro había un proyector pequeño, desenchufado, y una hoja de mantenimiento escrita a mano.

Anna leyó la primera anotación en voz alta.

—Instalación del ojo. No conectar al circuito de iluminación del santuario.

Beth miró hacia el baptisterio.

—Bueno —dijo—. Alguien lo hizo.

### En la mesa

Preguntaron dónde podían hacer espacio a una persona cuya voz solía quedar ahogada por las demás. Sus respuestas incluyeron escuchar, devolver algo debido, ofrecer ayuda práctica y recibir ayuda ellas mismas.

**Ruta de lectura:** Mateo 1–28; Marcos 1–16; Lucas 1–24; Juan 1–21. Los relatos paralelos siguen pudiendo leerse individualmente. El manuscrito dramatiza las respuestas a ellos en vez de reemplazar su texto.
