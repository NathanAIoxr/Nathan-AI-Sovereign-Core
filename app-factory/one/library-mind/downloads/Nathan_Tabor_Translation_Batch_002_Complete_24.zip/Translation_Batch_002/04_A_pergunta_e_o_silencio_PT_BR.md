# LIVRO QUATRO

## A pergunta e o silêncio

### Um A cadeira ao lado da cama

Ruth faltou à reunião seguinte porque a irmã de June estava no hospital.

Não houve busca por pistas naquela noite. Houve uma cadeira ao lado de uma cama e uma longa conversa sobre coisas comuns.

Depois, June admitiu que tinha ficado com medo de que devesse dizer alguma coisa melhor.

— Você ficou — disse Ruth.

Quando voltaram a Jó, as perdas do início pareceram diferentes. Jó perdeu bens, filhos e saúde. Seus amigos chegaram e, primeiro, se sentaram em silêncio. Mais tarde, ofereceram explicações que tratavam o sofrimento como prova contra ele.

Jó discutiu. Lamentou. Queria uma resposta.

As mulheres leram as cenas celestiais, os argumentos, os discursos de Eliú, a resposta divina e a conclusão sem reduzir tudo à opinião de um único interlocutor. Perceberam que Jó 42:7 repreendia o que os amigos tinham dito sobre Deus.

A restauração veio depois. June manteve um dedo nas perdas anteriores.

— Um amor novo não apaga as pessoas que morreram.

Ruth assentiu.

Ninguém melhorou a frase.

### Dois O hinário sem capa

Salmos lhes deu louvor, queixa, confissão, confiança, raiva, gratidão e espera sem resposta.

— Temos cantado mais os de confiança — disse Lydia.

Leram o Salmo 13. Depois o Salmo 23. Depois o Salmo 88, que não terminava com a resolução emocional que esperavam.

June escreveu uma pergunta no caderno.

**Posso falar com honestidade antes de me sentir melhor?**

Provérbios trouxe observações sobre fala, trabalho, generosidade, raiva, disciplina, julgamento e sabedoria. Anna comparou provérbios que tratavam de situações diferentes.

— A circunstância importa — disse ela. — Uma frase sábia ainda precisa de alguém lendo com atenção.

Chegaram a Provérbios 23:7 e leram o aviso ao redor dele sobre um anfitrião cuja generosidade aparente escondia um coração calculista. A frase sobre pensar no próprio coração tinha uma cena específica à sua volta; elas podiam discutir pensamento e identidade sem fazer aquela cena desaparecer.

Eclesiastes permitiu que examinassem trabalho, prazer, mortalidade, limites, injustiça, companhia e estações da vida. Suas perguntas não cabiam em um cartão-postal alegre.

Ruth olhou para o jardim.

— Minha avó plantou aquela pereira. Nunca provou uma pera dela.

— Você provou — disse Anna.

Ruth sorriu.

— Sim.

### Três Amor com as luzes acesas

Cantares de Salomão surpreendeu a mesa, levando primeiro ao silêncio, depois ao riso e depois a uma conversa sobre afeto que ninguém esperava ter enquanto comia pãezinhos.

Elas leram sua poesia como poesia, com imagens, desejo, beleza e prazer mútuo. June explicou que leitores religiosos também a tinham abordado de forma alegórica. Aquelas eram tradições interpretativas; as imagens na página ainda mereciam atenção.

Beth encontrou uma fita escondida atrás da encadernação da Bíblia da família. Letras minúsculas bordadas percorriam a fita.

**Você pode ler a frase inteira.**

— Isso parece menos dramático do que uma passagem secreta — disse Lydia.

— Depende da frase — respondeu Beth.

Ruth se lembrou de ouvir que devia ter alegria em toda circunstância. Amara a palavra e às vezes a usara para se apressar a passar pelo luto.

Naquela noite, ligou para June depois da visita ao hospital.

— Como você está?

— Cansada. Triste. Feliz porque você ligou.

As três coisas cabiam na resposta.

A fita terminava numa pequena janela bordada. Anna a relacionou com a pintura de Ellen. Ao longo do peitoril pintado, quase escondida debaixo da moldura, havia uma referência de versículo.

**ISAÍAS 1.**

Elas tinham chegado à janela do vigia.

### À mesa

Cada mulher escolheu um salmo que combinava com o que realmente sentia. Qualquer uma podia guardar sua escolha para si. Elas deixaram a oração ser verdadeira antes de pedir que fosse eloquente.

**Trilha de leitura:** Jó; Salmos; Provérbios; Eclesiastes; Cantares de Salomão, na íntegra. As aplicações das personagens não prometem que mudar uma interpretação cure instantaneamente uma doença ou o luto.
