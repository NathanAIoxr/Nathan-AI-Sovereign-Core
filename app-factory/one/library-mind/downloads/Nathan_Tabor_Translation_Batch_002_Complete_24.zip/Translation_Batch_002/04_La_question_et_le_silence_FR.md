# LIVRE QUATRE

## La question et le silence

### Un La chaise près du lit

Ruth manqua la réunion suivante parce que la sœur de June était à l’hôpital.

Il n’y eut pas de chasse aux indices ce soir-là. Il y eut une chaise près d’un lit et une longue conversation sur des choses ordinaires.

Ensuite, June admit qu’elle avait craint de devoir dire quelque chose de mieux.

— Tu es restée, dit Ruth.

Lorsqu’elles revinrent à Job, les pertes du début résonnèrent autrement. Job perdit ses biens, ses enfants et sa santé. Ses amis arrivèrent et s’assirent d’abord en silence. Plus tard, ils fournirent des explications qui traitaient sa souffrance comme une preuve contre lui.

Job contesta. Il se lamenta. Il voulait une réponse.

Les femmes lurent les scènes célestes, les débats, les discours d’Élihu, la réponse divine et la conclusion sans tout réduire à l’opinion d’un seul interlocuteur. Elles remarquèrent qu’en Job 42:7, les amis étaient repris pour leurs paroles au sujet de Dieu.

La restauration suivit. June garda un doigt posé sur les pertes antérieures.

— Un amour nouveau n’efface pas les personnes qui sont mortes.

Ruth acquiesça.

Personne ne perfectionna la phrase.

### Deux Le recueil de cantiques sans couverture

Les Psaumes leur donnèrent la louange, la plainte, la confession, la confiance, la colère, la reconnaissance et l’attente sans réponse.

— Nous avons chanté plus souvent ceux qui expriment la confiance, dit Lydia.

Elles lurent le Psaume 13. Puis le Psaume 23. Puis le Psaume 88, qui ne se terminait pas par l’apaisement émotionnel qu’elles attendaient.

June écrivit une question dans son carnet.

**Puis-je parler honnêtement avant de me sentir mieux ?**

Les Proverbes offraient des observations sur la parole, le travail, la générosité, la colère, la discipline, le jugement et la sagesse. Anna compara des proverbes qui traitaient de situations différentes.

— Les circonstances comptent, dit-elle. Une phrase sage a toujours besoin de quelqu’un qui la lise avec attention.

Elles arrivèrent à Proverbes 23:7 et lurent l’avertissement qui l’entourait, au sujet d’un hôte dont la générosité apparente cachait un cœur calculateur. La phrase sur ce que l’on pense en son cœur avait une scène précise autour d’elle ; elles pouvaient discuter de la pensée et de l’identité sans faire disparaître cette scène.

L’Ecclésiaste leur permit d’examiner le travail, le plaisir, la mortalité, les limites, l’injustice, la compagnie des autres et les saisons de la vie. Ses questions ne tenaient pas sur une carte postale joyeuse.

Ruth regarda vers le jardin.

— Ma grand-mère a planté ce poirier. Elle n’en a jamais goûté une poire.

— Toi, si, dit Anna.

Ruth sourit.

— Oui.

### Trois L’amour, lumières allumées

Le Cantique des cantiques surprit la tablée au point de la plonger dans le silence, puis dans le rire, puis dans une discussion sur l’affection que personne n’avait prévu d’avoir autour de petits pains.

Elles lurent sa poésie comme de la poésie, avec ses images, son désir, sa beauté et son plaisir partagé. June expliqua que des lecteurs religieux l’avaient aussi abordée de manière allégorique. C’étaient des traditions d’interprétation ; les images sur la page méritaient toujours leur attention.

Beth trouva un ruban glissé derrière la reliure de la Bible familiale. De minuscules lettres brodées couraient le long du tissu.

**Tu peux lire la phrase entière.**

— Ça paraît moins spectaculaire qu’un passage secret, dit Lydia.

— Ça dépend de la phrase, répondit Beth.

Ruth se souvint qu’on lui avait dit de garder la joie en toute circonstance. Elle avait aimé ce mot et s’en était parfois servie pour se presser de dépasser son chagrin.

Ce soir-là, elle appela June après la visite à l’hôpital.

— Comment vas-tu ?

— Fatiguée. Triste. Contente que tu aies appelé.

Les trois avaient leur place dans la réponse.

Le ruban se terminait par une petite fenêtre brodée. Anna la rapprocha du tableau d’Ellen. Sur le rebord peint, presque dissimulée sous le cadre, figurait une référence de verset.

**ÉSAÏE 1.**

Elles avaient atteint la fenêtre du guetteur.

### À table

Chaque femme choisit un psaume qui correspondait à ce qu’elle ressentait vraiment. Chacune pouvait garder son choix pour elle. Elles laissèrent une prière être sincère avant de lui demander d’être éloquente.

**Parcours de lecture :** Job ; Psaumes ; Proverbes ; Ecclésiaste ; Cantique des cantiques, en entier. Les applications des personnages ne promettent pas qu’un changement d’interprétation guérisse instantanément la maladie ou le deuil.
