# BUCH ZWEI

## Die Tür und die Wüste

### Eins Der verschlossene Schrank

Der Schlüssel öffnete einen Schrank im alten Unterrichtsraum hinter dem Gemeindesaal.

Darin befanden sich das Modell eines Türrahmens, an dessen Oberseite ein roter Faden befestigt war, ein Korb, ein gefaltetes Tuch und eine Karte, auf der kein Weg eingezeichnet war.

„Damit hat deine Großmutter unterrichtet?“, fragte Beth.

„Als ich klein war“, sagte Ruth. „An den Korb erinnere ich mich.“

Sie schlugen das zweite Buch Mose auf.

Bevor Mose vor dem Pharao stand, handelten bereits Frauen: Hebammen widersetzten sich einem Mordbefehl; eine Mutter versteckte ihr Kind; eine Schwester hielt Wache; die Tochter des Pharaos nahm das Kind auf.

„Alle erinnern sich an den Mann mit dem Stab“, sagte Lydia.

June berührte den Korb. „Lest, wer ihm geholfen hat, lange genug zu leben, um ihn halten zu können.“

Mose floh, nachdem er einen Ägypter getötet hatte. Jahre später rief ihn der brennende Dornbusch zurück. Er wandte ein, dass er nicht geeignet sei. Aaron schloss sich ihm an. Die Auseinandersetzung brachte Plagen, Passah, Aufbruch und den Durchzug durchs Meer.

Sie benannten die Befreiung und die Todesfälle. Die Freude für Menschen, die der Knechtschaft entkamen, verlangte nicht, so zu tun, als enthielte der Bericht keine Trauer.

Am Meer sang Mirjam.

In der Wüste klagte das Volk.

Beth lehnte sich zurück. „Freiheit bringt dich aus dem alten Ort heraus. Frühstück brauchst du trotzdem noch.“

Lydia lachte heftiger, als der Satz es zu verlangen schien.

### Zwei Genug für heute

Das Manna kam mit Anweisungen zum Sammeln. Wasser wurde gebraucht. Jitros Rat half Mose, Verantwortung zu teilen, statt jeden Streit selbst anzuhören.

Lydia klappte die Bibel zu.

„Ich habe es als Beweis dafür genommen, dass ich mein Leben richtig führe, wenn ich diejenige bin, die alle anrufen.“

„Du kannst das gut“, sagte Anna.

„Ich weiß. So habe ich mich vor der Frage versteckt.“

Sie schlug die Bibel wieder auf.

Am Sinai kamen Bund und Gebote. Dann kamen das goldene Kalb, zerbrochene Tafeln, Fürbitte und ein erneuerter Bund. Die Menschen, die eine klare Anweisung erhalten hatten, brauchten trotzdem Rechenschaft und einen neuen Anfang.

Sie erreichten die Stiftshütte und verweilten bei den Fertigkeiten: weben, schnitzen, verbinden, entwerfen, herstellen. Gottesdienst brauchte Hände ebenso wie Worte.

Beth entfaltete das Tuch aus dem Schrank. Es hatte fünf Taschen.

In einer lag ein kleiner Zimmermannswinkel. In einer anderen eine Nadel. Die übrigen enthielten einen Löffel, einen Bleistift und einen glatten Stein.

„Verschiedene Funktionen“, sagte June.

Beth legte den Winkel an die Modelltür.

Sie war schief.

„Und die erste Funktion von diesem hier besteht darin, zuzugeben, dass etwas angepasst werden muss.“

### Drei Die Menschen zwischen den Zeilen

Das dritte Buch Mose ließ sie langsamer werden.

Opfergaben, priesterliche Pflichten, Reinheitsregeln, Feiertage, Wiedergutmachung, Land und Versorgung für Menschen, die wenig besaßen. Es war ein altes, auf einem Bund beruhendes System, und sie lasen es als solches, bevor sie Bezüge zur Gegenwart herstellten.

Ihnen fiel die Anweisung auf, einen Teil der Ernte für die Armen und die Fremden stehen zu lassen.

„Man kann Heiligkeit so organisieren, dass jemand etwas zu essen übrig bleibt“, sagte Lydia.

Das vierte Buch Mose zählte Menschen und hielt Reisen, Klagen, Auflehnung und Verluste fest. Kundschafter sahen das Land; Angst vergrößerte die Hindernisse. Bileams Eselin sah, was Bileam nicht sah. Die Töchter Zelofhads brachten eine Erbfrage vor die Versammlung, und das Gesetz gab eine Antwort auf ihren Fall.

„Die Frage gehört in den Raum“, sagte Anna.

Das fünfte Buch Mose erzählte die Reise noch einmal. Erinnere dich. Lehre. Wähle. Sorge für die Witwe, die Waisen und die Fremden. Höre die Segnungen und die Warnungen. Mose sah das Land, starb jedoch, bevor er es betrat.

Ruth betrachtete die Karte ohne Weg.

„Ich dachte, hier fehlt etwas.“

Beth hielt sie an die Modelltür. Kleine Löcher im Rahmen warfen Punkte auf das Papier.

Ein Weg erschien, als der Winkel stimmte.

„Es brauchte noch ein anderes Teil“, sagte Beth.

Lydia nahm ihr Handy heraus und rief eine andere Frau aus der Gemeinde an.

Sie fragte, ob sie das nächste Essen nach einer Beerdigung auf drei Haushalte aufteilen könnten.

Die Frau sagte zu, bevor Lydia ihre Erklärung beendet hatte.

Für einen Moment sah Lydia beinahe beleidigt aus, weil die Welt das so einfach zugelassen hatte.

Dann lachte sie.

Am gegenüberliegenden Rand der Karte umgaben die Punkte eine Krone.

### Am Tisch

Jede wählte eine Aufgabe aus, die sie teilen, jemand anderem beibringen oder überdenken wollte. Niemand musste eine Aufgabe aufgeben, die sie liebte. Lydia kochte weiterhin Suppe. Jemand anderes würde das Geschirr einsammeln.

**Lesepfad:** 2. Mose 1–40; 3. Mose 1–27; 4. Mose 1–36; 5. Mose 1–34. Gesetze und Listen bleiben Teil der Lektüre, auch wenn die Erzählung sie auf den menschlichen Alltag bezieht.

---
