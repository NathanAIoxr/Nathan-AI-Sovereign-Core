# BUCH EINS

## Das Auge und der Garten

### Eins Das Flackern

Der Mittwochabend war vorbei, aber die Kirche hatte noch nicht aufgehört, Kirche zu sein.

Jemand suchte den Deckel einer Auflaufform. Jemand gab einen geliehenen Regenschirm zurück. Im Gemeindesaal versuchte ein Mann, der zwanzig Minuten zuvor sehr feierlich gebetet hatte, seiner Frau einzureden, dass der übrige Kuchen ein Zuhause brauchte.

Ruth stand in der Nähe des Taufbeckens und stützte die Bibel ihrer Großmutter gegen ihre Hüfte.

„June, hast du das dort hingetan?“

„Wenn es noch eine Aufgabe für einen Ausschuss ist: nein.“

Über dem Wasser schien sich um das gespiegelte Licht ein blasser Umriss zu bilden.

Ein Auge.

Dann flackerte das Licht.

Für einen Augenblick erschienen darunter Worte.

**IN EINEM AUGENBLICK, IN EINEM AUGENZWINKERN.**

Das Licht kehrte zurück. Unten scharrte ein Stuhl über den Boden.

Anna sah Lydia an. Lydia sah Ruth an. June lächelte nicht mehr.

Beth rollte näher an das Taufbecken heran.

„Nun“, sagte sie. „Wir können es anstarren, oder wir können herausfinden, woher das Licht kam.“

Die Bibel rutschte an Ruths Hand entlang. Ein gefaltetes Blatt fiel heraus.

Auf der Vorderseite war mit Bleistift ein Garten gezeichnet. Durch seine Mitte führten zwei Wege, die sich kreuzten.

Auf der Rückseite stand in der Handschrift ihrer Großmutter:

**Fang vor der Angst an.**

### Zwei Bevor das Verstecken begann

Am Samstag saßen sie um Ruths Küchentisch. Fünf Tassen. Eine Bibel. Eine Dose voller Knöpfe, zu der Ruth jede Erklärung verweigerte.

Anna schlug das erste Buch Mose auf.

Sie begannen mit der Schöpfung: Licht, Trennung, Pflanzen, Geschöpfe, Menschen und Ruhe. Ihnen fiel auf, dass der Bericht die Schöpfung gut nannte, bevor irgendjemand etwas geleistet hatte.

„Bevor es ein Zeugnis gab“, sagte Beth.

Ruth lächelte und blickte dann auf ihre eigenen Hände.

Im Garten kamen eine Grenze, eine Versuchung, eine Entscheidung und das Verstecken. Adam gab der Frau die Schuld. Die Frau sprach von der Schlange. Folgen schlossen sich an. Kleidung wurde bereitgestellt. Das Leben ging außerhalb des Gartens weiter.

Lydia erinnerte sich an ein Bild aus der Sonntagsschule, auf dem Eva die ganze Schuld allein zu tragen schien.

„Adam steht auch in dem Abschnitt“, sagte June. „Lassen wir ihn dort.“

Sie lasen von Kain und Abel. Ein Opfer. Zorn. Eine Warnung. Ein getöteter Bruder. Eine Frage nach Verantwortung. Ein Urteil, zu dem ein Zeichen gehörte, das Kain davor schützte, von anderen getötet zu werden.

Anna schrieb zwei Sätze auf getrennte Karten.

**Eine Tat kann verurteilt werden.**

**Ein Leben kann trotzdem geschützt werden.**

„Beides“, sagte Ruth.

Sie lasen von der Flut, ohne die Toten verschwinden zu lassen. Sie verfolgten Noahs Bewahrung, den Bund und dann das spätere Versagen der Familie. Das Überleben hatte sie nicht fehlerlos gemacht.

Babel brachte eine Stadt, einen Turm und die Zerstreuung der Sprachen.

„Auch ein gemeinsamer Plan kann einer Prüfung bedürfen“, sagte June.

Beth drehte die Gartenzeichnung zum Fenster. Die sich kreuzenden Wege verliefen entlang der mit Bleistift nachgezogenen Falten.

Ein X.

Am Schnittpunkt stand ein einziges Wort.

**SCHAU.**

### Drei Die Familie mit dem Gewand

Sie folgten Abraham und Sara durch Aufbruch, Verheißung, Ungeduld und Lachen. Sie blieben lange genug bei Hagar, um wahrzunehmen, dass eine Frau in Not gesehen wurde. Sie lasen von Isaaks drohender Opferung und ihrer Unterbrechung, ohne den Schrecken angenehm zu nennen.

Rebekka trat eine Reise an. Jakob täuschte und wurde getäuscht. Esau verlor und umarmte später. Lea und Rahel lebten in einem Haushalt, in dem Zuneigung und Rivalität ungleich verteilt waren. Dinas Geschichte brachte Leid und Vergeltungsgewalt; die Frauen weigerten sich, eines von beidem mit einem Schutz zu verwechseln, der ihr ihre Stimme zurückgegeben hätte.

Dann kam Josefs Gewand auf den Tisch.

„Da ist er“, sagte Lydia. „Der Liebling.“

Die Brüder verkauften ihn. Sie ließen ihren Vater glauben, er sei tot. In Ägypten erlitt Josef Unrecht, deutete Träume und organisierte schließlich Lebensmittel für eine Hungersnot. Seine Macht hätte die Brüder vernichten können, als sie zurückkehrten. Stattdessen sorgte er nach einem schwierigen Prozess des Prüfens und Sich-zu-erkennen-Gebens für die Familie.

„Das Gute, das später kommt, macht den Verkauf nicht zu einer guten Tat“, sagte Anna.

Ruth nickte. „Aber es bedeutet, dass der Verkauf nicht das letzte Wort hatte.“

Neben dem fünfzigsten Kapitel des ersten Buches Mose lag ein Zeitungsausschnitt in der Bibel. Er beschrieb den Sohn eines Predigers, der auf einem Bauernhof aufgewachsen war, einen kleinen Jungen von drei Jahren, dessen Vater Schweinezüchter und später Geistlicher und Maler war. Der Name war Nathan Tabor.

Die handschriftliche Notiz daneben lautete:

**Frage, was das Kind mitbekommen hat, bevor du entscheidest, was der erwachsene Mensch meint.**

June las das zweimal.

Sie hatten nach einem Gerät über dem Taufbecken gesucht. Jetzt betrachteten sie auch das Erbe: die Worte, die eine Familie wiederholt, die Rollen, die sie verteilt, und die Erwartungen, die ein Kind erlernt, bevor es weiß, dass es Erwartungen sind.

„Was hast du mitbekommen?“, fragte Anna Ruth.

Ruth berührte die Bibel ihrer Großmutter.

„Glauben. Einen Platz am Tisch. Und das Gefühl, dass ich beides verlieren könnte, wenn ich aufhörte zu arbeiten.“

Niemand beeilte sich zu antworten.

Lydia schob den Kuchenteller näher zu ihrer Mutter.

In der Knopfdose fand Beth unter einem doppelten Boden einen Messingschlüssel.

Auf seinem Etikett stand:

**DIE TÜR.**

### Am Tisch

Ruth begann eine Seite mit zwei Überschriften: **Was ich mitbekommen habe** und **Was ich weitertragen möchte**. Unter beide schrieb sie Gastfreundschaft. Unter die erste schrieb sie Erschöpfung. Unter der zweiten ließ sie eine Stelle frei, bis sie bereit war, sie auszufüllen.

**Lesepfad:** 1. Mose 1–50. Die Nacherzählung wählt wichtige Begebenheiten aus; zur vollständigen Lektüre gehören Stammbäume, Bündnisse, Reisen, Familienstreitigkeiten, Segnungen und Todesfälle.

---
