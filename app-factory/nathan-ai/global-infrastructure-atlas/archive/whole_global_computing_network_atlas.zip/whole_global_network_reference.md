# Whole Global Computing Network Atlas

**Snapshot:** 2026-11-18  
**Scope:** public-source technology reference and illustrative topology, **not** a census of all active endpoints or a deployment report.  
**Preserved:** 205 previously indexed GitHub projects and 36 previous directory entries.

## Inventory summary

| Indexed object | Count |
|---|---:|
| Taxonomy layers | 18 |
| Unique reference components | 871 |
| Typed component relationships | 83 |
| Architectural layer relationships | 23 |
| Reference sources | 24 |
| Illustrative geographic hubs | 14 |
| Coverage topics | 18 |

## Reading the network

The map has three distinct meanings: **geography** (public city-level hub examples), **architecture** (dependencies and service roles), and **software inventory** (candidate repositories and named products). Do not merge them into purported real-world connections without evidence.

## Full infrastructure taxonomy (every layer)


### L00 — Physical planet & facilities
Cables, terrestrial fiber, satellites, IXPs, colocation, power and buildings.

**Boundary:** Physical presence, not a software-deployment assertion.

**Indexed entries (30):**

- [AMS-IX](https://www.peeringdb.com/) — public_iexchange
- [CDN PoPs](https://www.submarinecablemap.com/) — physical_infrastructure
- [Colocation facilities](https://www.submarinecablemap.com/) — physical_infrastructure
- [Cooling infrastructure](https://www.submarinecablemap.com/) — physical_infrastructure
- [Cross-connects](https://www.submarinecablemap.com/) — physical_infrastructure
- [Data centers](https://www.submarinecablemap.com/) — physical_infrastructure
- [DE-CIX Frankfurt](https://www.peeringdb.com/) — public_iexchange
- [Electrical grid interconnection](https://www.submarinecablemap.com/) — physical_infrastructure
- [Enterprise campus networks](https://www.submarinecablemap.com/) — physical_infrastructure
- [Hyperscale campuses](https://www.submarinecablemap.com/) — physical_infrastructure
- [Internet access networks](https://www.submarinecablemap.com/) — physical_infrastructure
- [Internet exchange points](https://www.submarinecablemap.com/) — physical_infrastructure
- [IX.br](https://www.peeringdb.com/) — public_iexchange
- [JPNAP](https://www.peeringdb.com/) — public_iexchange
- [LEO satellite networks](https://www.submarinecablemap.com/) — physical_infrastructure
- [LINX](https://www.peeringdb.com/) — public_iexchange
- [Metro network aggregation](https://www.submarinecablemap.com/) — physical_infrastructure
- [Metropolitan fiber](https://www.submarinecablemap.com/) — physical_infrastructure
- [Mobile RAN infrastructure](https://www.submarinecablemap.com/) — physical_infrastructure
- [NAPAfrica](https://www.peeringdb.com/) — public_iexchange
- [Optical DWDM line systems](https://www.submarinecablemap.com/) — physical_infrastructure
- [Optical landing stations](https://www.submarinecablemap.com/) — physical_infrastructure
- [Physical cross-border landing rights](https://www.submarinecablemap.com/) — physical_infrastructure
- [Regional PoPs](https://www.submarinecablemap.com/) — physical_infrastructure
- [Residential broadband networks](https://www.submarinecablemap.com/) — physical_infrastructure
- [Satellite ground stations](https://www.submarinecablemap.com/) — physical_infrastructure
- [SGIX](https://www.peeringdb.com/) — public_iexchange
- [Submarine optical cable systems](https://www.submarinecablemap.com/) — physical_infrastructure
- [Terrestrial long-haul fiber](https://www.submarinecablemap.com/) — physical_infrastructure
- [UPS and backup generators](https://www.submarinecablemap.com/) — physical_infrastructure

### L01 — Silicon & firmware: rings −3 to −1
CPU/SoC, secure processors, boot firmware, BMCs, SmartNICs and DPUs.

**Boundary:** Pre-OS subsystems do not form one interchangeable class of kernel.

**Indexed entries (35):**

- [AMD Platform Security Processor (PSP)](https://openbmc.org/) — firmware
- [Arm CPUs](https://uefi.org/specifications) — hardware_component
- [ASIC switch fabric](https://uefi.org/specifications) — hardware_component
- [Baseboard Management Controller (BMC)](https://openbmc.org/) — firmware
- [Boot ROM](https://openbmc.org/) — firmware
- [coreboot](https://www.coreboot.org/) — firmware
- [DMTF Redfish](https://openbmc.org/) — firmware
- [FPGAs](https://uefi.org/specifications) — hardware_component
- [GPU compute silicon](https://uefi.org/specifications) — hardware_component
- [Hardware security modules](https://uefi.org/specifications) — hardware_component
- [Intel Management Engine (ME)](https://openbmc.org/) — firmware
- [IPMI](https://openbmc.org/) — firmware
- [LinuxBoot](https://openbmc.org/) — firmware
- [Measured boot](https://openbmc.org/) — firmware
- [Network interface firmware](https://openbmc.org/) — firmware
- [Network processors](https://uefi.org/specifications) — hardware_component
- [NVIDIA BlueField DPU](https://docs.nvidia.com/networking/) — firmware
- [OpenBMC](https://openbmc.org/) — firmware
- [PCIe device firmware](https://openbmc.org/) — firmware
- [PCIe root complex](https://uefi.org/specifications) — hardware_component
- [Platform Controller Hub](https://uefi.org/specifications) — hardware_component
- [RAM memory controllers](https://uefi.org/specifications) — hardware_component
- [RISC-V CPUs](https://uefi.org/specifications) — hardware_component
- [Secure boot chain](https://openbmc.org/) — firmware
- [Secure Enclave-class processor](https://uefi.org/specifications) — hardware_component
- [SmartNIC](https://openbmc.org/) — firmware
- [SPI flash](https://uefi.org/specifications) — hardware_component
- [TianoCore EDK II](https://openbmc.org/) — firmware
- [TPM 2.0](https://uefi.org/specifications) — hardware_component
- [Trusted execution environments](https://uefi.org/specifications) — hardware_component
- [Trusted Firmware-A](https://openbmc.org/) — firmware
- [U-Boot](https://openbmc.org/) — firmware
- [UEFI](https://uefi.org/specifications) — firmware
- [UEFI Secure Boot](https://openbmc.org/) — firmware
- [x86-64 CPUs](https://uefi.org/specifications) — hardware_component

### L02 — Links, transport & routing
L2/L3 underlay, ASNs, BGP, Anycast, transport, overlay, route authorization.

**Boundary:** Internet-wide observed adjacency is incomplete.

**Indexed entries (40):**

- [802.11 Wi-Fi](https://www.iana.org/protocols) — network_standard
- [ARP](https://www.iana.org/protocols) — network_standard
- [Autonomous System Number (ASN)](https://www.iana.org/protocols) — network_standard
- [BGP](https://datatracker.ietf.org/doc/html/rfc4271) — network_standard
- [BGP Anycast](https://www.iana.org/protocols) — network_standard
- [CAIDA AS relationships](https://www.ripe.net/analyse/internet-measurements/routing-information-service-ris/) — public_measurement
- [DWDM](https://www.iana.org/protocols) — network_standard
- [ECMP](https://www.iana.org/protocols) — network_standard
- [Ethernet](https://www.iana.org/protocols) — network_standard
- [EVPN](https://www.iana.org/protocols) — network_standard
- [GRE](https://www.iana.org/protocols) — network_standard
- [HTTP/3](https://www.iana.org/protocols) — network_standard
- [ICMP](https://www.iana.org/protocols) — network_standard
- [IPsec](https://www.iana.org/protocols) — network_standard
- [IPv4](https://www.iana.org/protocols) — network_standard
- [IPv6](https://www.iana.org/protocols) — network_standard
- [IPv6 SLAAC](https://www.iana.org/protocols) — network_standard
- [IRR](https://www.iana.org/protocols) — network_standard
- [IS-IS](https://www.iana.org/protocols) — network_standard
- [MPLS](https://www.iana.org/protocols) — network_standard
- [NAT64](https://www.iana.org/protocols) — network_standard
- [NDP](https://www.iana.org/protocols) — network_standard
- [Optical fiber](https://www.iana.org/protocols) — network_standard
- [OSPF](https://www.iana.org/protocols) — network_standard
- [PeeringDB network interconnection records](https://www.ripe.net/analyse/internet-measurements/routing-information-service-ris/) — public_measurement
- [QUIC](https://www.iana.org/protocols) — network_standard
- [RIPE RIS Route Collectors](https://www.ripe.net/analyse/internet-measurements/routing-information-service-ris/) — public_measurement
- [RIR allocations](https://www.iana.org/protocols) — network_standard
- [ROA](https://www.iana.org/protocols) — network_standard
- [Route Views BGP collectors](https://www.ripe.net/analyse/internet-measurements/routing-information-service-ris/) — public_measurement
- [RPKI](https://rpki.readthedocs.io/) — network_standard
- [RPKI Route Origin Validation](https://www.iana.org/protocols) — network_standard
- [Segment Routing](https://www.iana.org/protocols) — network_standard
- [SRv6](https://www.iana.org/protocols) — network_standard
- [TCP](https://www.iana.org/protocols) — network_standard
- [TLS 1.3](https://www.iana.org/protocols) — network_standard
- [UDP](https://www.iana.org/protocols) — network_standard
- [VLAN](https://www.iana.org/protocols) — network_standard
- [VXLAN](https://www.iana.org/protocols) — network_standard
- [WireGuard](https://www.iana.org/protocols) — network_standard

### L03 — Resolution, naming, identity & trust
DNS root/TLD/recursive/authoritative, RIRs, CA/ACME, CT and identity protocols.

**Boundary:** DNS names, certificates and ASNs are different identities.

**Indexed entries (49):**

- [12 root server operators](https://www.iana.org/dnssec/procedures/ksk-operator/ksk-dps-20240315.html) — dns_or_registry
- [13 logical DNS root-server identities](https://www.iana.org/domains/root/servers) — dns_or_registry
- [ACME](https://letsencrypt.org/how-it-works/) — identity_standard
- [Authoritative DNS servers](https://www.iana.org/domains/root/servers) — dns_or_registry
- [BIND 9](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Certificate Authorities](https://letsencrypt.org/how-it-works/) — identity_standard
- [Certificate Transparency](https://certificate.transparency.dev/) — identity_standard
- [Cloudflare DNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [CoreDNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [CRL](https://letsencrypt.org/how-it-works/) — identity_standard
- [CT log monitors](https://letsencrypt.org/how-it-works/) — identity_standard
- [DNS caches](https://www.iana.org/domains/root/servers) — dns_or_registry
- [DNS delegation](https://www.iana.org/domains/root/servers) — dns_or_registry
- [DNS forwarders](https://www.iana.org/domains/root/servers) — dns_or_registry
- [DNS over HTTPS (DoH)](https://www.iana.org/domains/root/servers) — dns_or_registry
- [DNS over QUIC (DoQ)](https://www.iana.org/domains/root/servers) — dns_or_registry
- [DNS over TLS (DoT)](https://www.iana.org/domains/root/servers) — dns_or_registry
- [DNS-based domain validation](https://letsencrypt.org/how-it-works/) — identity_standard
- [DNSSEC](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Domain registrars](https://www.iana.org/domains/root/servers) — dns_or_registry
- [FIDO2](https://letsencrypt.org/how-it-works/) — identity_standard
- [Google Public DNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [HSM key management](https://letsencrypt.org/how-it-works/) — identity_standard
- [IANA Number Resources](https://www.iana.org/domains/root/servers) — dns_or_registry
- [IANA root zone](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Knot DNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Let’s Encrypt](https://letsencrypt.org/how-it-works/) — identity_standard
- [NSD DNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [OAuth 2.0](https://letsencrypt.org/how-it-works/) — identity_standard
- [OCSP](https://letsencrypt.org/how-it-works/) — identity_standard
- [OIDC workload identity](https://letsencrypt.org/how-it-works/) — identity_standard
- [OpenID Connect](https://letsencrypt.org/how-it-works/) — identity_standard
- [PowerDNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Public Key Infrastructure (PKI)](https://letsencrypt.org/how-it-works/) — identity_standard
- [Quad9](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Recursive DNS resolvers](https://www.iana.org/domains/root/servers) — dns_or_registry
- [RIR registries](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Root anycast instances](https://www.iana.org/domains/root/servers) — dns_or_registry
- [Route 53 DNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [RPKI trust anchors](https://letsencrypt.org/how-it-works/) — identity_standard
- [SAML](https://letsencrypt.org/how-it-works/) — identity_standard
- [SPIFFE](https://letsencrypt.org/how-it-works/) — identity_standard
- [SPIRE](https://letsencrypt.org/how-it-works/) — identity_standard
- [SPKI](https://letsencrypt.org/how-it-works/) — identity_standard
- [TLD registry servers](https://www.iana.org/domains/root/servers) — dns_or_registry
- [TLS/mTLS](https://letsencrypt.org/how-it-works/) — identity_standard
- [Unbound DNS](https://www.iana.org/domains/root/servers) — dns_or_registry
- [WebAuthn](https://letsencrypt.org/how-it-works/) — identity_standard
- [X.509](https://letsencrypt.org/how-it-works/) — identity_standard

### L04 — Host operating systems & kernels
Linux/BSD/Windows/RT kernels, syscall isolation, modules and kernel interfaces.

**Boundary:** OS kernels differ from notebook and GPU compute kernels.

**Indexed entries (38):**

- [Android kernel](https://kernel.org/) — operating_system_or_kernel
- [Apple XNU](https://kernel.org/) — operating_system_or_kernel
- [bazzite](https://github.com/ublue-os/bazzite) — github_repository_seed
- [blog_os](https://github.com/phil-opp/blog_os) — github_repository_seed
- [bottlerocket](https://github.com/bottlerocket-os/bottlerocket) — github_repository_seed
- [cilium](https://cilium.io/) — github_repository_seed
- [Cilium eBPF datapath](https://kernel.org/) — operating_system_or_kernel
- [FreeBSD kernel](https://kernel.org/) — operating_system_or_kernel
- [freebsd-src](https://github.com/freebsd/freebsd-src) — github_repository_seed
- [gvisor](https://github.com/gvisor/gvisor) — github_repository_seed
- [L4 microkernel family](https://kernel.org/) — operating_system_or_kernel
- [Linux cgroups](https://kernel.org/) — operating_system_or_kernel
- [Linux eBPF virtual machine](https://kernel.org/) — operating_system_or_kernel
- [Linux kernel](https://www.kernel.org/) — operating_system_or_kernel
- [Linux kernel modules](https://kernel.org/) — operating_system_or_kernel
- [Linux LSM](https://kernel.org/) — operating_system_or_kernel
- [Linux namespaces](https://kernel.org/) — operating_system_or_kernel
- [Linux seccomp](https://kernel.org/) — operating_system_or_kernel
- [Linux XDP](https://kernel.org/) — operating_system_or_kernel
- [lkmpg](https://github.com/sysprog21/lkmpg) — github_repository_seed
- [MINIX 3](https://kernel.org/) — operating_system_or_kernel
- [NetBSD kernel](https://kernel.org/) — operating_system_or_kernel
- [OpenBSD kernel](https://kernel.org/) — operating_system_or_kernel
- [puter](https://github.com/HeyPuter/puter) — github_repository_seed
- [QNX Neutrino](https://kernel.org/) — operating_system_or_kernel
- [reactos](https://github.com/reactos/reactos) — github_repository_seed
- [redox](https://github.com/redox-os/redox) — github_repository_seed
- [Redox OS](https://kernel.org/) — operating_system_or_kernel
- [rt-thread](https://github.com/RT-Thread/rt-thread) — github_repository_seed
- [rust-raspberrypi-OS-tutorials](https://github.com/rust-embedded/rust-raspberrypi-OS-tutorials) — github_repository_seed
- [seL4](https://github.com/seL4/seL4) — github_repository_seed
- [seL4 microkernel](https://kernel.org/) — operating_system_or_kernel
- [serenity](https://github.com/SerenityOS/serenity) — github_repository_seed
- [SerenityOS](https://kernel.org/) — operating_system_or_kernel
- [Systemd](https://kernel.org/) — operating_system_or_kernel
- [Windows NT kernel](https://kernel.org/) — operating_system_or_kernel
- [zephyr](https://github.com/zephyrproject-rtos/zephyr) — github_repository_seed
- [Zircon kernel](https://kernel.org/) — operating_system_or_kernel

### L05 — Hypervisors, containers & isolated runtimes
VM, microVM, OCI, V8 isolates, Node.js, Deno, Wasm/WASI, Jupyter.

**Boundary:** Many runtimes require hosts, not standalone Workers.

**Indexed entries (46):**

- [assemblyscript](https://github.com/AssemblyScript/assemblyscript) — github_repository_seed
- [Bun runtime](https://www.cncf.io/projects/) — execution_runtime
- [Cloud Hypervisor](https://www.cncf.io/projects/) — execution_runtime
- [CLR/.NET runtime](https://www.cncf.io/projects/) — execution_runtime
- [containerd](https://www.cncf.io/projects/) — execution_runtime
- [CRI-O](https://www.cncf.io/projects/) — execution_runtime
- [crun](https://www.cncf.io/projects/) — execution_runtime
- [Deno runtime](https://www.cncf.io/projects/) — execution_runtime
- [Docker Engine](https://www.cncf.io/projects/) — execution_runtime
- [emscripten](https://github.com/emscripten-core/emscripten) — github_repository_seed
- [Erlang BEAM](https://www.cncf.io/projects/) — execution_runtime
- [Firecracker MicroVM](https://firecracker-microvm.github.io/) — execution_runtime
- [Hyper-V](https://www.cncf.io/projects/) — execution_runtime
- [IJulia](https://www.cncf.io/projects/) — execution_runtime
- [IPython kernel](https://www.cncf.io/projects/) — execution_runtime
- [IRkernel](https://www.cncf.io/projects/) — execution_runtime
- [Jupyter kernel protocol](https://www.cncf.io/projects/) — execution_runtime
- [JVM](https://www.cncf.io/projects/) — execution_runtime
- [Kata Containers](https://www.cncf.io/projects/) — execution_runtime
- [KVM](https://www.cncf.io/projects/) — execution_runtime
- [Node.js](https://www.cncf.io/projects/) — execution_runtime
- [OCI Runtime Spec](https://www.cncf.io/projects/) — execution_runtime
- [partykit](https://github.com/partykit/partykit) — github_repository_seed
- [Podman](https://www.cncf.io/projects/) — execution_runtime
- [pyodide](https://github.com/pyodide/pyodide) — github_repository_seed
- [Python CPython](https://www.cncf.io/projects/) — execution_runtime
- [QEMU](https://www.cncf.io/projects/) — execution_runtime
- [runc](https://www.cncf.io/projects/) — execution_runtime
- [spin](https://github.com/fermyon/spin) — github_repository_seed
- [Spin (Fermyon)](https://www.cncf.io/projects/) — execution_runtime
- [tinygo](https://github.com/tinygo-org/tinygo) — github_repository_seed
- [V8 JavaScript isolates](https://www.cncf.io/projects/) — execution_runtime
- [VMware ESXi](https://www.cncf.io/projects/) — execution_runtime
- [WASI](https://www.cncf.io/projects/) — execution_runtime
- [Wasm sandboxing](https://www.cncf.io/projects/) — execution_runtime
- [wasm3](https://github.com/wasm3/wasm3) — github_repository_seed
- [wasmCloud](https://github.com/wasmCloud/wasmCloud) — github_repository_seed
- [WasmEdge](https://github.com/WasmEdge/WasmEdge) — github_repository_seed
- [wasmer](https://github.com/wasmerio/wasmer) — github_repository_seed
- [wasmi](https://github.com/wasmi-labs/wasmi) — github_repository_seed
- [wasmtime](https://github.com/bytecodealliance/wasmtime) — github_repository_seed
- [WebAssembly component model](https://www.cncf.io/projects/) — execution_runtime
- [Xen](https://www.cncf.io/projects/) — execution_runtime
- [xeus-cling](https://www.cncf.io/projects/) — execution_runtime
- [zenoh](https://github.com/eclipse-zenoh/zenoh) — github_repository_seed
- [ZeroMQ](https://www.cncf.io/projects/) — execution_runtime

### L06 — Cloud edge & serverless execution
Workers, edge functions, durable actor/stateful execution, cloud function services.

**Boundary:** Provider deployment footprints are private and variable.

**Indexed entries (55):**

- [60s](https://github.com/vikiboss/60s) — github_repository_seed
- [agents](https://github.com/cloudflare/agents) — github_repository_seed
- [Akamai EdgeWorkers](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Apache OpenWhisk](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [awesome-agents](https://github.com/cloudflare/awesome-agents) — github_repository_seed
- [AWS CloudFront Functions](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [AWS Lambda](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [AWS Lambda@Edge](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Azure Functions](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [chalice](https://github.com/aws/chalice) — github_repository_seed
- [cloud-mail](https://github.com/maillab/cloud-mail) — github_repository_seed
- [Cloudflare Containers](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Cloudflare Cron Triggers](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Cloudflare Durable Objects](https://developers.cloudflare.com/durable-objects/) — serverless_runtime_or_service
- [Cloudflare Pages](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Cloudflare Queues](https://developers.cloudflare.com/queues/) — serverless_runtime_or_service
- [Cloudflare service bindings](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Cloudflare Workers](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Cloudflare Workers AI](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Cloudflare Workers for Platforms](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Cloudflare Workflows](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [cloudflare_temp_email](https://github.com/dreamhunter2333/cloudflare_temp_email) — github_repository_seed
- [Deno Deploy](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [examples](https://github.com/serverless/examples) — github_repository_seed
- [Fastly Compute](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Fission](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Fly.io Machines](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Google Cloud Functions](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Google Cloud Run](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [hono](https://github.com/honojs/hono) — github_repository_seed
- [jose](https://github.com/panva/jose) — github_repository_seed
- [Knative Serving](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [microfeed](https://github.com/microfeed/microfeed) — github_repository_seed
- [middy](https://github.com/middyjs/middy) — github_repository_seed
- [midway](https://github.com/midwayjs/midway) — github_repository_seed
- [moltworker](https://github.com/cloudflare/moltworker) — github_repository_seed
- [Netlify Edge Functions](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [nodewarden](https://github.com/shuaiplus/nodewarden) — github_repository_seed
- [open-connector](https://github.com/oomol-lab/open-connector) — github_repository_seed
- [OpenFaaS](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [serverless](https://github.com/serverless/serverless) — github_repository_seed
- [Serverless Framework](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Serverless-Devs](https://github.com/Serverless-Devs/Serverless-Devs) — github_repository_seed
- [serverless-express](https://github.com/CodeGenieApp/serverless-express) — github_repository_seed
- [serverless-step-functions](https://github.com/serverless-operations/serverless-step-functions) — github_repository_seed
- [Supabase Edge Functions](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [supermemory](https://github.com/supermemoryai/supermemory) — github_repository_seed
- [templates](https://github.com/cloudflare/templates) — github_repository_seed
- [Vercel Edge Runtime](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [Vercel Functions](https://developers.cloudflare.com/workers/) — serverless_runtime_or_service
- [vibesdk](https://github.com/cloudflare/vibesdk) — github_repository_seed
- [webstudio](https://github.com/webstudio-is/webstudio) — github_repository_seed
- [workerd](https://github.com/cloudflare/workerd) — github_repository_seed
- [workers-sdk](https://github.com/cloudflare/workers-sdk) — github_repository_seed
- [Zappa](https://github.com/zappa/Zappa) — github_repository_seed

### L07 — Cluster scheduling & orchestration
Kubernetes, batch schedulers, pipelines and workflow orchestration.

**Boundary:** Control-plane and worker-node semantics differ by system.

**Indexed entries (88):**

- [agenda](https://github.com/agenda/agenda) — github_repository_seed
- [airflow](https://github.com/apache/airflow) — github_repository_seed
- [Apache Airflow](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Apache Beam](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Apache DolphinScheduler](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Apache Flink](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Apache Spark](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Argo CD](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [argo-workflows](https://github.com/argoproj/argo-workflows) — github_repository_seed
- [astron-agent](https://github.com/iflytek/astron-agent) — github_repository_seed
- [AWS ECS](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [AWS EKS](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [awx-operator](https://github.com/ansible/awx-operator) — github_repository_seed
- [Azure AKS](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [bee-queue](https://github.com/bee-queue/bee-queue) — github_repository_seed
- [boinc](https://github.com/BOINC/boinc) — github_repository_seed
- [budibase](https://github.com/Budibase/budibase) — github_repository_seed
- [BullMQ](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [capsule](https://github.com/projectcapsule/capsule) — github_repository_seed
- [Celery](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [chronos](https://github.com/mesos/chronos) — github_repository_seed
- [clickhouse-operator](https://github.com/Altinity/clickhouse-operator) — github_repository_seed
- [ColossalAI](https://github.com/hpcaitech/ColossalAI) — github_repository_seed
- [conductor](https://github.com/conductor-oss/conductor) — github_repository_seed
- [Conductor OSS](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [cyclops](https://github.com/cyclops-ui/cyclops) — github_repository_seed
- [Daft](https://github.com/Eventual-Inc/Daft) — github_repository_seed
- [Dagster](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [dagu](https://github.com/dagucloud/dagu) — github_repository_seed
- [dapr](https://github.com/dapr/dapr) — github_repository_seed
- [Dask](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [dolphinscheduler](https://github.com/apache/dolphinscheduler) — github_repository_seed
- [ergo](https://github.com/ergo-services/ergo) — github_repository_seed
- [flowable-engine](https://github.com/flowable/flowable-engine) — github_repository_seed
- [Flux CD](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [gleam](https://github.com/chrislusf/gleam) — github_repository_seed
- [Go cron schedulers](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [go-quartz](https://github.com/reugn/go-quartz) — github_repository_seed
- [Google Borg (proprietary)](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Google GKE](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [grafana-operator](https://github.com/grafana/grafana-operator) — github_repository_seed
- [Hadoop YARN](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [HashiCorp Nomad](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [hatchet](https://github.com/hatchet-dev/hatchet) — github_repository_seed
- [hazelcast](https://github.com/hazelcast/hazelcast) — github_repository_seed
- [Helm](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [inngest](https://github.com/inngest/inngest) — github_repository_seed
- [KEDA](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [kopf](https://github.com/nolar/kopf) — github_repository_seed
- [KubeEdge](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [kuberay](https://github.com/kuberay-project/kuberay) — github_repository_seed
- [Kubernetes](https://kubernetes.io/) — scheduler_or_orchestrator
- [Kubernetes API Server](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Kubernetes controller manager](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Kubernetes CRDs](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Kubernetes kubelet](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Kubernetes Operator SDK](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [Kubernetes scheduler](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [livebook](https://github.com/livebook-dev/livebook) — github_repository_seed
- [meshery](https://github.com/meshery/meshery) — github_repository_seed
- [Microsoft Apollo scheduler (proprietary)](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [n8n](https://github.com/n8n-io/n8n) — github_repository_seed
- [nats-server](https://github.com/nats-io/nats-server) — github_repository_seed
- [nocobase](https://github.com/nocobase/nocobase) — github_repository_seed
- [Nomad](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [opentelemetry-operator](https://github.com/open-telemetry/opentelemetry-operator) — github_repository_seed
- [OpenYurt](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [operator-lifecycle-manager](https://github.com/operator-framework/operator-lifecycle-manager) — github_repository_seed
- [postgres-operator](https://github.com/CrunchyData/postgres-operator) — github_repository_seed
- [PowerJob](https://github.com/PowerJob/PowerJob) — github_repository_seed
- [prefect](https://github.com/PrefectHQ/prefect) — github_repository_seed
- [protoactor-go](https://github.com/asynkron/protoactor-go) — github_repository_seed
- [quartznet](https://github.com/quartznet/quartznet) — github_repository_seed
- [ray](https://docs.ray.io/) — github_repository_seed
- [resque](https://github.com/resque/resque) — github_repository_seed
- [restate](https://github.com/restatedev/restate) — github_repository_seed
- [sail](https://github.com/lakehq/sail) — github_repository_seed
- [shell-operator](https://github.com/flant/shell-operator) — github_repository_seed
- [Sidekiq](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [skypilot](https://github.com/skypilot-org/skypilot) — github_repository_seed
- [SLURM](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [spark-operator](https://github.com/kubeflow/spark-operator) — github_repository_seed
- [stackgres](https://github.com/ongres/stackgres) — github_repository_seed
- [strimzi-kafka-operator](https://github.com/strimzi/strimzi-kafka-operator) — github_repository_seed
- [Tekton](https://landscape.cncf.io/) — scheduler_or_orchestrator
- [temporal](https://github.com/temporalio/temporal) — github_repository_seed
- [windmill](https://github.com/windmill-labs/windmill) — github_repository_seed
- [workflow-core](https://github.com/danielgerlag/workflow-core) — github_repository_seed

### L08 — Persistence, databases, consensus & memory
Raft/Zab coordination, SQL/NoSQL, KV, object stores, vector and graph databases.

**Boundary:** Consistency and geographic replication models are product-specific.

**Indexed entries (49):**

- [Apache Cassandra](https://etcd.io/) — database_storage_or_consensus
- [Apache ZooKeeper](https://zookeeper.apache.org/) — database_storage_or_consensus
- [ArangoDB](https://etcd.io/) — database_storage_or_consensus
- [AWS S3](https://etcd.io/) — database_storage_or_consensus
- [Azure Blob Storage](https://etcd.io/) — database_storage_or_consensus
- [Backblaze B2](https://etcd.io/) — database_storage_or_consensus
- [Ceph](https://etcd.io/) — database_storage_or_consensus
- [Change data capture (CDC)](https://etcd.io/) — database_storage_or_consensus
- [Chroma](https://etcd.io/) — database_storage_or_consensus
- [Cloudflare D1](https://developers.cloudflare.com/d1/) — database_storage_or_consensus
- [Cloudflare Durable Objects SQLite](https://etcd.io/) — database_storage_or_consensus
- [Cloudflare KV](https://developers.cloudflare.com/kv/) — database_storage_or_consensus
- [Cloudflare R2](https://developers.cloudflare.com/r2/) — database_storage_or_consensus
- [CockroachDB](https://www.cockroachlabs.com/) — database_storage_or_consensus
- [Consul](https://developer.hashicorp.com/consul) — database_storage_or_consensus
- [DragonflyDB](https://etcd.io/) — database_storage_or_consensus
- [Elasticsearch](https://etcd.io/) — database_storage_or_consensus
- [etcd](https://etcd.io/) — database_storage_or_consensus
- [FoundationDB](https://www.foundationdb.org/) — database_storage_or_consensus
- [Google Cloud Storage](https://etcd.io/) — database_storage_or_consensus
- [IPFS content address store](https://etcd.io/) — database_storage_or_consensus
- [LevelDB](https://etcd.io/) — database_storage_or_consensus
- [LMDB](https://etcd.io/) — database_storage_or_consensus
- [MariaDB](https://etcd.io/) — database_storage_or_consensus
- [Milvus](https://milvus.io/) — database_storage_or_consensus
- [MinIO](https://etcd.io/) — database_storage_or_consensus
- [MongoDB](https://etcd.io/) — database_storage_or_consensus
- [Multi-Paxos](https://etcd.io/) — database_storage_or_consensus
- [Multi-region replication](https://etcd.io/) — database_storage_or_consensus
- [MySQL](https://etcd.io/) — database_storage_or_consensus
- [Neo4j](https://neo4j.com/) — database_storage_or_consensus
- [Object versioning](https://etcd.io/) — database_storage_or_consensus
- [OpenSearch](https://etcd.io/) — database_storage_or_consensus
- [Paxos family](https://etcd.io/) — database_storage_or_consensus
- [pgvector](https://etcd.io/) — database_storage_or_consensus
- [Pinecone](https://etcd.io/) — database_storage_or_consensus
- [PostgreSQL](https://etcd.io/) — database_storage_or_consensus
- [Qdrant](https://qdrant.tech/) — database_storage_or_consensus
- [Raft consensus](https://etcd.io/) — database_storage_or_consensus
- [Redis](https://etcd.io/) — database_storage_or_consensus
- [Redis Streams](https://etcd.io/) — database_storage_or_consensus
- [RocksDB](https://etcd.io/) — database_storage_or_consensus
- [ScyllaDB](https://etcd.io/) — database_storage_or_consensus
- [Snapshot backup](https://etcd.io/) — database_storage_or_consensus
- [SQLite](https://etcd.io/) — database_storage_or_consensus
- [TiKV](https://tikv.org/) — database_storage_or_consensus
- [Valkey](https://etcd.io/) — database_storage_or_consensus
- [Weaviate](https://weaviate.io/) — database_storage_or_consensus
- [ZooKeeper Atomic Broadcast (Zab)](https://cwiki.apache.org/confluence/spaces/ZOOKEEPER/pages/24189846/Zab1.0) — database_storage_or_consensus

### L09 — Messages, queues, streams & service buses
Event logs, brokers, durable queues, streaming and service messaging.

**Boundary:** At-most-once and at-least-once delivery differ.

**Indexed entries (34):**

- [AMQP 0-9-1](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [AMQP 1.0](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Apache Flume](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Apache Kafka](https://kafka.apache.org/) — messaging_or_protocol
- [Apache NiFi](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Apache Pulsar](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Apache RocketMQ](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [AWS SNS](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [AWS SQS](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Azure Event Hubs](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Azure Service Bus](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Cloudflare Pub/Sub](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Dead-letter queue](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Debezium](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Durable workflow queue](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [EMQX](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Google Pub/Sub](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [gRPC streams](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Idempotency keys](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Kafka Wire Protocol](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Mosquitto](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [MQTT](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [NATS](https://nats.io/) — messaging_or_protocol
- [NATS JetStream](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [NATS protocol](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [OpenTelemetry Collector pipelines](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Outbox pattern](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [RabbitMQ](https://www.rabbitmq.com/) — messaging_or_protocol
- [Redpanda](https://www.redpanda.com/) — messaging_or_protocol
- [Server-Sent Events](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [STOMP](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [Vector pipelines](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [WebSockets](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol
- [ZeroMQ messaging](https://docs.nats.io/concepts/jetstream) — messaging_or_protocol

### L10 — AI models, inference, acceleration & compute kernels
GPU engines, distributed ML, model serving, vector retrieval.

**Boundary:** GPU kernels are computation functions, not operating-system kernels.

**Indexed entries (53):**

- [AMD ROCm](https://pytorch.org/) — ai_compute_or_serving
- [audio-separation-nodes-comfyui](https://github.com/christian-byrne/audio-separation-nodes-comfyui) — github_repository_seed
- [Batched model inference](https://pytorch.org/) — ai_compute_or_serving
- [BentoML](https://github.com/bentoml/BentoML) — github_repository_seed
- [ComfyUI](https://pytorch.org/) — ai_compute_or_serving
- [ComfyUI custom nodes](https://pytorch.org/) — ai_compute_or_serving
- [ComfyUI-Copilot](https://github.com/ATH-MaaS/ComfyUI-Copilot) — github_repository_seed
- [ComfyUI-DyPE](https://github.com/wildminder/ComfyUI-DyPE) — github_repository_seed
- [ComfyUI-IDM-VTON](https://github.com/TemryL/ComfyUI-IDM-VTON) — github_repository_seed
- [comfyui-inpaint-nodes](https://github.com/Acly/comfyui-inpaint-nodes) — github_repository_seed
- [ComfyUI-RMBG](https://github.com/1038lab/ComfyUI-RMBG) — github_repository_seed
- [ComfyUI-SeedVR2_VideoUpscaler](https://github.com/numz/ComfyUI-SeedVR2_VideoUpscaler) — github_repository_seed
- [ComfyUI-VibeVoice](https://github.com/wildminder/ComfyUI-VibeVoice) — github_repository_seed
- [CPU vector kernels](https://pytorch.org/) — ai_compute_or_serving
- [DeepSpeed](https://pytorch.org/) — ai_compute_or_serving
- [dynamo](https://github.com/ai-dynamo/dynamo) — github_repository_seed
- [Embedding model services](https://pytorch.org/) — ai_compute_or_serving
- [FSDP](https://pytorch.org/) — ai_compute_or_serving
- [gpt4all](https://github.com/nomic-ai/gpt4all) — github_repository_seed
- [GPU tensor kernels](https://pytorch.org/) — ai_compute_or_serving
- [Horovod](https://pytorch.org/) — ai_compute_or_serving
- [Hugging Face Hub](https://pytorch.org/) — ai_compute_or_serving
- [Hugging Face Spaces](https://pytorch.org/) — ai_compute_or_serving
- [Hugging Face TGI](https://pytorch.org/) — ai_compute_or_serving
- [JAX](https://pytorch.org/) — ai_compute_or_serving
- [Knowledge graph retrieval](https://pytorch.org/) — ai_compute_or_serving
- [KServe](https://pytorch.org/) — ai_compute_or_serving
- [Kubeflow](https://pytorch.org/) — ai_compute_or_serving
- [litgpt](https://github.com/Lightning-AI/litgpt) — github_repository_seed
- [llama.cpp](https://pytorch.org/) — ai_compute_or_serving
- [lmdeploy](https://github.com/InternLM/lmdeploy) — github_repository_seed
- [MLflow](https://pytorch.org/) — ai_compute_or_serving
- [NCCL](https://pytorch.org/) — ai_compute_or_serving
- [NVIDIA CUDA](https://pytorch.org/) — ai_compute_or_serving
- [NVIDIA Triton Inference Server](https://pytorch.org/) — ai_compute_or_serving
- [Ollama](https://pytorch.org/) — ai_compute_or_serving
- [ONNX Runtime](https://pytorch.org/) — ai_compute_or_serving
- [OpenAI Triton language](https://pytorch.org/) — ai_compute_or_serving
- [OpenLLM](https://github.com/bentoml/OpenLLM) — github_repository_seed
- [openvino](https://github.com/openvinotoolkit/openvino) — github_repository_seed
- [PowerInfer](https://github.com/Tiiny-AI/PowerInfer) — github_repository_seed
- [PyTorch](https://pytorch.org/) — ai_compute_or_serving
- [Ray Serve](https://pytorch.org/) — ai_compute_or_serving
- [RCCL](https://pytorch.org/) — ai_compute_or_serving
- [Retrieval-augmented generation (RAG)](https://pytorch.org/) — ai_compute_or_serving
- [SGLang](https://pytorch.org/) — ai_compute_or_serving
- [TensorFlow](https://pytorch.org/) — ai_compute_or_serving
- [TensorRT-LLM](https://pytorch.org/) — ai_compute_or_serving
- [TPU kernels](https://pytorch.org/) — ai_compute_or_serving
- [turso](https://github.com/tursodatabase/turso) — github_repository_seed
- [Vector similarity indexing](https://pytorch.org/) — ai_compute_or_serving
- [VibeVoice-ComfyUI](https://github.com/Enemyx-net/VibeVoice-ComfyUI) — github_repository_seed
- [vLLM](https://pytorch.org/) — ai_compute_or_serving

### L11 — Autonomous agents, MCP, APIs & tool protocols
Agent frameworks, tool servers, A2A orchestration and LLM APIs.

**Boundary:** A registry listing does not imply trusted execution or tool approval.

**Indexed entries (67):**

- [activepieces](https://github.com/activepieces/activepieces) — github_repository_seed
- [adk-docs](https://github.com/google/adk-docs) — github_repository_seed
- [adk-go](https://github.com/google/adk-go) — github_repository_seed
- [adk-java](https://github.com/google/adk-java) — github_repository_seed
- [adk-python](https://github.com/google/adk-python) — github_repository_seed
- [Agent task orchestrator](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [agent-framework](https://github.com/microsoft/agent-framework) — github_repository_seed
- [Agent2Agent (A2A) protocol](https://a2a-protocol.org/) — ai_agent_or_protocol
- [agentscope](https://github.com/agentscope-ai/agentscope) — github_repository_seed
- [agentscope-java](https://github.com/agentscope-ai/agentscope-java) — github_repository_seed
- [agno](https://github.com/agno-agi/agno) — github_repository_seed
- [autogen](https://github.com/microsoft/autogen) — github_repository_seed
- [chrome-devtools-mcp](https://github.com/ChromeDevTools/chrome-devtools-mcp) — github_repository_seed
- [Cloudflare Agents SDK](https://developers.cloudflare.com/agents/) — ai_agent_or_protocol
- [codebase-memory-mcp](https://github.com/DeusData/codebase-memory-mcp) — github_repository_seed
- [context-mode](https://github.com/mksglu/context-mode) — github_repository_seed
- [context7](https://github.com/upstash/context7) — github_repository_seed
- [CopilotKit](https://github.com/CopilotKit/CopilotKit) — github_repository_seed
- [crewAI](https://github.com/crewAIInc/crewAI) — github_repository_seed
- [deer-flow](https://github.com/bytedance/deer-flow) — github_repository_seed
- [ElizaOS](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [gemini-cli](https://github.com/google-gemini/gemini-cli) — github_repository_seed
- [github-mcp-server](https://github.com/github/github-mcp-server) — github_repository_seed
- [Google Agent Development Kit (ADK)](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [GraphQL](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [gRPC](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [haystack](https://github.com/deepset-ai/haystack) — github_repository_seed
- [hermes-agent](https://github.com/NousResearch/hermes-agent) — github_repository_seed
- [hive](https://github.com/Aden-Hive/hive) — github_repository_seed
- [Human-in-the-loop review](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [JSON-RPC](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [LangChain.js](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [LangChainGo](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [langgraph](https://github.com/langchain-ai/langgraph) — github_repository_seed
- [llama_index](https://github.com/run-llama/llama_index) — github_repository_seed
- [mastra](https://github.com/mastra-ai/mastra) — github_repository_seed
- [MCP client](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [MCP prompt](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [MCP resource](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [MCP server](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [MCP tool](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [Memory retrieval](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [MetaGPT](https://github.com/FoundationAgents/MetaGPT) — github_repository_seed
- [Microsoft AutoGen](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [Microsoft Semantic Kernel](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [Model Context Protocol (MCP)](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [Multi-agent state machine](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [n8n-mcp](https://github.com/czlonkowski/n8n-mcp) — github_repository_seed
- [nanobot](https://github.com/HKUDS/nanobot) — github_repository_seed
- [OAuth delegated access](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/) — ai_agent_or_protocol
- [openai-agents-python](https://github.com/openai/openai-agents-python) — github_repository_seed
- [OpenAPI](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [openfang](https://github.com/RightNow-AI/openfang) — github_repository_seed
- [pydantic-ai](https://github.com/pydantic/pydantic-ai) — github_repository_seed
- [python-sdk](https://github.com/modelcontextprotocol/python-sdk) — github_repository_seed
- [registry](https://github.com/modelcontextprotocol/registry) — github_repository_seed
- [ruflo](https://github.com/ruvnet/ruflo) — github_repository_seed
- [Rust Rig](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [sdk-python](https://github.com/strands-agents/sdk-python) — github_repository_seed
- [semantic-kernel](https://github.com/microsoft/semantic-kernel) — github_repository_seed
- [serena](https://github.com/oraios/serena) — github_repository_seed
- [servers](https://github.com/modelcontextprotocol/servers) — github_repository_seed
- [smolagents](https://github.com/huggingface/smolagents) — github_repository_seed
- [Strands Agents](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [Tool approval gates](https://modelcontextprotocol.io/) — ai_agent_or_protocol
- [Upsonic](https://github.com/Upsonic/Upsonic) — github_repository_seed

### L12 — Bots, crawlers, browsers & automation
Web search crawlers, browser automation, message bots, CI automations.

**Boundary:** Crawler user-agent claims are not proof of bot identity.

**Indexed entries (54):**

- [AdaptiveCards](https://github.com/microsoft/AdaptiveCards) — github_repository_seed
- [aiogram](https://github.com/aiogram/aiogram) — github_repository_seed
- [Applebot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Baiduspider](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Bingbot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Bot Framework SDK](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [BotFramework-WebChat](https://github.com/microsoft/BotFramework-WebChat) — github_repository_seed
- [botman](https://github.com/botman/botman) — github_repository_seed
- [Browserless](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Buildkite agents](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [CCBot (Common Crawl)](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Chromium headless](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [ClaudeBot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [cog](https://github.com/operable/cog) — github_repository_seed
- [Crawlee](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [discord.js](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [discord.py](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [DuckDuckBot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Email autoresponder bots](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Firefox headless](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [GitHub Actions runners](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [GitHub Apps](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [GitHub Copilot coding agent](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [GitHub Dependabot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [GitLab Runners](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Google-Extended crawler token](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Googlebot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [GPTBot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Hexabot](https://github.com/hexabot-ai/Hexabot) — github_repository_seed
- [hikari](https://github.com/hikari-py/hikari) — github_repository_seed
- [Hikari bot framework](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [jbot](https://github.com/rampatra/jbot) — github_repository_seed
- [Jenkins](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [nextcord](https://github.com/nextcord/nextcord) — github_repository_seed
- [node-telegram-bot-api](https://github.com/yagop/node-telegram-bot-api) — github_repository_seed
- [OAI-SearchBot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [opsdroid](https://github.com/opsdroid/opsdroid) — github_repository_seed
- [PerplexityBot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Playwright](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Puppeteer](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [rasa](https://github.com/RasaHQ/rasa) — github_repository_seed
- [Robots Exclusion Protocol (robots.txt)](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Scrapy](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Selenium](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [Slack bot API](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [slacker](https://github.com/shomali11/slacker) — github_repository_seed
- [telego](https://github.com/mymmrac/telego) — github_repository_seed
- [telegraf](https://github.com/telegraf/telegraf) — github_repository_seed
- [Telegram Bot API](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [telegram-bot-sdk](https://github.com/irazasyed/telegram-bot-sdk) — github_repository_seed
- [TwitchIO](https://github.com/TwitchIO/TwitchIO) — github_repository_seed
- [Webhook workers](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [WebKit automation](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser
- [YandexBot](https://www.rfc-editor.org/rfc/rfc9309.html) — bot_crawler_or_browser

### L13 — IoT, embedded RTOS, robotics & radio
Microcontrollers, RTOS, sensors, gateways, fieldbuses, ROS.

**Boundary:** Devices can be intermittently connected and privately managed.

**Indexed entries (51):**

- [6LoWPAN](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Arm Cortex-M](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [autoware](https://github.com/autowarefoundation/autoware) — github_repository_seed
- [autoware_universe](https://github.com/autowarefoundation/autoware_universe) — github_repository_seed
- [Azure RTOS](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [BACnet](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Bluetooth Low Energy](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [CAN bus](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [CoAP](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Contiki-NG](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Cyclone DDS](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [DALI](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [DDS](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Eclipse ThreadX](https://threadx.io/) — iot_firmware_or_protocol
- [Edge gateway](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [ESP-IDF](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [ESP32 microcontroller](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [evo](https://github.com/MichaelGrupp/evo) — github_repository_seed
- [Fast-DDS](https://github.com/eProsima/Fast-DDS) — github_repository_seed
- [FreeRTOS](https://freertos.org/) — iot_firmware_or_protocol
- [glim](https://github.com/koide3/glim) — github_repository_seed
- [iceoryx](https://github.com/eclipse-iceoryx/iceoryx) — github_repository_seed
- [Industrial Ethernet](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [IoT sensor node](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [kiss-icp](https://github.com/PRBonn/kiss-icp) — github_repository_seed
- [KNX](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [LoRaWAN](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [LTE-M](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Matter](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Mbed OS](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [micro-ROS](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Modbus](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [MQTT for IoT](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [navigation2](https://github.com/ros-navigation/navigation2) — github_repository_seed
- [NB-IoT](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [NuttX](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [OPC UA](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [PLC controller](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [PX4-Autopilot](https://github.com/PX4/PX4-Autopilot) — github_repository_seed
- [Raspberry Pi SBC](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [RIOT OS](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [RISC-V MCU](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [ROS 2](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [ROS Navigation2](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [rtabmap](https://github.com/introlab/rtabmap) — github_repository_seed
- [Thread mesh](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [TinyGo for microcontrollers](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [webots](https://github.com/cyberbotics/webots) — github_repository_seed
- [Wi-Fi HaLow](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Zephyr RTOS](https://www.zephyrproject.org/) — iot_firmware_or_protocol
- [Zigbee](https://www.zephyrproject.org/) — iot_firmware_or_protocol

### L14 — Decentralized, P2P, blockchain & federation
Distributed hash tables, content addressing, peer discovery, validators, federation.

**Boundary:** Peer identity and permission models vary widely.

**Indexed entries (32):**

- [ActivityPub](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [AT Protocol](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Bitcoin Core](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Bittensor](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [BitTorrent](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [BitTorrent DHT](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Block exchange](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [CometBFT](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Content identifiers (CID)](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Cosmos SDK](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Decentralized GPU marketplace](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Distributed peer discovery](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Erigon](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Ethereum execution clients](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Filecoin](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Geth (go-ethereum)](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [GossipSub](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Hypercore](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [IPFS](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [IPNS](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Kademlia DHT](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Kubo](https://docs.ipfs.tech/how-to/command-line-quick-start/) — decentralized_node_or_protocol
- [libp2p](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Matrix protocol](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Nethermind](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Polkadot](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Render Network](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Reth](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Solana validator](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Substrate](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [Tendermint BFT](https://docs.ipfs.tech/) — decentralized_node_or_protocol
- [WebRTC](https://docs.ipfs.tech/) — decentralized_node_or_protocol

### L15 — Observability, defense, compliance & supply chain
OTel, eBPF, metrics, logs, policy, WAF and provenance.

**Boundary:** Monitoring should be read-only and authorized.

**Indexed entries (48):**

- [Cloudflare DDoS protection](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Cloudflare WAF](https://developers.cloudflare.com/waf/) — observability_or_defense
- [Cosign](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [CycloneDX](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Datadog](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [eBPF tracing](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Envoy Proxy](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Falco](https://falco.org/) — observability_or_defense
- [Falco rules](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Fluent Bit](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Fluentd](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Grafana](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Grafana Loki](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Grafana Tempo](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Grype](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [HAProxy](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [HashiCorp Vault](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Immutable audit logs](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Incident response runbooks](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Jaeger](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Kyverno](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [ModSecurity](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [NGINX](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Open Policy Agent (OPA)](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [OpenSearch Observability](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [OpenTelemetry](https://opentelemetry.io/) — observability_or_defense
- [OpenTelemetry Collector](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [OSQuery](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [OTLP](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [OWASP Core Rule Set](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Pixie](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Prometheus](https://prometheus.io/) — observability_or_defense
- [Prometheus Alertmanager](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Prometheus exporters](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Read-only telemetry collectors](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [SBOM](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Sentry](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Sigstore](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [SLSA](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [SPDX](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [SPIFFE/SPIRE identity](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Suricata](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Trivy](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Vector (telemetry)](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Wazuh](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [XDP filtering](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Zeek](https://opentelemetry.io/docs/collector/) — observability_or_defense
- [Zipkin](https://opentelemetry.io/docs/collector/) — observability_or_defense

### L16 — Registries, measurement & public discovery
Public source indexes, routing observations, Internet registries and package ecosystems.

**Boundary:** Public catalogs cannot enumerate private deployments.

**Indexed entries (60):**

- [Anaconda.org](https://anaconda.org/) — public_directory
- [Artifact Hub](https://artifacthub.io/) — public_directory
- [CAIDA AS Rank](https://asrank.caida.org/) — public_directory
- [CAIDA Internet Datasets](https://www.caida.org/catalog/datasets/overview/) — public_directory
- [Certificate Transparency Public Logs](https://certificate.transparency.dev/logs/) — public_directory
- [Cloudflare Awesome Agents](https://github.com/cloudflare/awesome-agents) — public_directory
- [Cloudflare Workers examples](https://developers.cloudflare.com/workers/examples/) — public_directory
- [Cloudflare Workers language support](https://developers.cloudflare.com/workers/languages/) — public_directory
- [Cloudflare Workers templates](https://github.com/cloudflare/templates) — public_directory
- [CNCF Landscape](https://landscape.cncf.io/) — public_directory
- [CNCF project list](https://www.cncf.io/projects/) — public_directory
- [ComfyUI Registry](https://registry.comfy.org/) — public_directory
- [Conda-forge](https://conda-forge.org/) — public_directory
- [crates.io](https://crates.io/) — public_directory
- [Deno JSR](https://jsr.io/) — public_directory
- [Docker Hub](https://hub.docker.com/) — public_directory
- [Fermyon Spin](https://www.fermyon.com/spin) — public_directory
- [GitHub agent frameworks topic](https://github.com/topics/agent-framework) — public_directory
- [GitHub AI agents topic](https://github.com/topics/ai-agents) — public_directory
- [GitHub bots topic](https://github.com/topics/bot) — public_directory
- [GitHub Cloudflare topic](https://github.com/topics/cloudflare-workers) — public_directory
- [GitHub Container Registry (GHCR)](https://ghcr.io/) — public_directory
- [GitHub Marketplace](https://github.com/marketplace) — public_directory
- [GitHub MCP topic](https://github.com/topics/mcp-server) — public_directory
- [Go packages](https://pkg.go.dev/) — public_directory
- [Hex](https://hex.pm/) — public_directory
- [Hugging Face Agents](https://huggingface.co/docs/hub/agents) — public_directory
- [IANA DNS Root Files](https://www.iana.org/domains/root/files) — public_directory
- [IANA Protocol Registries](https://www.iana.org/protocols) — public_directory
- [IANA Root Server Directory](https://www.iana.org/domains/root/servers) — public_directory
- [IANA TLD Database](https://www.iana.org/domains/root/db) — public_directory
- [IETF Datatracker](https://datatracker.ietf.org/) — public_directory
- [Linux Foundation Landscape](https://landscape.cncf.io/) — public_directory
- [LuaRocks](https://luarocks.org/) — public_directory
- [Maven Central](https://central.sonatype.com/) — public_directory
- [MCP Registry](https://registry.modelcontextprotocol.io/) — public_directory
- [MCP registry source](https://github.com/modelcontextprotocol/registry) — public_directory
- [n8n community nodes directory](https://communitynodes.creahive.com/) — public_directory
- [n8n workflow-node search](https://workflownodes.vercel.app/) — public_directory
- [npm](https://www.npmjs.com/) — public_directory
- [NuGet](https://www.nuget.org/) — public_directory
- [OCI Image Specification](https://github.com/opencontainers/image-spec) — public_directory
- [Open Compute Project](https://www.opencompute.org/) — public_directory
- [Open VSX Registry](https://open-vsx.org/) — public_directory
- [OpenTelemetry Registry](https://opentelemetry.io/ecosystem/registry/) — public_directory
- [Packagist](https://packagist.org/) — public_directory
- [PeeringDB](https://www.peeringdb.com/) — public_directory
- [PeeringDB REST API](https://www.peeringdb.com/apidocs/) — public_directory
- [pub.dev](https://pub.dev/) — public_directory
- [PyPI](https://pypi.org/) — public_directory
- [Regional Internet Registries via NRO](https://www.nro.net/about/rirs/) — public_directory
- [RIPE Routing Information Service](https://www.ripe.net/analyse/internet-measurements/routing-information-service-ris/) — public_directory
- [RIPE RPKI Validation](https://stat.ripe.net/docs/data-api/api-endpoints/rpki-validation) — public_directory
- [RIPEstat Data API](https://stat.ripe.net/docs/data-api/) — public_directory
- [Root Servers Organization](https://root-servers.org/) — public_directory
- [ROS Index](https://index.ros.org/) — public_directory
- [Route Views Project](https://www.routeviews.org/routeviews/) — public_directory
- [RubyGems](https://rubygems.org/) — public_directory
- [TeleGeography Submarine Cable Map](https://www.submarinecablemap.com/) — public_directory
- [Uptime Institute Global Datacenter Research](https://uptimeinstitute.com/) — public_directory

### L17 — Applications, integrations & industry workflows
Service frontends, integrations, no-code nodes, knowledge and application delivery.

**Boundary:** Downstream application examples are not network infrastructure.

**Indexed entries (42):**

- [API service frontends](https://github.com/marketplace) — application_or_integration
- [Artifact registries](https://github.com/marketplace) — application_or_integration
- [awesome-n8n](https://github.com/restyler/awesome-n8n) — github_repository_seed
- [awesome-n8n-msp-nodes](https://github.com/themookfactory/awesome-n8n-msp-nodes) — github_repository_seed
- [Browser SDK clients](https://github.com/marketplace) — application_or_integration
- [Chat bots](https://github.com/marketplace) — application_or_integration
- [CI/CD pipelines](https://github.com/marketplace) — application_or_integration
- [Cloudflare AI Gateway](https://github.com/marketplace) — application_or_integration
- [Cloudflare API Gateway](https://github.com/marketplace) — application_or_integration
- [Cloudflare Worker templates](https://github.com/marketplace) — application_or_integration
- [ComfyUI workflows](https://github.com/marketplace) — application_or_integration
- [Community workflow nodes](https://github.com/marketplace) — application_or_integration
- [Data catalog](https://github.com/marketplace) — application_or_integration
- [Developer portals](https://github.com/marketplace) — application_or_integration
- [Digital twin dashboards](https://github.com/marketplace) — application_or_integration
- [Enterprise SaaS connectors](https://github.com/marketplace) — application_or_integration
- [ETL pipelines](https://github.com/marketplace) — application_or_integration
- [GitHub Actions marketplace](https://github.com/marketplace) — application_or_integration
- [GitHub repositories](https://github.com/marketplace) — application_or_integration
- [IoT dashboards](https://github.com/marketplace) — application_or_integration
- [Knowledge graph applications](https://github.com/marketplace) — application_or_integration
- [MCP server directories](https://github.com/marketplace) — application_or_integration
- [Mobile SDK clients](https://github.com/marketplace) — application_or_integration
- [n8n workflow catalog](https://github.com/marketplace) — application_or_integration
- [n8n-llamacloud](https://github.com/run-llama/n8n-llamacloud) — github_repository_seed
- [n8n-nodes-browserless](https://github.com/minhlucvan/n8n-nodes-browserless) — github_repository_seed
- [n8n-nodes-crawl-and-scrape](https://github.com/swimmingkiim/n8n-nodes-crawl-and-scrape) — github_repository_seed
- [n8n-nodes-globals](https://github.com/umanamente/n8n-nodes-globals) — github_repository_seed
- [n8n-nodes-imap](https://github.com/umanamente/n8n-nodes-imap) — github_repository_seed
- [n8n-nodes-puppeteer](https://github.com/drudge/n8n-nodes-puppeteer) — github_repository_seed
- [n8n-nodes-python](https://github.com/naskio/n8n-nodes-python) — github_repository_seed
- [n8n-nodes-tesseractjs](https://github.com/jreyesr/n8n-nodes-tesseractjs) — github_repository_seed
- [n8n-nodes-twitch](https://github.com/CodelyTV/n8n-nodes-twitch) — github_repository_seed
- [n8n-workflow-all-templates](https://github.com/zengfr/n8n-workflow-all-templates) — github_repository_seed
- [Notification services](https://github.com/marketplace) — application_or_integration
- [RBAC authorization services](https://github.com/marketplace) — application_or_integration
- [Reverse proxies](https://github.com/marketplace) — application_or_integration
- [Secrets vault connectors](https://github.com/marketplace) — application_or_integration
- [Service discovery catalog](https://github.com/marketplace) — application_or_integration
- [Static site deployments](https://github.com/marketplace) — application_or_integration
- [Vector retrieval applications](https://github.com/marketplace) — application_or_integration
- [Webhooks](https://github.com/marketplace) — application_or_integration

## Key interlayer relationships

| From | Relationship | To |
|---|---|---|
| L00 | physical underlay for | L02 |
| L01 | boots host | L04 |
| L02 | transports queries for | L03 |
| L03 | resolves and authenticates | L06 |
| L04 | hosts | L05 |
| L05 | can host | L06 |
| L05 | can host | L07 |
| L07 | uses for state | L08 |
| L07 | can schedule consumers of | L09 |
| L08 | stores agent memory for | L11 |
| L09 | delivers tasks to | L11 |
| L10 | provides model compute to | L11 |
| L11 | can orchestrate | L12 |
| L13 | can publish telemetry into | L09 |
| L14 | communicates over | L02 |
| L15 | observes facilities | L00 |
| L15 | observes and defends | L06 |
| L15 | audits | L11 |
| L16 | indexes public metadata of | L02 |
| L16 | indexes public metadata of | L11 |
| L17 | can use | L11 |
| L17 | can run on | L06 |
| L16 | catalogs public portions of | L14 |

## Representative end-to-end flows (not recorded network traces)

### Public request, resolution and trust

Internet access networks → Recursive DNS resolvers → Root anycast instances → TLD registry servers → Authoritative DNS servers → TLS/mTLS → Cloudflare WAF → Cloudflare Workers → Cloudflare D1 → OpenTelemetry Collector

### Worker queue and durable state

Cloudflare Workers → Cloudflare Queues → Cloudflare Durable Objects → Cloudflare Durable Objects SQLite → OpenTelemetry Collector

### IoT sensor to AI application

IoT sensor node → Zephyr RTOS → Edge gateway → MQTT → Mosquitto → NATS JetStream → Cloudflare Workers → OpenTelemetry Collector

### Kubernetes worker scheduling

Linux kernel → containerd → Kubernetes → Kubernetes kubelet → etcd → Raft consensus → OpenTelemetry Collector

### Agent, tools and memory

Cloudflare Agents SDK → Model Context Protocol (MCP) → MCP server → MCP tool → Qdrant → OpenTelemetry Collector

### P2P content discovery

Internet access networks → IPFS → libp2p → Kademlia DHT → Content identifiers (CID) → Kubo


## Complete requested-topic coverage matrix

| Requested theme | Covered layers | Scope preserved |
|---|---|---|
| Physical global backbone | L00, L02 | fiber, submarine systems, landings, satellite, data centers, PoPs, IXPs, ASNs, BGP, Anycast |
| Firmware rings −3 to −1 | L01 | UEFI/coreboot, BMC/OpenBMC, Intel ME, AMD PSP, SmartNIC/BlueField, boot trust |
| DNS and cryptographic identity | L03 | 13 logical root-server identities, root Anycast, TLD, authoritative, recursive, DNSSEC, ACME, CT, PKI |
| State and persistent memory | L08 | etcd/Consul/ZooKeeper, D1/KV/R2, FoundationDB/CockroachDB/TiKV, Milvus/Qdrant/Weaviate/Neo4j |
| Messages and streaming | L09 | Kafka, Redpanda, NATS, RabbitMQ, Redis Streams, Cloudflare Queues, AMQP, MQTT |
| Embedded, RTOS and IoT | L13 | FreeRTOS, Zephyr, ThreadX, MQTT, CoAP, LoRaWAN, Matter/Thread, gateways |
| Telemetry and security | L15 | eBPF, Cilium, Falco, Pixie, OTel, Prometheus, Vector, WAF, Envoy, NGINX |
| Edge execution | L05, L06 | Cloudflare, Fastly, Akamai, Lambda@Edge, Deno Deploy, V8, Wasm |
| Multi-agent frameworks | L11 | LangGraph, CrewAI, AutoGen, ADK, PydanticAI, Mastra, ElizaOS, Rig, LangChainGo |
| Kernels and sandboxes | L04, L05, L10 | OS kernels, Firecracker, Jupyter ZeroMQ kernels, Wasmtime, gVisor, Kata, CUDA and ROCm kernels |
| Distributed schedulers and workers | L07 | Celery, BullMQ, Sidekiq, Temporal, Kubernetes/kubelet, Ray, Spark, Slurm, Borg, ECS, Apollo |
| Decentralized and P2P nodes | L14 | BitTorrent DHT, IPFS/Kubo, Filecoin, Bittensor, Render, Ethereum, Solana, Bitcoin |
| Web crawler and browser workers | L12 | Googlebot, Bingbot, Applebot, GPTBot, OAI-SearchBot, ClaudeBot, CCBot, Playwright, Puppeteer, Selenium |
| Agent interoperability and federation | L11, L14 | MCP, A2A, OpenAPI, GraphQL, gRPC, ActivityPub, AT Protocol, Matrix |
| Physical telemetry and trust | L00, L01, L03, L15 | firmware trust, power/thermal, TLS/mTLS, identity, packet and application observability |
| Packages, languages and registries | L16 | previous 36 discovery directories plus RIR/RIS/CAIDA/PeeringDB/CT/IANA and language package registries |
| Programming language coverage | L04, L05, L06, L07, L10, L11, L12, L13, L14, L15 | Python, Rust, Go, TS/JS, C/C++, Java, Scala, Erlang, Ruby, Kotlin, Swift, PHP, Dart, R, Julia, Zig and others |
| Geographic network topology | L00, L02, L16 | city-level illustrative hub index; authoritative datasets needed for facilities/cables/live BGP |

## Public data sources and boundaries

| Registry or source | Use | Important limit |
|---|---|---|
| [IANA Root Server Directory](https://www.iana.org/domains/root/servers) | Logical root servers | Not all physical instances |
| [IANA Root Files](https://www.iana.org/domains/root/files) | Root hints records | No private recursive resolvers |
| [Root Servers](https://root-servers.org/) | Instance geography and root operations | Operator-run and variable |
| [NRO](https://www.nro.net/about/rirs/) | Regional registry scope | Not deployed workload counts |
| [RIPE RIS](https://www.ripe.net/analyse/internet-measurements/routing-information-service-ris/) | Publicly observed BGP | Observer coverage limited |
| [RIPEstat](https://stat.ripe.net/docs/data-api/) | Prefix/ASN/route queries | Time-dependent observations |
| [CAIDA AS Rank](https://asrank.caida.org/) | Inferred AS-level relationships | Inference is not ground-truth topology |
| [PeeringDB](https://www.peeringdb.com/apidocs/) | Network exchange and facility directory | Self-reported entries may be stale |
| [Submarine Cable Map](https://www.submarinecablemap.com/) | Public cable systems | Not complete capacity or exact routing |
| [Certificate Transparency](https://certificate.transparency.dev/logs/) | Certificate log directories | Certificates are not proof of active service |
| [Let’s Encrypt ACME](https://letsencrypt.org/how-it-works/) | Automated certificate issuance | Other CAs exist |
| [OpenBMC](https://openbmc.org/) | BMC firmware | Only supported hardware |
| [UEFI Forum](https://uefi.org/specifications) | Platform boot specifications | Not open access to device firmware |
| [etcd](https://etcd.io/) | Consensus KV store | Cluster topology not public |
| [Apache ZooKeeper Zab](https://cwiki.apache.org/confluence/spaces/ZOOKEEPER/pages/24189846/Zab1.0) | Zab protocol | Not Raft or Paxos |
| [Cloudflare Workers](https://developers.cloudflare.com/workers/) | Worker runtime and bindings | Not full Cloudflare node inventory |
| [Cloudflare Durable Objects](https://developers.cloudflare.com/durable-objects/) | Durable state coordination | No particular app deployed |
| [NATS JetStream](https://docs.nats.io/concepts/jetstream) | Persistent message delivery | Not identical to core NATS pub-sub |
| [FreeRTOS](https://freertos.org/) | Microcontroller RTOS | Hardware dependent |
| [OpenTelemetry Collector](https://opentelemetry.io/docs/collector/) | Telemetry pipeline | Does not imply host authorization |
| [Official MCP Registry](https://registry.modelcontextprotocol.io/) | Published MCP servers | Listings not security attestations |
| [CNCF Landscape](https://landscape.cncf.io/) | Cloud-native projects | Not installation data |
| [GitHub Topics](https://github.com/topics/ai-agents) | Repository discovery | Topic duplication and stale repos |
| [Hugging Face](https://huggingface.co/) | Models and applications | Licenses differ |

## Frequently misunderstood distinctions

- There are 13 logical DNS root server identities, served by multiple physical anycast instances and operated by 12 organizations; not 13 singular machines.
- UEFI, coreboot, BMC firmware, Intel ME, AMD PSP and DPU operating environments are different classes of firmware or embedded runtime, not all interchangeable microkernels.
- etcd and Consul use Raft. ZooKeeper uses ZooKeeper Atomic Broadcast (Zab), not Raft; Paxos is a family of consensus algorithms used elsewhere.
- Cloudflare Workers are not arbitrary Linux servers. A compatible Worker or approved external container is needed for non-Workers software.
- DNS Certificate Transparency logs contain certificate records and do not establish server uptime, ownership of all hosts, or software installed.
- BGP collectors and PeeringDB yield partial, sometimes inferred or self-reported network topology, not the full planet-wide physical or private network.
- A bot name or HTTP user-agent is not a cryptographic identity, and crawler policy must be independently evaluated.
- GPU kernels, OS kernels, Jupyter kernels and communication kernels are distinct concepts.
- Some components are proprietary or service-managed; a public mention does not grant operational access.
- No global port scanning, device enumeration, exploit checks, or remote deployment is part of this catalog.

## Languages and protocols (searchable indexes)

Language labels: C, C#, C++, CUDA, Erlang, Go, Java, JavaScript, Python, Ruby, Rust, Rust via WebAssembly, Scala, TypeScript.

Protocol labels: ACME, AMQP, BGP, Bluetooth LE, Bolt, CID, CT, Cypher, DDS, DNS, DNSSEC, etcd, Ethernet, Fetch API, gRPC, HTTP, IPFS, IPMI, IPv4, IPv6, JSON-RPC, Kafka Wire Protocol, Kubernetes API, libp2p, MQTT, NATS, OTLP, PCIe, Prometheus Remote Write, Queue API, Raft, Redfish, REST, RPKI, S3 API, SPIFFE ID, SQL, TCP/IP, Thread, TLS, UEFI, WebSockets, Zab.

The catalog is an open-ended index. Names and projects have not been installed or security-reviewed. Runtime-specific deployment and license verification are separate later steps.

## Example database queries

```sql
-- Read the whole catalog with category labels
SELECT c.id, c.name, l.name AS layer FROM components c JOIN layers l ON l.id=c.primary_layer ORDER BY l.canonical_order, c.name;
-- Find a protocol or language
SELECT c.name, t.value FROM tags t JOIN components c ON c.id=t.component_id WHERE t.value = 'MQTT';
-- View typed connections
SELECT a.name AS from_name,r.relation,b.name AS to_name FROM relationships r JOIN components a ON a.id=r.from_id JOIN components b ON b.id=r.to_id;
-- Full-text search
SELECT id,name FROM search WHERE search MATCH 'kernel';
```
