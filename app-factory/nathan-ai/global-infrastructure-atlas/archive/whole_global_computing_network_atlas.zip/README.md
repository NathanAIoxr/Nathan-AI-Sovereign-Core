# Whole Global Computing Network Atlas

Snapshot: 2026-11-18

## Files
- `whole_global_network_interactive.html` — offline self-contained interactive stack, searchable component index, typed edges, flows, city-level reference diagram and coverage matrix.
- `whole_global_network_atlas.json` — canonical machine-readable, normalized nodes, relationships, public sources, coverage and language/protocol indexes.
- `whole_global_network_atlas.sqlite` — searchable relational SQLite database with FTS5 index.
- `whole_global_network_reference.md` — complete long-form reference index with every component and links.
- `components.csv`, `relationships.csv`, `layers.csv`, `registries_sources.csv`, `coverage_matrix.csv`, `geographic_hubs.csv` — CSV extracts.
- `illustrative_global_hubs.geojson` — approximate metro-level map markers.
- `schema.sql` — example SQL read queries.
- `original_seed/global_tech_inventory.json` and `original_seed/global_discovery.py` — preserved previous discovery snapshot and read-only discovery program.

## Count and traceability
- 871 distinct named components / public repository seed entries
- 18 infrastructure layers
- 83 named component relations; 23 layer-level relations
- 24 high-quality source directories/standards links
- All 205 prior GitHub discovery entries maintained via `prior_catalog_id_map`.
- All 36 previous directories retained as catalog components.

## Safety and accuracy
This is not a discovery scan, a network ownership claim, a real-time host census or a software deployment. All previous GitHub repositories are candidates awaiting license, security, and compatibility review. Private network details are not inferred. Connections are architectural examples, not measured links. The physical map shows example city centroids, not surveyed hardware, submarine cable lines or facilities. No user credentials are present.

To inspect locally, open the HTML in any current browser. To query, open SQLite in `sqlite3` or any SQL browser. No additional packages required.
