# Global technology discovery — Nathan AI

**Snapshot:** 2026-11-18  
**Distinct GitHub repositories in this curated seed catalog:** 205  
**Public registries/directories:** 36  
**Scope:** Public source code and catalogs; not a network scan or proof of deployment.

This is a hand-reviewed discovery starter index, not an exhaustive internet inventory. The `cloudflare_fit` field is a preliminary routing hint, not a verified compatibility result. Language, licenses, maintainer activity, and vulnerabilities require follow-up checks.

## Catalog by category

### Cloudflare Workers / edge apps (17)

- [honojs/hono](https://github.com/honojs/hono)
- [cloudflare/workers-sdk](https://github.com/cloudflare/workers-sdk)
- [cloudflare/agents](https://github.com/cloudflare/agents)
- [cloudflare/awesome-agents](https://github.com/cloudflare/awesome-agents)
- [cloudflare/templates](https://github.com/cloudflare/templates)
- [cloudflare/workerd](https://github.com/cloudflare/workerd)
- [cloudflare/vibesdk](https://github.com/cloudflare/vibesdk)
- [cloudflare/moltworker](https://github.com/cloudflare/moltworker)
- [supermemoryai/supermemory](https://github.com/supermemoryai/supermemory)
- [oomol-lab/open-connector](https://github.com/oomol-lab/open-connector)
- [vikiboss/60s](https://github.com/vikiboss/60s)
- [webstudio-is/webstudio](https://github.com/webstudio-is/webstudio)
- [panva/jose](https://github.com/panva/jose)
- [microfeed/microfeed](https://github.com/microfeed/microfeed)
- [dreamhunter2333/cloudflare_temp_email](https://github.com/dreamhunter2333/cloudflare_temp_email)
- [maillab/cloud-mail](https://github.com/maillab/cloud-mail)
- [shuaiplus/nodewarden](https://github.com/shuaiplus/nodewarden)

### Edge & WebAssembly runtimes (13)

- [WasmEdge/WasmEdge](https://github.com/WasmEdge/WasmEdge)
- [wasm3/wasm3](https://github.com/wasm3/wasm3)
- [wasmi-labs/wasmi](https://github.com/wasmi-labs/wasmi)
- [wasmerio/wasmer](https://github.com/wasmerio/wasmer)
- [bytecodealliance/wasmtime](https://github.com/bytecodealliance/wasmtime)
- [wasmCloud/wasmCloud](https://github.com/wasmCloud/wasmCloud)
- [fermyon/spin](https://github.com/fermyon/spin)
- [emscripten-core/emscripten](https://github.com/emscripten-core/emscripten)
- [AssemblyScript/assemblyscript](https://github.com/AssemblyScript/assemblyscript)
- [tinygo-org/tinygo](https://github.com/tinygo-org/tinygo)
- [pyodide/pyodide](https://github.com/pyodide/pyodide)
- [eclipse-zenoh/zenoh](https://github.com/eclipse-zenoh/zenoh)
- [partykit/partykit](https://github.com/partykit/partykit)

### AI agents & orchestration (28)

- [cloudflare/agents](https://github.com/cloudflare/agents)
- [google/adk-python](https://github.com/google/adk-python)
- [google/adk-java](https://github.com/google/adk-java)
- [google/adk-go](https://github.com/google/adk-go)
- [microsoft/agent-framework](https://github.com/microsoft/agent-framework)
- [langchain-ai/langgraph](https://github.com/langchain-ai/langgraph)
- [crewAIInc/crewAI](https://github.com/crewAIInc/crewAI)
- [run-llama/llama_index](https://github.com/run-llama/llama_index)
- [pydantic/pydantic-ai](https://github.com/pydantic/pydantic-ai)
- [deepset-ai/haystack](https://github.com/deepset-ai/haystack)
- [agentscope-ai/agentscope](https://github.com/agentscope-ai/agentscope)
- [agentscope-ai/agentscope-java](https://github.com/agentscope-ai/agentscope-java)
- [strands-agents/sdk-python](https://github.com/strands-agents/sdk-python)
- [huggingface/smolagents](https://github.com/huggingface/smolagents)
- [agno-agi/agno](https://github.com/agno-agi/agno)
- [mastra-ai/mastra](https://github.com/mastra-ai/mastra)
- [microsoft/autogen](https://github.com/microsoft/autogen)
- [microsoft/semantic-kernel](https://github.com/microsoft/semantic-kernel)
- [HKUDS/nanobot](https://github.com/HKUDS/nanobot)
- [NousResearch/hermes-agent](https://github.com/NousResearch/hermes-agent)
- [bytedance/deer-flow](https://github.com/bytedance/deer-flow)
- [FoundationAgents/MetaGPT](https://github.com/FoundationAgents/MetaGPT)
- [CopilotKit/CopilotKit](https://github.com/CopilotKit/CopilotKit)
- [RightNow-AI/openfang](https://github.com/RightNow-AI/openfang)
- [Aden-Hive/hive](https://github.com/Aden-Hive/hive)
- [Upsonic/Upsonic](https://github.com/Upsonic/Upsonic)
- [openai/openai-agents-python](https://github.com/openai/openai-agents-python)
- [google/adk-docs](https://github.com/google/adk-docs)

### MCP servers & integration (13)

- [modelcontextprotocol/registry](https://github.com/modelcontextprotocol/registry)
- [modelcontextprotocol/servers](https://github.com/modelcontextprotocol/servers)
- [modelcontextprotocol/python-sdk](https://github.com/modelcontextprotocol/python-sdk)
- [github/github-mcp-server](https://github.com/github/github-mcp-server)
- [ChromeDevTools/chrome-devtools-mcp](https://github.com/ChromeDevTools/chrome-devtools-mcp)
- [upstash/context7](https://github.com/upstash/context7)
- [oraios/serena](https://github.com/oraios/serena)
- [mksglu/context-mode](https://github.com/mksglu/context-mode)
- [DeusData/codebase-memory-mcp](https://github.com/DeusData/codebase-memory-mcp)
- [czlonkowski/n8n-mcp](https://github.com/czlonkowski/n8n-mcp)
- [ruvnet/ruflo](https://github.com/ruvnet/ruflo)
- [activepieces/activepieces](https://github.com/activepieces/activepieces)
- [google-gemini/gemini-cli](https://github.com/google-gemini/gemini-cli)

### Bots & messaging (17)

- [RasaHQ/rasa](https://github.com/RasaHQ/rasa)
- [yagop/node-telegram-bot-api](https://github.com/yagop/node-telegram-bot-api)
- [telegraf/telegraf](https://github.com/telegraf/telegraf)
- [botman/botman](https://github.com/botman/botman)
- [aiogram/aiogram](https://github.com/aiogram/aiogram)
- [irazasyed/telegram-bot-sdk](https://github.com/irazasyed/telegram-bot-sdk)
- [microsoft/AdaptiveCards](https://github.com/microsoft/AdaptiveCards)
- [microsoft/BotFramework-WebChat](https://github.com/microsoft/BotFramework-WebChat)
- [nextcord/nextcord](https://github.com/nextcord/nextcord)
- [rampatra/jbot](https://github.com/rampatra/jbot)
- [hexabot-ai/Hexabot](https://github.com/hexabot-ai/Hexabot)
- [mymmrac/telego](https://github.com/mymmrac/telego)
- [hikari-py/hikari](https://github.com/hikari-py/hikari)
- [operable/cog](https://github.com/operable/cog)
- [TwitchIO/TwitchIO](https://github.com/TwitchIO/TwitchIO)
- [opsdroid/opsdroid](https://github.com/opsdroid/opsdroid)
- [shomali11/slacker](https://github.com/shomali11/slacker)

### Workflow engines & durable jobs (17)

- [n8n-io/n8n](https://github.com/n8n-io/n8n)
- [apache/airflow](https://github.com/apache/airflow)
- [conductor-oss/conductor](https://github.com/conductor-oss/conductor)
- [Budibase/budibase](https://github.com/Budibase/budibase)
- [dapr/dapr](https://github.com/dapr/dapr)
- [nocobase/nocobase](https://github.com/nocobase/nocobase)
- [temporalio/temporal](https://github.com/temporalio/temporal)
- [PrefectHQ/prefect](https://github.com/PrefectHQ/prefect)
- [windmill-labs/windmill](https://github.com/windmill-labs/windmill)
- [argoproj/argo-workflows](https://github.com/argoproj/argo-workflows)
- [flowable/flowable-engine](https://github.com/flowable/flowable-engine)
- [hatchet-dev/hatchet](https://github.com/hatchet-dev/hatchet)
- [inngest/inngest](https://github.com/inngest/inngest)
- [restatedev/restate](https://github.com/restatedev/restate)
- [danielgerlag/workflow-core](https://github.com/danielgerlag/workflow-core)
- [ergo-services/ergo](https://github.com/ergo-services/ergo)
- [iflytek/astron-agent](https://github.com/iflytek/astron-agent)

### Automation and community nodes (13)

- [drudge/n8n-nodes-puppeteer](https://github.com/drudge/n8n-nodes-puppeteer)
- [umanamente/n8n-nodes-globals](https://github.com/umanamente/n8n-nodes-globals)
- [naskio/n8n-nodes-python](https://github.com/naskio/n8n-nodes-python)
- [minhlucvan/n8n-nodes-browserless](https://github.com/minhlucvan/n8n-nodes-browserless)
- [umanamente/n8n-nodes-imap](https://github.com/umanamente/n8n-nodes-imap)
- [jreyesr/n8n-nodes-tesseractjs](https://github.com/jreyesr/n8n-nodes-tesseractjs)
- [CodelyTV/n8n-nodes-twitch](https://github.com/CodelyTV/n8n-nodes-twitch)
- [swimmingkiim/n8n-nodes-crawl-and-scrape](https://github.com/swimmingkiim/n8n-nodes-crawl-and-scrape)
- [run-llama/n8n-llamacloud](https://github.com/run-llama/n8n-llamacloud)
- [restyler/awesome-n8n](https://github.com/restyler/awesome-n8n)
- [Synaptiv-AI/awesome-n8n](https://github.com/Synaptiv-AI/awesome-n8n)
- [zengfr/n8n-workflow-all-templates](https://github.com/zengfr/n8n-workflow-all-templates)
- [themookfactory/awesome-n8n-msp-nodes](https://github.com/themookfactory/awesome-n8n-msp-nodes)

### Kernels & kernel-adjacent (12)

- [SerenityOS/serenity](https://github.com/SerenityOS/serenity)
- [cilium/cilium](https://github.com/cilium/cilium)
- [gvisor/gvisor](https://github.com/gvisor/gvisor)
- [reactos/reactos](https://github.com/reactos/reactos)
- [redox-os/redox](https://github.com/redox-os/redox)
- [RT-Thread/rt-thread](https://github.com/RT-Thread/rt-thread)
- [phil-opp/blog_os](https://github.com/phil-opp/blog_os)
- [sysprog21/lkmpg](https://github.com/sysprog21/lkmpg)
- [rust-embedded/rust-raspberrypi-OS-tutorials](https://github.com/rust-embedded/rust-raspberrypi-OS-tutorials)
- [seL4/seL4](https://github.com/seL4/seL4)
- [zephyrproject-rtos/zephyr](https://github.com/zephyrproject-rtos/zephyr)
- [freebsd/freebsd-src](https://github.com/freebsd/freebsd-src)

### Operating systems & system images (9)

- [HeyPuter/puter](https://github.com/HeyPuter/puter)
- [SerenityOS/serenity](https://github.com/SerenityOS/serenity)
- [reactos/reactos](https://github.com/reactos/reactos)
- [redox-os/redox](https://github.com/redox-os/redox)
- [bottlerocket-os/bottlerocket](https://github.com/bottlerocket-os/bottlerocket)
- [ublue-os/bazzite](https://github.com/ublue-os/bazzite)
- [zephyrproject-rtos/zephyr](https://github.com/zephyrproject-rtos/zephyr)
- [RT-Thread/rt-thread](https://github.com/RT-Thread/rt-thread)
- [seL4/seL4](https://github.com/seL4/seL4)

### Distributed compute & messaging (12)

- [nats-io/nats-server](https://github.com/nats-io/nats-server)
- [hazelcast/hazelcast](https://github.com/hazelcast/hazelcast)
- [livebook-dev/livebook](https://github.com/livebook-dev/livebook)
- [Eventual-Inc/Daft](https://github.com/Eventual-Inc/Daft)
- [asynkron/protoactor-go](https://github.com/asynkron/protoactor-go)
- [chrislusf/gleam](https://github.com/chrislusf/gleam)
- [lakehq/sail](https://github.com/lakehq/sail)
- [eclipse-zenoh/zenoh](https://github.com/eclipse-zenoh/zenoh)
- [kuberay-project/kuberay](https://github.com/kuberay-project/kuberay)
- [BOINC/boinc](https://github.com/BOINC/boinc)
- [ray-project/ray](https://github.com/ray-project/ray)
- [hpcaitech/ColossalAI](https://github.com/hpcaitech/ColossalAI)

### Kubernetes / operators / platform (14)

- [meshery/meshery](https://github.com/meshery/meshery)
- [strimzi/strimzi-kafka-operator](https://github.com/strimzi/strimzi-kafka-operator)
- [CrunchyData/postgres-operator](https://github.com/CrunchyData/postgres-operator)
- [cyclops-ui/cyclops](https://github.com/cyclops-ui/cyclops)
- [kubeflow/spark-operator](https://github.com/kubeflow/spark-operator)
- [nolar/kopf](https://github.com/nolar/kopf)
- [flant/shell-operator](https://github.com/flant/shell-operator)
- [Altinity/clickhouse-operator](https://github.com/Altinity/clickhouse-operator)
- [projectcapsule/capsule](https://github.com/projectcapsule/capsule)
- [operator-framework/operator-lifecycle-manager](https://github.com/operator-framework/operator-lifecycle-manager)
- [open-telemetry/opentelemetry-operator](https://github.com/open-telemetry/opentelemetry-operator)
- [ansible/awx-operator](https://github.com/ansible/awx-operator)
- [ongres/stackgres](https://github.com/ongres/stackgres)
- [grafana/grafana-operator](https://github.com/grafana/grafana-operator)

### Robotics / ROS / machine nodes (12)

- [PX4/PX4-Autopilot](https://github.com/PX4/PX4-Autopilot)
- [autowarefoundation/autoware](https://github.com/autowarefoundation/autoware)
- [ros-navigation/navigation2](https://github.com/ros-navigation/navigation2)
- [cyberbotics/webots](https://github.com/cyberbotics/webots)
- [MichaelGrupp/evo](https://github.com/MichaelGrupp/evo)
- [introlab/rtabmap](https://github.com/introlab/rtabmap)
- [eclipse-zenoh/zenoh](https://github.com/eclipse-zenoh/zenoh)
- [eProsima/Fast-DDS](https://github.com/eProsima/Fast-DDS)
- [PRBonn/kiss-icp](https://github.com/PRBonn/kiss-icp)
- [eclipse-iceoryx/iceoryx](https://github.com/eclipse-iceoryx/iceoryx)
- [koide3/glim](https://github.com/koide3/glim)
- [autowarefoundation/autoware_universe](https://github.com/autowarefoundation/autoware_universe)

### AI inference / serving / distributed ML (11)

- [nomic-ai/gpt4all](https://github.com/nomic-ai/gpt4all)
- [ray-project/ray](https://github.com/ray-project/ray)
- [Lightning-AI/litgpt](https://github.com/Lightning-AI/litgpt)
- [bentoml/OpenLLM](https://github.com/bentoml/OpenLLM)
- [openvinotoolkit/openvino](https://github.com/openvinotoolkit/openvino)
- [Tiiny-AI/PowerInfer](https://github.com/Tiiny-AI/PowerInfer)
- [bentoml/BentoML](https://github.com/bentoml/BentoML)
- [ai-dynamo/dynamo](https://github.com/ai-dynamo/dynamo)
- [InternLM/lmdeploy](https://github.com/InternLM/lmdeploy)
- [hpcaitech/ColossalAI](https://github.com/hpcaitech/ColossalAI)
- [tursodatabase/turso](https://github.com/tursodatabase/turso)

### Schedulers / queues (10)

- [apache/dolphinscheduler](https://github.com/apache/dolphinscheduler)
- [skypilot-org/skypilot](https://github.com/skypilot-org/skypilot)
- [agenda/agenda](https://github.com/agenda/agenda)
- [resque/resque](https://github.com/resque/resque)
- [PowerJob/PowerJob](https://github.com/PowerJob/PowerJob)
- [quartznet/quartznet](https://github.com/quartznet/quartznet)
- [dagucloud/dagu](https://github.com/dagucloud/dagu)
- [mesos/chronos](https://github.com/mesos/chronos)
- [bee-queue/bee-queue](https://github.com/bee-queue/bee-queue)
- [reugn/go-quartz](https://github.com/reugn/go-quartz)

### Serverless frameworks (9)

- [serverless/serverless](https://github.com/serverless/serverless)
- [serverless/examples](https://github.com/serverless/examples)
- [aws/chalice](https://github.com/aws/chalice)
- [midwayjs/midway](https://github.com/midwayjs/midway)
- [CodeGenieApp/serverless-express](https://github.com/CodeGenieApp/serverless-express)
- [middyjs/middy](https://github.com/middyjs/middy)
- [zappa/Zappa](https://github.com/zappa/Zappa)
- [Serverless-Devs/Serverless-Devs](https://github.com/Serverless-Devs/Serverless-Devs)
- [serverless-operations/serverless-step-functions](https://github.com/serverless-operations/serverless-step-functions)

### Visual AI / ComfyUI nodes (9)

- [ATH-MaaS/ComfyUI-Copilot](https://github.com/ATH-MaaS/ComfyUI-Copilot)
- [numz/ComfyUI-SeedVR2_VideoUpscaler](https://github.com/numz/ComfyUI-SeedVR2_VideoUpscaler)
- [1038lab/ComfyUI-RMBG](https://github.com/1038lab/ComfyUI-RMBG)
- [Enemyx-net/VibeVoice-ComfyUI](https://github.com/Enemyx-net/VibeVoice-ComfyUI)
- [Acly/comfyui-inpaint-nodes](https://github.com/Acly/comfyui-inpaint-nodes)
- [christian-byrne/audio-separation-nodes-comfyui](https://github.com/christian-byrne/audio-separation-nodes-comfyui)
- [wildminder/ComfyUI-DyPE](https://github.com/wildminder/ComfyUI-DyPE)
- [wildminder/ComfyUI-VibeVoice](https://github.com/wildminder/ComfyUI-VibeVoice)
- [TemryL/ComfyUI-IDM-VTON](https://github.com/TemryL/ComfyUI-IDM-VTON)

## Source registries

- [Cloudflare Workers examples](https://developers.cloudflare.com/workers/examples/) — Worker source templates
- [Cloudflare Workers templates](https://github.com/cloudflare/templates) — Worker starters
- [Cloudflare Agents SDK](https://github.com/cloudflare/agents) — Durable AI agents
- [Cloudflare Awesome Agents](https://github.com/cloudflare/awesome-agents) — Agents SDK ecosystem
- [Cloudflare Workers language support](https://developers.cloudflare.com/workers/languages/) — Compatibility matrix
- [GitHub Cloudflare topic](https://github.com/topics/cloudflare-workers) — Public project discovery
- [GitHub AI agents topic](https://github.com/topics/ai-agents) — Public project discovery
- [GitHub bots topic](https://github.com/topics/bot) — Public project discovery
- [GitHub agent frameworks topic](https://github.com/topics/agent-framework) — Public project discovery
- [GitHub MCP topic](https://github.com/topics/mcp-server) — Public project discovery
- [GitHub Marketplace](https://github.com/marketplace) — GitHub Apps and Actions
- [MCP Registry](https://registry.modelcontextprotocol.io/) — MCP server metadata
- [MCP registry source](https://github.com/modelcontextprotocol/registry) — Registry API/source
- [CNCF Landscape](https://landscape.cncf.io/) — Cloud-native ecosystem
- [CNCF project list](https://www.cncf.io/projects/) — Graduated, incubating, sandbox projects
- [Artifact Hub](https://artifacthub.io/) — Helm charts, operators and policy packs
- [ROS Index](https://index.ros.org/) — Robot software packages
- [ComfyUI Registry](https://registry.comfy.org/) — AI workflow custom nodes
- [Hugging Face Hub](https://huggingface.co/) — Models, datasets, Spaces
- [Hugging Face Agents](https://huggingface.co/docs/hub/agents) — AI agent integration
- [npm](https://www.npmjs.com/) — JavaScript and TypeScript packages
- [PyPI](https://pypi.org/) — Python packages
- [crates.io](https://crates.io/) — Rust crates
- [Go packages](https://pkg.go.dev/) — Go packages
- [Maven Central](https://central.sonatype.com/) — Java JVM packages
- [NuGet](https://www.nuget.org/) — C#/.NET packages
- [RubyGems](https://rubygems.org/) — Ruby gems
- [Packagist](https://packagist.org/) — PHP Composer packages
- [pub.dev](https://pub.dev/) — Dart Flutter packages
- [Hex](https://hex.pm/) — Elixir Erlang packages
- [LuaRocks](https://luarocks.org/) — Lua packages
- [Conda-forge](https://conda-forge.org/) — Cross-language scientific packages
- [Docker Hub](https://hub.docker.com/) — Container images
- [n8n community nodes directory](https://communitynodes.creahive.com/) — Automation node packages
- [n8n workflow-node search](https://workflownodes.vercel.app/) — Community node search
- [Fermyon Spin](https://www.fermyon.com/spin) — Multi-language WebAssembly apps

## Execution model

1. **Cloudflare edge:** Start from Workers/Agents SDK examples; verify JS/TS, Python or Rust/Wasm compatibility.
2. **External workers:** Use verified HTTP endpoints or queues between Workers and container-based services.
3. **Kernels and operating systems:** Catalogue them as separate hardware/VM/device stacks; do not mislabel them as Cloudflare Worker scripts.
4. **Security and licensing:** Inspect provenance, license, source, dependencies, maintenance, and requested permissions before importing.
5. **Discovery, not intrusion:** Public repository searches do not imply permission to probe or access third-party servers.

## International/language sweep

Use the accompanying discovery script with GitHub repository topics and language filters. Country of origin is not inferred from author names or repository languages.
