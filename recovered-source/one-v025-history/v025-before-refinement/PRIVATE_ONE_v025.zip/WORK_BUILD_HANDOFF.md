# TABOR 1-2-3 FACTORY™ — OCTOBER 9, 2026 WORK BUILD HANDOFF

## READ ME FIRST — CHATGPT WORK
**Product:** TABOR 1-2-3 FACTORY™ / **App #001**.
**Core workflow:** `1. CREATE → 2. CONNECT → 3. LAUNCH`.
**Owner's device:** iPhone only. Build for responsive mobile web/PWA now, cloud native iOS/Android through authorized Expo/EAS later.

**This repository contains a working-but-limited static Factory PWA and archived original game prototypes. It is a public repository. Do not put private ChatGPT archives, images, source secrets, keys, invoices or unapproved personal media into it.**

The owner has also prepared a **private ~60 MB downloadable WORK build ZIP** in ChatGPT. Work should request/open that ZIP, read `WORK_START_HERE.md` and `COPY_THIS_INTO_CHATGPT_WORK.txt` inside, and then follow its **full master product requirements, 32-module catalog, 24-feature inventory, 18-provider registry, backlog, SQL draft, API contract and tests**. That package holds recovered original high-resolution art and source code and must not be uploaded wholesale to this public GitHub.

## Build now, not another plan
1. Audit the entire repo; verify GitHub Pages, Vault, Story Blueprint, Role Atlas and existing tests.
2. Create secure multi-user accounts/workspaces and hosted private asset storage. Reuse existing `app-factory/vault.html` and `vault.js` behavior; replace browser-only limitations with a backend.
3. Import ChatGPT ZIP and supported media/doc/code formats; deduplicate by original bytes, index versions, per-user private permissions, a complete original-byte export and recovery process. No direct ChatGPT account sync claim without supported authorization.
4. Create project registry and **one original asset linked to multiple projects**; import any AI's `tabor123.project.v1` handoff via schema validation and owner approval. Support official OAuth adapters when permitted; show disconnected status until verified.
5. Add AI text/image/video generation with model/provider routing, transparent dollar budgets and caps, device-first availability and Wi-Fi warnings. On-device AI is hardware dependent, and cloud GPU charges exist even on Wi-Fi.
6. Build/test/release pipeline for web/PWA, Expo EAS apps, App Store Connect/Google Play, books, video, marketing, Kickstarter/investor materials, storefront/payments. **No publishing or charges without user approval**; App Store/Play external review required.
7. Preserve distinct creations and implement small playable/editorial slices: Story Blueprint root-of-harm endings, 135-record Historical Role Atlas (many entries need scholarly sources), Angels vs Demons 404-character tactical prototype, TABOR WORLD, ONE MATRIX/GAME OF LIFE, **Healers & Protectors** (main replacement for Maters & Taters; keep Ropato/Otapor in legacy archive), original **TaborTales** (Tater the Drummer Boy, Buddy the BLACK German Shepherd, Moe the Garbanzo Bean, Exodus 14/Christmas, KJV plus real nature/STEM educational tools), stars/almanac/creative books/other inventor products.
8. Add secure privacy, provenance, age-aware education mode, copyright/licensing, accessibility, rate limits, stable schema contracts, migrations, mocks/tests, deploy staging and operational monitoring.
9. Maintain a `WORK_STATUS.md` progress ledger with real working/prototype/blocked/not-started statuses, verified URLs/tests and precise user action requests. Don't merely rename plan sections as finished features.

## Current known repository files
- `app-factory/index.html` — live static project manager, media plan, story writer, historical atlas, AI handoff and launch checklist UI.
- `app-factory/vault.html`, `app-factory/vault.js` — local-first Universal Creator Vault: ZIP/conversation/media import, indexed local storage, previews, project links, tag/filter/search, original download.
- `app-factory/UNIVERSAL-CREATOR-VAULT.md` — multi-tenant production design.
- `app-factory/role-atlas.json` — 135 preliminary entries, **not fully historically verified**.
- `app-factory/ROLE-ATLAS-METHODOLOGY.md` — verification requirements.
- `app-factory/PLATFORM-ARCHITECTURE.md`, `app-factory/MEDIA-ENGINE.md`, `app-factory/README.md` — prior prototypes/specs.
- `app-factory/sync/feed.json` — public demo metadata feed, **not** private account sync.

## Built-vs-missing truth
- **Confirmed source/prototype:** PWA UI, manual project import, local Vault, story and role atlas, recovered original media and several local playable Python/HTML demos in private ZIP.
- **Not connected/fully built:** authenticated multi-tenant service, permanent private cloud binary storage/sync, OAuth AI accounts, background jobs, actual image/video engine, full native builds, store signing/submission, payments, multi-channel posting, production games.
- **User blockers:** Apple Developer old-membership issue ($99 US program renewal/enrollment), EAS login, hosting/billing, developer credentials and store reviews. Use testing mocks and continue other work.

## Nonnegotiable owner preferences
- A genuinely simple 1-2-3 experience; do the technical work in cloud, don't require a Mac.
- Creator media library is **for every user**; privacy is workspace scoped; import original artwork so no re-creation required.
- No random human faces, preserve original characters; founder portraits conceal face. No gacha/pay-to-win for children.
- "Innocence at root" not corrupt and GAME OF LIFE symbolic matrix assumptions are **creative canon**, not proven physics.
- Clearly distinguish myth, faith, interpretations, fiction and primary-source historical/scientific facts.
- Never copy protected franchise likenesses or images into commercial products without rights.
- Owner decides public publishing, any payment or irreversible external action.

## First Work run exit criteria
A repo audit, green CI, working secure staging login, private two-account isolation test, demonstrable original-media import/dedupe and cross-project reuse, portable AI handoff import, detailed implementation status, plus the next production milestone PR. If no external service is connected, ship a tested mock integration with an honest BLOCKED tag; never claim production connection.

**Source:** Creator direction and prototypes from October 9, 2026, with associated recovered originals in the private Work ZIP. No passwords, personal financial credentials or media originals are in this public document.


## NEW GAME: 1420 — THE CROWNING JEWEL (committed Oct 9)
**Status:** playable local-browser prototype, not a finished commercial game or historically complete simulation.
**Open:** `app-factory/games/crowning-jewel.html`
**Engine/tests:** `app-factory/games/crowning-jewel.js`, `app-factory/games/crowning-jewel.test.cjs`
**Game blueprint:** `app-factory/games/CROWNING-JEWEL-BLUEPRINT.md`
**Current play:** 5×5 turn-based Tábor 1420 settlement-defense and civilian-rescue, 1872 African American Knights and Daughters of Tabor mutual-aid civic builder, and a five-clue unlockable cross-century fictional Crowning Jewel archive puzzle using 1899 Dickson 777/333 imagery.
**Research:** Tábor founded 1420, Jan Žižka's wagon-defense methods and Hussite divisions; separate Moses Dickson 1872 fraternal society in Independence, Missouri; 1899 Order publication; later Taborian Hospital. The 1872 association is NOT a military branch descended from the Czech Táborites; its name references biblical Mount Tabor. Historical evidence is cited in the game and blueprint.
**Build next:** make core game part of Factory module registry, asset vault and cross-project publishing pipeline. Add original characters/world art, narrative and diplomacy, save slots, historic chapters Sudoměř/Vítkov Hill/Kutná Hora/Lipany, nineteenth-century benefit programs, 1899 manuscript and later care institution, source audit and educational mode. Preserve current action logic, run `node app-factory/games/crowning-jewel.test.cjs` and add end-to-end mobile browser tests. No real-world armament manufacturing instructions; roles and theological claims are perspectives, not established facts.
**Package caveat:** This game was added **after** the earlier comprehensive Work ZIP. ChatGPT Work must pull current GitHub `main` as authoritative for 1420 alongside the original ZIP.

## PRIVATE 101–901 ROOT CONSTELLATION EXPANSION (2026-10-09)

**Source package**: `TABOR_101_TO_901_COMPLETE_ROOT_CATALOG.zip` downloadable from the user's conversation; not stored on public GitHub. It includes `MASTER_ROOT_ARCHITECTURE.json`, `NEW_101_TO_901_IDEAS.json`, `ORIGINAL_101_GAMES_PRESERVED.json`, `PRIOR_150_CATALOG_PRESERVED.json`, `ROOT_RELATIONSHIPS.json`, `GAP_REGISTER.json`, `READ_ME_AND_GAPS.md`, and a private offline portfolio viewer.

**Verified inventory:** 496 **new proposed** independent app/game concepts, original TW-001 to TW-101 game identities preserved, 150 previously cataloged records preserved (source inventories may overlap), nine eras/tools categories anchored at 101/201/301/401/501/601/701/801/901 with 891 potential slots, 395 unfilled slots, 31 prioritized gaps. **Do not sum overlapping source catalogs as confirmed unique published products.** New ideas are concept-stage only.

**Immediate action for Work:** import this private archive into secure user-specific catalog tables without merging source identities; implement relational edge graph connected to a permissioned TABOR-ROOT for accounts, vault assets, version provenance, history research, AI interchange, and publishing/builds. Per-app stories, asset rights, owners, edits, revenue, release gates and historic eras remain sovereign. Label mythology/faith/fiction and historical facts separately; review dates and source evidence. Public `app-factory/root-constellation.html` is a local-only reader that contains no private idea list. **Never push the private idea catalog to public GitHub without explicit approval.** See `GAP_REGISTER.json` for implementation order.


## ONE — THE LAST APP (separate flagship personal OS product)
**Product:** ONE by Nathan Tabor, personal operating system and permissioned app-orchestration shell. **Keep ONE independent from TABOR 1-2-3 FACTORY**, sharing only approved root infrastructure/assets. The 101–901 ONE architecture codes (frontend, orchestration, vault, workflows, cloud, identity, payments, AI router, native OS bridge) are distinct from Factory's 101–901 creative-history category numbers.

**Prototype:** `app-factory/one/index.html` and `one.js`; 26 A–Z life domains, 19 provider descriptions, local tasks/notes/events, DO bar, Morning/Work/Sleep local flows, export, Zero Mode and action history. Connections to banking, health, communication and installed apps are **not live**. DO NOT claim any real transactions, background OS control, deep scanning or granted OAuth. Document: `app-factory/one/ONE-TECHNICAL-BUILD.md`. Engine tests: `node app-factory/one/one.test.cjs`.

**Build priority:** SwiftUI app + Android Compose shell, private user account, signed-in tenant isolation, EventKit, HealthKit and document picker with individual permissions, Android equivalents, OAuth approved connectors, consent expiration/revoke UI, user-confirmed action plans and durable audit. Only native OS/public APIs allowed; iOS/Android cannot arbitrarily control every installed app. Read whole technical handoff and update Work status as integrations actually pass tests.



## V1.0 MASTER PYTHON SEED — PRIVATE COMPANION FILES

The creator provided a 22-section Python master specification for TABOR 1-2-3 FACTORY and ONE, including:
- Exact XY canon: `XY = GROUNDED (X) WITH WANDER (Y)`, `3 + 1 = 4`, fifth `UNDETERMINED / WHO YOU ARE`, `X = MORAL ABSOLUTES`, `Y = WHY AREN'T MORAL ABSOLUTES ENFORCED`, and `ESTABLISH PEACE AND ORDER`.
- Three sovereign states (positive, negative, neutral), symbolic negative scale and conceptual matrix.
- ONE's A-Z life domains, nine distinct technical layers (101-901) and explicit consent-based connectors.
- TABOR WORLD, 404 target characters, independent Healers & Protectors and archived Maters & Taters, TaborTales, Project Innocence/ACT, Name in the Stars, books, product concepts, creative policies and six build phases.

**Private handoff:** `TABOR_MASTER_V1_WORK_HANDOFF.zip` is available in the creator's ChatGPT conversation. It contains an executable Python seed exporter, `tabor_master_database.json`, `tabor_work_build_brief.md`, validation and namespace-reconciliation JSON, and snapshots of earlier inventory catalogs. It does NOT automatically contain every historic image or conversation and is not a production app. The generated exporter is a faithful structured reconstruction, NOT a byte-for-byte copy of the creator's original pasted Python.

**Mandatory identity guard:** The creator's flagship IDs `TW001–TW008` in this V1 script must **not replace** original inventory `TW-001–TW-101`. Maintain cross-references or aliases. Likewise `one:layer:101` must remain distinct from `factory:category:101`. No existing original files, game titles, or rights metadata should be destroyed, conflated, or silently rewritten.

**Next Work task:** Ingest the private V1 ZIP alongside the earlier private full-build and 101-901 packages; cross-check against the creator's original pasted Python and preserve any source details not captured in the reconstructed seed. Extend database migrations and write tests before importing catalog records. Keep all private archives out of public GitHub without explicit authorization.

## NATHAN AI LET/TET V2 (NEW MODULE)

User supplied a full symbolic `TaborInfluence` definition and requested executable **LET AI NODE** (language and experience translation) and **TET AI NODE** (truth and execution testing) integrated with **PPL** and **THE THINKER**. The validated v2 source is available as a **private conversation attachment** `NATHAN_AI_LET_TET_THE_THINKER_V2.zip`, with full Python source and fourteen passing `unittest` checks. Read `app-factory/nathan-ai/README.md` before integrating and import the private ZIP to a private Work workspace. It preserves the **original twelve-sign PPL v1.0 source** and the five core Tabor directives. Never claim the development prototype has trained a foundation model, can establish factual truth from a SHA-256 checksum, or has authenticated permission to execute. Make it an independent AI module available to ONE and Factory only via explicit, authenticated TABOR ROOT permission scopes. Use a real model adapter, source evidence verification, provider limits, and approval gates when built. Maintain separate versioned PPL contracts.

## UNIVERSAL FIVE-PILLAR STATE ENGINE — EXECUTABLE BUILD

**New private handoff:** `TABOR_UNIVERSAL_101_STATE_ENGINE_WORK_BUILD.zip` in this conversation. 15 passing automated backend tests, a verified API roundtrip, browser frontend, rule validation, SQLite versioned state transactions, per-demo-owner scoping, anti-client-credit rules, idempotent command processing, tamper-evident hash-linked event metadata, example Unity C# client, JSON schemas and Docker local setup. This private code package is not on public GitHub yet. Read `app-factory/universal-state-engine/README.md` and archive `WORK_START_HERE.md`.

**Core rule:** Do not start with graphics or client-authorized inventory changes. Define the bounded context, entity aggregate, JSON contract, legal command -> pure deterministic transition -> domain events -> transactionally committed version and audited result. Apply the five pillars: wisdom/rules, attributes/state, functionality/services, technology/adapters, hardware/deployment. Explicitly keep TW-001/TW001 and ONE/Factory 101–901 namespaces distinct.

**IMPORTANT:** The demo uses a forgeable `X-Owner` value; that is not security. Do not expose it publicly. Implement authenticated identity, authorization, PostgreSQL transactions, external ledger separation, concurrency tests and recovery before production. Cloud gaming/multiplayer, any monetary transaction and app store releases remain not implemented. Build real provider integration only with explicit owner grants.

## TABOR GPS — POSITION + ORIENTATION + TIME

**Independent product:** `app-factory/tabor-gps/index.html` with reusable `gps.js`, full status in `app-factory/tabor-gps/README.md`. A responsive, manual/browser-location prototype computes WGS84 ECEF coordinates, distances, true bearings, personal facing-relative direction, hemisphere-specific poleward direction, and distinguishes five environmental layers. **11 mathematical/functional checks passed**. This is not certified navigation and does not have real road routing, magnetic declination, ETA, native motion sensor fusion, or ionosphere/radiation/magnetopause measurement feeds. Preserve the creator's Earth/time/interface premise but do not interpret five layers as five independent magnetic fields or reverse geographic north in the Southern Hemisphere. Extend with licensed maps, secure user permissions, sensor fusion, historical map orientation, Earth/time globe and validated field tests. No false accuracy claim.

## ⚔️ REMOVE JC — THE WAR OF TWO WORLDS · GAME ENGINE V1

**Playable private Work archive:** `REMOVE_JC_WAR_OF_TWO_WORLDS_WORK_BUILD.zip` (in current conversation), generated from the user's two source dossiers. **90 input topics imported**, grouped as **23 physical, 22 occult/legend, 22 soul/religious, 23 shadow-network claims**. **6 acts, 18 fictional opponents/missions, 6 interactive evidence ciphers, 6 seals and a complete moral-sovereignty ending**; full original game art including a 12-second silent teaser. **27 automated tests passed**, confirmed source/ZIP integrity. An optional Node 22+ authoritative localhost SQLite game server reuses browser engine rules and guards duplicate actions and state versions. Browser headless QA unavailable in current sandbox: do not claim verified on iPhone.

Read `app-factory/remove-jc/README.md`, then import the private ZIP and read `WORK_START_HERE.md`. **GitHub README is not the game source nor proof of public deployment**: full static website and backend code remain inside the downloadable Work package until public/private destinations approved. Preserve original source documents privately and public-facing Atlas with claims clearly labeled; no real faith community or institution is an enemy target. Fictional final fortress/Shadow Council only. Implement auth, server data isolation, genuine 3D action movement, battle and QA later; avoid unsupported historical attribution. Don't overwrite original TABOR WORLD catalog IDs.

## SYSTEM-WIDE REPAIR AUDIT — OCTOBER 10, 2026

**Start with:** [full public system audit](app-factory/SYSTEM_AUDIT_2026-10-10.md) and [release gates](app-factory/RELEASE_GATES.md). The source-code fixes and device installation manifests have been committed into the **PUBLIC** Factory, with automated GitHub Actions checks. This does NOT publish or integrate the private original ZIP packages.

**Private Work data:** 8 owner-supplied archive baselines were retested locally: 27 REMOVE JC, 15 Universal State Engine, 13 Universal Commerce, 9 ChristmasToyDrive, 13 TABOR INFINITUM, 14 Nathan AI, 6 TABOR ROOT and 6 complete Factory starter = **103 passing tests**. Full machine-readable SHA-256 and test-output audit is in the current conversation's owner-private audit artifact. Baseline tests are not end-to-end interservice integration tests.

**Current public Factory additions:** searchable, curated (not exhaustive private) `app-factory/ecosystem.html`; typed `app-factory/core/root-contracts.js` with server-context caveats; PWA manifests for ONE/GPS/1420; public Node quality tests, status verification and restricted service-worker caching. Critical asset dedup bug fixed; too-large/unhashable originals are retained without false deduplication; missing GPS coordinates now rejected.

**Priority:** stop publishing private or unreleased source to public GitHub. Import authorized private packages to owner-controlled private versioned repositories. Implement a full original-byte Vault backup/restore before device cleanup. Implement authenticated tenant isolation across TABOR ROOT. Keep payment, donation, banking, live external action and remote publishing endpoints disabled until approved production provider integrations. Build tests and stage each product separately; do not merge naming conventions (original `TW-001` ≠ `TW001`, ONE 101–901 ≠ creative 101–901).

**Owner action requiring confirmation:** The public root has Apache 2.0 `LICENSE`; confirm intended licensing boundaries for source and commercial assets before any additional original art/source is committed. The assistant has **not** changed that license.

**Verify after each release:** exact GitHub Actions run result, Pages rollout, public file paths, real Safari on iPhone, all package tests, tenant/permission boundaries and backup restore. Update `WORK_STATUS.md` with tested evidence, not aspiration.

## TABOR ROOT KNOWLEDGE & CREATION ENGINE — 2026-10-10

**Owner:** Nathan Tabor; **module:** `T123-KNOWLEDGE-001`. Independently engineered, portable replacement **foundation**, not a clone of Word/Excel/PowerPoint or a claimed AI model. **Private executable ZIP:** `TABOR_ROOT_KNOWLEDGE_CREATION_ENGINE_V1_WORK_BUILD.zip` attached in the current ChatGPT conversation. **44 passing pytest checks**; limited DOCX/XLSX/PPTX file imports/exports, source-aware FTS5 graph, per-record immutable version history, content-addressed source originals, clean full-byte ZIP backup/restore, local FastAPI, responsive JS UI and AI runtime capability planner. Real backend API tested separately; simulated browser interaction tests passed; localhost browser navigation was blocked for automated chromium E2E, so real-device browser QA is pending.

**Read public:** `app-factory/knowledge-engine/README.md` and `app-factory/core/knowledge-record.schema.json`. **Read ZIP:** `WORK_START_HERE.md`, `docs/ARCHITECTURE.md`, `docs/INTEGRATIONS.md`, `docs/BUILD_STATUS.md`, `docs/API_CONTRACT.md` and `BUILD_INTEGRITY_MANIFEST.json`.

**Security and truth boundaries:** **localhost-only; no auth, tenant isolation, real Microsoft Graph, Teams/Outlook, file cloud-sync, trained model, ONNX, GPU/NPU, payments, crowdfunding publishing or remote deletion**. Never publicly deploy the local source or disclose original files to the public GitHub repo. Original imported binaries are retained even when converted text loses formatting. A checksum is not a signed proof of authenticity. Microsoft Graph delta/OAuth is a **future** provider connection; don't build new Exchange Online EWS dependencies while being phased out Oct 2026–2027.

**Factory-wide integration:** All apps/games/books/research/images have separate source identities, and only explicit permissioned cross-project record and asset references are shared. Never overwrite `TW-001`–`TW-101` with `TW001` names. Keep ONE's technical 101–901 namespace separate from the Factory's historical/creative 101–901. Maintain Healers & Protectors as TABOR WORLD's core. Upgrade the prototype to true server-authenticated private workspace, full original-file backups, reliable cloud sync and supported provider adapters before calling it production.

## BUILD-ONCE DEPENDENCY AUDIT — 2026-10-10

**FIRST READ:** [Build Order Controller](app-factory/build-order/index.html) · [Dependency manifest](app-factory/build-order/dependencies.json) · [Reuse matrix / roadmap](app-factory/build-order/README.md). The public repository was inspected before expansion, and **38 independently modeled components** are now assembled into a tested DAG. `planner.js` computes prerequisites, rejects cycles/missing identifiers and tags each domain as **reuse public source**, **import and verify private package**, **build shared implementation once**, **approval needed**, **concept only**, or **catalog only**. Only this metadata graph is public; private ZIPs and assets remain private.

**IMPORTANT, NOW BUILT IN THE PUBLIC VAULT:** `app-factory/vault-backup.js` with `app-factory/vault-backup.test.cjs`; the browser Vault now offers a full-original-byte ZIP export and non-destructive integrity-verified restore. ZIP members are stored without compression and validated by CRC32 + SHA-256. The UI uses **numbered approximately 95 MB source-file batches** to avoid mobile memory spikes; owner must download and preserve **all parts**. A single over-limit original is reported and requires a separate source download. Index-only JSON export remains, but is not a binary backup. These are **tested code paths**, not verified cloud disaster recovery. Real iPhone Safari and large real-library restore testing still required.

**DO NOT RECREATE:** public Vault picker, ONE shell, 1420 rules, TABOR GPS coordinates, Sovereign Box importer, Factory dashboard. Do not rewrite private Knowledge Engine, LET/TET/PPL, State Engine, Commerce, INFINITUM, REMOVE JC, ChristmasToyDrive or Angels 404 based on their readmes; import actual original code into approved private repositories, verify baseline tests and extract shared contracts before enhancing. Maintain each product's own state machines and interfaces.

**ORDER:** inventory → private source destination and full backups → authenticated server identity and owner/tenant isolation → versioned asset store and event contracts → import private engines → tested AI/model adapter, media pipeline and game state services → distinct product vertical slices → authorized platform integrations and human-reviewed release. All 618 public Sovereign Boxes are **records/identities** (101 original games + 496 private proposed slots + 21 modules), not 618 deployed services.

**NEXT BLOCKER REQUIRING OWNER ACTION:** choose the owner-approved destination for **private version-controlled source and media**. The public GitHub hub must not receive full unpublished ZIPs, personal data or proprietary source by default. Do not create payment or publishing credentials or presume Apple developer approval. Keep `WORK_STATUS.md` updated with actual CI and device results.
