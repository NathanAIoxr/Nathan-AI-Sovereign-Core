/* Private ONE v025 A–Z Studio: native input, bounded animation, read-only inspector. */
(function(){'use strict';
const engine=window.StudioMatch3,architecture=window.StructuralGateway,$=id=>document.getElementById(id);
const KEY='one.private.v025.studio.v1',GLYPHS=['◇','○','△','□','⬡','✦'],NAMES=['cyan diamond','violet circle','gold triangle','jade square','coral hexagon','silver star'],COLORS=['#70e5ed','#cca5ff','#ffdb91','#8fe2b6','#ffabb7','#d9e8fc'],POWER_MARK={row:'↔',column:'↕',blast:'✹',spectrum:'✺'};
let state=engine.initial(),meta={wins:0,best:0},recorded=false,selected=null,hint=null,locked=false,pointer=null,suppressClickUntil=0,storage='available',blocked=false,storageMessage='',audio=null;
const observed={pointerSwaps:0,animatedTurns:0},motion=matchMedia('(prefers-reduced-motion: reduce)');
try{const raw=localStorage.getItem(KEY);if(raw){const data=JSON.parse(raw);state=engine.restore(data.save);if(!data.meta||!Number.isSafeInteger(data.meta.wins)||data.meta.wins<0||!Number.isSafeInteger(data.meta.best)||data.meta.best<0||typeof data.recorded!=='boolean')throw Error('Invalid local run records');meta=data.meta;recorded=data.recorded;}}catch(err){blocked=true;storage='preserved malformed save';storageMessage='Existing save could not be loaded and has not been overwritten. Import a valid backup or export this new run separately.';}
function element(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
function say(text){$('status').textContent=text;}
function persist(){if(blocked)return;try{localStorage.setItem(KEY,JSON.stringify({schema:'one.v025.studio.app.v1',save:engine.save(state),meta,recorded}));storage='available';}catch(err){storage='unavailable';storageMessage='Browser storage unavailable. Play remains available; use Export game JSON for a backup.';}$('storage-note').textContent=storageMessage;}
function recordOutcome(){meta.best=Math.max(meta.best,state.score);if(state.status==='won'&&!recorded){meta.wins++;recorded=true;}}
function renderHUD(){
 $('score').textContent=state.score;$('target').textContent=state.goal;$('turns').textContent=state.moves+'/'+state.budget;$('run-wins').textContent=meta.wins;$('seed').value=state.seed;
 $('motion').textContent=motion.matches?'Reduced motion: animation is bypassed; rules are unchanged.':'Animated swaps and cascades. Your system’s reduced-motion preference is respected.';
 for(const id of ['hint','retry','start','random','import-save'])$(id).disabled=locked||(id==='hint'&&state.status!=='playing');
 $('play-hint').disabled=locked||!hint||state.status!=='playing';$('board').querySelectorAll('button').forEach(b=>{b.disabled=locked||state.status!=='playing';});$('board').setAttribute('aria-busy',String(locked));
 const stats=$('run-stats');stats.replaceChildren();for(const [name,value] of Object.entries(state.stats))stats.append(element('p',name.replace(/([A-Z])/g,' $1')+': '+value));stats.append(element('p','Best local score: '+meta.best));
 $('storage-note').textContent=storageMessage;
}
function renderBoard(board=state.board,classes={}){
 const fragment=document.createDocumentFragment();
 board.forEach((tile,i)=>{
  const b=element('button',undefined,'gem'+(selected===i?' selected':'')+(hint&&(hint.a===i||hint.b===i)?' hinted':'')+(classes.clear?.includes(i)?' clearing':'')+(classes.arrive?' arriving':''));
  b.type='button';b.dataset.cell=i;b.dataset.id=tile.id;b.dataset.power=tile.power||'';b.style.setProperty('--gem',COLORS[tile.value]);b.disabled=locked||state.status!=='playing';
  b.setAttribute('aria-label','Row '+(Math.floor(i/8)+1)+', column '+(i%8+1)+': '+NAMES[tile.value]+(tile.power?', '+tile.power+' power':''));b.setAttribute('aria-pressed',String(selected===i));
  b.append(element('span',tile.power==='spectrum'?'✺':GLYPHS[tile.value]));if(tile.power)b.append(element('span',POWER_MARK[tile.power],'power'));
  b.addEventListener('click',()=>{if(performance.now()<suppressClickUntil||locked||state.status!=='playing')return;if(selected===null){selected=i;hint=null;renderBoard();$('board').querySelector('[data-cell="'+i+'"]').focus({preventScroll:true});say('Now choose a neighboring gem.');}else{const a=selected;selected=null;play(a,i);}});
  b.addEventListener('keydown',e=>{const offset={ArrowLeft:-1,ArrowRight:1,ArrowUp:-8,ArrowDown:8}[e.key];if(offset!==undefined){e.preventDefault();const next=i+offset;if(engine.adjacent(i,next))$('board').querySelector('[data-cell="'+next+'"]').focus();}if(e.key==='Escape'){e.preventDefault();selected=null;hint=null;renderBoard();renderHUD();}});
  fragment.append(b);
 });
 $('board').replaceChildren(fragment);
}
function observation(){return {locked,pointerSwaps:observed.pointerSwaps,animatedTurns:observed.animatedTurns,reducedMotion:motion.matches,labelledTiles:$('board').querySelectorAll('button[aria-label]').length,liveStatus:$('status').getAttribute('aria-live')==='polite',sound:$('sound').checked,hudScore:Number($('score').textContent),hudMoves:Number($('turns').textContent.split('/')[0]),storage,wins:meta.wins};}
function renderInspector(){
 const search=$('search').value.trim().toLowerCase(),direction=$('direction').value,rows=architecture.audit(state,engine,observation()).filter(row=>(direction==='all'||row.direction===direction)&&(!search||[row.letter,row.label,row.system,row.definition,row.engineMapping].join(' ').toLowerCase().includes(search)));
 const list=$('layers');list.replaceChildren();for(const row of rows){const card=element('article',undefined,'layer');card.dataset.layer=row.id;
  card.append(element('span',row.direction.toUpperCase()+' '+row.letter,'eyebrow'),element('h3',row.label),element('strong',row.system),element('p',row.definition),element('code',row.engineMapping),element('p',row.labelSource,'small'),element('span',row.result.status.toUpperCase(),'badge '+row.result.status),element('p',row.result.evidence));list.append(card);}
 $('layer-count').textContent=rows.length+' / 52 entries · Reverse inspection is read-only.';
}
function download(value,name,type='application/json'){const blob=new Blob([typeof value==='string'?value:JSON.stringify(value,null,2)],{type}),url=URL.createObjectURL(blob),a=element('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function tone(){if(!$('sound').checked)return;try{const C=window.AudioContext||window.webkitAudioContext;if(!C){say('Sound is unavailable in this browser. Gameplay is unchanged.');return;}audio=audio||new C();audio.resume().catch(()=>{});const oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.frequency.setValueAtTime(330,audio.currentTime);oscillator.frequency.exponentialRampToValueAtTime(660,audio.currentTime+.12);gain.gain.setValueAtTime(.025,audio.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audio.currentTime+.15);oscillator.connect(gain);gain.connect(audio.destination);oscillator.start();oscillator.stop(audio.currentTime+.16);}catch(err){$('sound').checked=false;}}
const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function animateTurn(a,b){
 if(motion.matches)return;
 const left=$('board').querySelector('[data-cell="'+a+'"]'),right=$('board').querySelector('[data-cell="'+b+'"]');
 if(left&&right){const x=left.getBoundingClientRect(),y=right.getBoundingClientRect();left.style.transform='translate('+(y.x-x.x)+'px,'+(y.y-x.y)+'px)';right.style.transform='translate('+(x.x-y.x)+'px,'+(x.y-y.y)+'px)';await delay(150);}
 for(const frame of state.lastTurn.frames.slice(0,3)){renderBoard(frame.before,{clear:frame.cleared});await delay(150);renderBoard(frame.after,{arrive:true});await delay(160);}
 observed.animatedTurns++;
}
async function play(a,b){
 if(locked||state.status!=='playing')return;locked=true;selected=null;hint=null;renderHUD();
 try{
  const accepted=engine.swap(state,a,b);recordOutcome();persist();
  if(!accepted){say(state.lastTurn.reason==='not_adjacent'?'Choose orthogonal neighbors. No move spent.':'No match — exact board restored. No move spent.');return;}
  renderHUD();tone();await animateTurn(a,b);
  const t=state.lastTurn;say(state.status==='won'?'TARGET COMPLETE · '+state.score+' points. Retry this seed or try a new puzzle.':state.status==='failed'?'Move budget reached · '+state.score+'/'+state.goal+'. Retry freely.':t.cleared+' cleared · '+t.cascades+' cascade'+(t.cascades===1?'':'s')+' · +'+t.scoreGained+' points'+(t.powersMade?' · '+t.powersMade+' power earned':'')+(t.reshuffled?' · free dead-board recovery':''));
 }catch(err){say('Move could not be completed: '+err.message);}
 finally{locked=false;renderHUD();renderBoard();if(!$('inspector-view').hidden)renderInspector();}
}
$('board').addEventListener('pointerdown',e=>{const cell=e.target.closest('button[data-cell]');if(!cell||locked||state.status!=='playing'||e.button!==0)return;pointer={id:e.pointerId,cell:Number(cell.dataset.cell),x:e.clientX,y:e.clientY};cell.setPointerCapture?.(e.pointerId);});
$('board').addEventListener('pointerup',e=>{if(!pointer||pointer.id!==e.pointerId)return;const p=pointer;pointer=null;const dx=e.clientX-p.x,dy=e.clientY-p.y;if(Math.hypot(dx,dy)<12)return;suppressClickUntil=performance.now()+400;observed.pointerSwaps++;const target=document.elementFromPoint(e.clientX,e.clientY)?.closest('button[data-cell]');let b=target?Number(target.dataset.cell):-1;if(!engine.adjacent(p.cell,b))b=p.cell+(Math.abs(dx)>Math.abs(dy)?Math.sign(dx):8*Math.sign(dy));play(p.cell,b);});
$('board').addEventListener('pointercancel',()=>{pointer=null;});
function newGame(seed){if(locked)return;try{state=engine.initial(seed);selected=null;hint=null;recorded=false;persist();renderHUD();renderBoard();say('New seeded board. Select, drag or use keyboard controls.');}catch(err){say(err.message);}}
$('start').addEventListener('click',()=>newGame(Number($('seed').value)));$('retry').addEventListener('click',()=>newGame(state.seed));$('random').addEventListener('click',()=>newGame(crypto.getRandomValues(new Uint32Array(1))[0]));
$('hint').addEventListener('click',()=>{if(locked)return;hint=engine.moves(state)[0]||null;selected=null;renderBoard();renderHUD();say(hint?'Try row '+(Math.floor(hint.a/8)+1)+', column '+(hint.a%8+1)+' ↔ row '+(Math.floor(hint.b/8)+1)+', column '+(hint.b%8+1)+' · '+hint.tiles+' opening tiles'+(hint.powers.length?' · creates '+hint.powers.join(', '):'')+'. Future refills are not predicted.':'No hint available after the run ends.');});
$('play-hint').addEventListener('click',()=>{if(hint){const {a,b}=hint;play(a,b);}});
$('sound').addEventListener('change',()=>{if($('sound').checked)tone();else audio?.suspend().catch(()=>{});});
for(const view of ['play','inspector','rules'])$(view+'-tab').addEventListener('click',()=>{for(const key of ['play','inspector','rules']){$(key+'-tab').setAttribute('aria-selected',String(key===view));$(key+'-view').hidden=key!==view;}if(view==='inspector')renderInspector();});
for(const id of ['search','direction'])$(id).addEventListener(id==='search'?'input':'change',renderInspector);$('audit').addEventListener('click',renderInspector);
$('export-save').addEventListener('click',()=>download({schema:'one.v025.studio.app.v1',save:engine.save(state),meta,recorded},'PRIVATE_ONE_v025_Studio_save.json'));
$('import-save').addEventListener('change',async e=>{try{const file=e.target.files[0];if(!file||locked)return;if(file.size>1024*1024)throw Error('File exceeds 1 MB');const data=JSON.parse(await file.text()),next=engine.restore(data.schema==='one.v025.studio.app.v1'?data.save:data);let nextMeta=meta,nextRecorded=next.status==='won';if(data.schema==='one.v025.studio.app.v1'){if(!data.meta||!Number.isSafeInteger(data.meta.wins)||data.meta.wins<0||!Number.isSafeInteger(data.meta.best)||data.meta.best<0||typeof data.recorded!=='boolean')throw Error('Invalid run records');nextMeta=data.meta;nextRecorded=data.recorded;}if(locked)throw Error('Wait for the current animation');state=next;meta=nextMeta;recorded=nextRecorded;blocked=false;storageMessage='';selected=null;hint=null;persist();renderHUD();renderBoard();say('Studio save restored exactly.');}catch(err){say('Import failed: '+err.message+'. Current game preserved.');}finally{e.target.value='';}});
$('export-matrix').addEventListener('click',()=>download({schema:'one.v025.az.matrix.v1',author:'Nathan Tabor',entries:52,layers:architecture.MATRIX},'PRIVATE_ONE_v025_AZ_52_layers.json'));
$('export-blueprint').addEventListener('click',()=>download(architecture.document(),'PRIVATE_ONE_v025_AZ_blueprint.md','text/markdown'));
motion.addEventListener?.('change',()=>renderHUD());
persist();renderHUD();renderBoard();
if(state.status!=='playing')say(state.status==='won'?'TARGET COMPLETE · saved run restored.':'Saved run ended. Retry freely.');
})();
