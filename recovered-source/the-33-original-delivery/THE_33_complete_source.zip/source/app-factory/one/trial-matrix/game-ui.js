/* ONE 33 Trial Matrix: browser presentation. No analytics endpoints or auto-upload. */
(function(){'use strict';
const game=window.OneTrialMatrix;if(!game)throw Error('Trial Matrix engine missing.');
const $=id=>document.getElementById(id);
const profiles=window.TrialProfile,storageKey='one.33trial.progress.v1';
let profile=profiles.initial(),storageWarning='',savedSession=null;
try{const raw=localStorage.getItem(storageKey);if(raw){const data=JSON.parse(raw);profile=profiles.validate(data.profile);savedSession=game.restore(data.save);}}catch(err){storageWarning='Local save could not be loaded. It has not been overwritten. Export a backup before continuing.';}
let session=savedSession||game.initial(profiles.next(profile),8291973,false,Date.now()),selected=null,planStart=null,feedAt=sessionLevelFeed(savedSession),hintMove=null,saveBlocked=!!storageWarning;
function sessionLevelFeed(s){return s?.level===5?Date.now()+2000:null;}
$('telemetry').checked=session.telemetryEnabled;
function persist(){if(saveBlocked)return;try{localStorage.setItem(storageKey,JSON.stringify({schema:'one.33trial.progress.v1',profile,save:game.save(session)}));}catch(err){storageWarning='Browser storage unavailable. Use Export JSON to keep your progress.';}}
function settle(){const reward=profiles.award(profile,session,game.LEVELS[session.level-1]);if(reward.earned)session.feedback+=' Earned '+reward.coins+' coins and '+reward.gems+' gems.';persist();}

function button(text,fn,cls,aria){const b=document.createElement('button');b.type='button';b.textContent=text;if(cls)b.className=cls;if(aria)b.setAttribute('aria-label',aria);if(fn)b.addEventListener('click',fn);return b;}
function node(tag,text,cls){const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;}
function resetSelection(){selected=null;planStart=null;hintMove=null;}
function newTrial(level=session.level){resetSelection();session=game.initial(level,(Date.now()^Math.imul(level,8291973))>>>0,!!$('telemetry').checked,Date.now());feedAt=level===5?Date.now()+2000:null;persist();render();}
function chooseLevel(level){newTrial(level);}
function update(a){game.step(session,a,Date.now());resetSelection();settle();render();}
function tap(i,coord){if(session.status!=='playing')return;
 if(selected===null){selected={i,coord};planStart=Date.now();$('selection-hint').textContent='Now select the tile to swap with';renderBoard();return;}
 const start=selected;if(session.level===4)update({type:'swap',a:start.coord,b:coord,planStartMs:planStart});else update({type:'swap',a:start.i,b:i,planStartMs:planStart});
}
function tile(value,onClick,extra='',number){let glyph=value===-1?'🧭':value===null?'':game.GLYPHS[Math.min(session.level-1,4)][value];const b=button(glyph,onClick,'tile '+extra+(selected!==null&&number===selected.i?' selected':''),number==null?undefined:'Slot '+(number+1)+(value===null?' structural void':' '+glyph));if(value===-1)b.classList.add('anchor');if(value===null){b.classList.add('void');b.disabled=true;}if(onClick===null)b.disabled=true;return b;}
function monolith(){const wrap=node('div',undefined,'tiles');session.board.forEach((v,i)=>{const playable=i<16&&v!==-1;let b=tile(v,playable?()=>tap(i):null,'',i);b.title=i===16?'The immutable compass anchor':i<16?'Choose LEFT wing: right wing auto-mirrors':'Right symmetry wing: automatic';wrap.append(b);});$('board').append(wrap);}
function makeRing(name,values,ring){const section=node('div',undefined,'ring '+name),title=node('div',name.toUpperCase()+' · '+values.length+' nodes','ring-name');section.append(title);values.forEach((v,i)=>{const b=tile(v,null,'',i);b.title=name+' node '+(i+1);const angle=-Math.PI/2+2*Math.PI*i/values.length;b.style.left=(50+43*Math.cos(angle))+'%';b.style.top=(50+43*Math.sin(angle))+'%';b.style.transform='translate(-50%,-50%)';section.append(b);});return section;}
function babylon(){const rings=node('div',undefined,'rings');rings.append(makeRing('outer',session.board.outer),makeRing('inner',session.board.inner),makeRing('core',session.board.core));$('board').append(rings);
 const p=$('ring-actions');p.hidden=false;p.replaceChildren();for(const ring of ['outer','inner'])for(const dir of [-1,1])p.append(button(ring.toUpperCase()+(dir===1?' ↻ clockwise':' ↺ counterclockwise'),()=>update({type:'rotate',ring,direction:dir})));
 p.append(node('span','Aligned radial paths: '+game.axes(session).length+'/3','small'));}
function rhombus(){const wrap=node('div',undefined,'diamond');session.board.forEach((v,i)=>wrap.append(tile(v,v===null?null:()=>tap(i),'',i)));$('board').append(wrap);}
function epidaurus(){const all=node('div',undefined,'funnel');session.board.forEach((row,r)=>{const line=node('div',undefined,'tiles'+(r===5?' bed':''));row.forEach((v,c)=>line.append(tile(v,()=>tap(r*100+c,{r,c}),'',r*100+c)));all.append(line);});$('board').append(all);}
function archimedes(){const grid=node('div',undefined,'spiral'),coordinates=new Map(game.SPIRAL.map(([r,c],i)=>[r*8+c,i]));
 for(let r=0;r<8;r++)for(let c=0;c<8;c++){const idx=coordinates.get(r*8+c),v=session.board.chain[idx],occupied=idx<session.board.chain.length,voidSlot=idx===63;
 const onClick=occupied&&session.status==='playing'?()=>tap(idx):null;
 const b=tile(occupied?v:null,onClick,voidSlot?'maw':occupied?'':'emptied',idx);
 b.classList.remove('void');b.disabled=!occupied;b.textContent=voidSlot?'💀':occupied?game.GLYPHS[4][v]:'·';
 const x=node('small',String(idx+1));b.prepend(x);b.setAttribute('aria-label','Spiral slot '+(idx+1)+(voidSlot?' Entropy Void':'')+(occupied?' occupied':' empty'));grid.append(b);
 }$('board').append(grid);}
function expanded(){
 const b=session.board,grid=node('div',undefined,'expanded-board');grid.style.setProperty('--columns',b.cols);
 for(let i=0;i<b.cells.length;i++){
  const p=game.expansion.presentation(session,i,selected?.i===i||hintMove?.a===i||hintMove?.b===i),tileButton=button(p.text,()=>tap(i),'tile'+(p.void?' void':'')+(selected?.i===i?' selected':'')+(hintMove?.a===i||hintMove?.b===i?' hinted':''));
  tileButton.disabled=p.disabled||session.status!=='playing';tileButton.setAttribute('aria-label','Row '+(Math.floor(i/b.cols)+1)+', column '+(i%b.cols+1)+': '+p.text+(p.disabled?' (fixed)':''));tileButton.dataset.slot=i;
  if(p.ink)tileButton.style.color=p.ink;
  if(session.level===10){tileButton.style.borderColor=['#efdba9','#83d3e5','#ccafff'][(Math.floor(i/b.cols/3)+Math.floor(i%b.cols/3))%3];}
  if(session.level===24){if(i%b.cols===4)tileButton.style.marginLeft='6px';if(Math.floor(i/b.cols)===4)tileButton.style.marginTop='6px';}
  grid.append(tileButton);
 }
 $('board').append(grid);$('board').append(node('p',game.expansion.status(session),'help'));
 const actions=$('ring-actions');actions.hidden=false;
 if(session.level===8)actions.append(button(b.revealed?'Hide symbols':'Study symbols (free)',()=>update({type:'study'})));
 if(session.level===23)for(const phase of [0,1]){const control=button((phase?'Dark':'Light')+' state',()=>update({type:'phase',phase}));control.setAttribute('aria-pressed',String(b.phase===phase));actions.append(control);}
 if(session.level===26)actions.append(button(b.inspect?'Hide weights':'Inspect weights (free)',()=>update({type:'inspect'})));
}
function renderBoard(){const b=$('board');b.replaceChildren();$('ring-actions').hidden=true;$('ring-actions').replaceChildren();
 if(session.level===1)monolith();else if(session.level===2)babylon();else if(session.level===3)rhombus();else if(session.level===4)epidaurus();else if(session.level===5)archimedes();else expanded();
 $('selection-hint').textContent=selected===null?'Select '+(session.level===2?'a ring rotation':'a tile to begin'):'Choose the second tile';
}
function formatMetric(v){if(v==null)return 'Insufficient moves';if(typeof v==='number')return Number.isInteger(v)?String(v):v.toFixed(3);return String(v);}
function renderMetrics(){const el=$('metrics');el.replaceChildren();const m=game.metrics(session);
 const entries=Object.entries(m).filter(([k])=>!['schema','trialId','trialName','gameplayOnly','notStandardizedIQTest','consentOptIn','elapsedMs','moves','progress','penalties','outcome','interpretation'].includes(k));
 if(!session.telemetryEnabled){el.append(node('p','Detailed event telemetry OFF. Basic game counters remain available during play; no detailed events are stored.'));return;}
 for(const [key,value] of entries){const line=node('p',undefined,'metric');const strong=node('strong',key.replace(/([A-Z])/g,' $1').replace(/^./,c=>c.toUpperCase())+': ');line.append(strong,node('span',value&&typeof value==='object'?JSON.stringify(value):formatMetric(value)));el.append(line);}
 if(m.interpretation)el.append(node('p',m.interpretation,'small'));
}
function render(){const def=game.LEVELS[session.level-1];$('stage-title').textContent=def.name;$('stage-tagline').textContent='“'+def.tagline+'”';$('level-tag').textContent='EPOCH '+def.epoch+' · TRIAL '+String(session.level).padStart(2,'0')+' / 33 · '+def.geometry;
 $('hint').disabled=session.status!=='playing';
 $('apply-hint').disabled=!hintMove;
 const nav=$('level-nav');nav.replaceChildren();game.LEVELS.forEach(def=>{const b=button('',()=>chooseLevel(def.id));b.append(node('strong',String(def.id).padStart(2,'0')),node('span',def.name));if(def.id===session.level)b.setAttribute('aria-current','step');if(profile.completed.includes(def.id))b.append(node('small','★'.repeat(profile.stars[def.id])+' Complete'));nav.append(b);});
 $('wallet').textContent='Free starter gift included · '+profile.coins+' coins · '+profile.gems+' gems · '+Object.values(profile.stars).reduce((a,b)=>a+b,0)+' stars · '+profile.completed.length+'/33 completed. All stages, hints and retries are free.';
 $('storage-status').textContent=storageWarning;
 $('continue').textContent='Continue → Trial '+profiles.next(profile);
 const stats=[['Level',String(session.level)+'/33'],['Progress',session.progress+'/'+def.goal],['Moves',session.moves+(def.moveLimit===null?'':'/'+def.moveLimit)],['Structural penalties',session.penalties]];
 $('scoreboard').replaceChildren();for(const [label,val] of stats){const x=node('div',undefined,'stat');x.append(node('strong',val),node('span',label));$('scoreboard').append(x);}
 const m=game.metrics(session);
 $('feedback').textContent=(session.status==='playing'?session.feedback||'Choose tiles or use the ring controls to begin.':session.status==='won'?'TRIAL COMPLETE — '+session.feedback:'TRIAL FAILED — '+session.feedback)
 +(session.level===5?' · Spiral occupancy '+session.board.chain.length+'/64':'');
 $('mechanics').textContent=def.detail;
 $('spec-details').replaceChildren();
 for(const [label,text] of [['Geometry',def.geometry],['Rules',def.detail],['Gameplay metric',def.metric],['Trial objective',String(def.goal)+(session.level===10?' rooms':session.level===33?' seals':session.level>=6?' objective points':' structural matches')]]){
  const x=node('p');x.append(node('strong',label+': '),node('span',text));$('spec-details').append(x);
 }
 if(session.level===2)$('spec-details').append(node('p','The displayed I/II/III/IV symbols follow the submitted visual labels; they are Roman-style numerals, not verified cuneiform.','technical'));
 if(session.level===5)$('spec-details').append(node('p','The entropy clock injects one tile every 2,000 ms while this level is active. Browsers may throttle timers in background tabs.','technical'));
 renderBoard();renderMetrics();
}
function downloadJSON(value,filename){const blob=new Blob([JSON.stringify(value,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=filename;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
function synchronizeSpiral(){if(session.level!==5||session.status!=='playing'||feedAt==null)return;
 const now=Date.now();let n=0;while(now>=feedAt&&session.status==='playing'&&n<128){game.step(session,{type:'tick'},feedAt);feedAt+=2000;n++;}if(n){settle();render();}
}
$('telemetry').addEventListener('change',()=>{if(session.moves||session.progress||session.level===5&&session.board.ticks){$('feedback').textContent='Detailed telemetry preference changed. Press Restart trial to apply the new setting.';return;}newTrial();});
$('new-session').addEventListener('click',()=>newTrial());
$('continue').addEventListener('click',()=>newTrial(profiles.next(profile)));
$('hint').addEventListener('click',()=>{
 hintMove=game.hint(session);
 if(!hintMove){$('feedback').textContent='No match available yet. On the spiral, wait for the next tile feed.';return;}
 if(session.level===23)game.step(session,{type:'phase',phase:hintMove.phase},Date.now());
 selected=null;planStart=null;renderBoard();
 const position=v=>typeof v==='object'?'row '+(v.r+1)+', column '+(v.c+1):'slot '+(v+1);
 $('feedback').textContent=hintMove.type==='rotate'?'Free hint: rotate '+hintMove.ring+' '+(hintMove.direction===1?'clockwise':'counterclockwise')+'.':'Free hint: swap '+position(hintMove.a)+' with '+position(hintMove.b)+'.';
 $('apply-hint').disabled=false;
});
$('apply-hint').addEventListener('click',()=>{if(!hintMove)return;const action=hintMove;hintMove=null;update(action);$('apply-hint').disabled=true;});
$('export').addEventListener('click',()=>{downloadJSON({schema:'one.33trial.progress.v1',profile,save:game.save(session)},'THE_33_Level_'+session.level+'_progress.json');});
$('import').addEventListener('change',async e=>{try{const f=e.target.files[0];if(!f)return;if(f.size>1024*1024)throw Error('Save file too large (1 MB limit)');const data=JSON.parse(await f.text());const restored=game.restore(data.schema==='one.33trial.progress.v1'?data.save:data),restoredProfile=data.schema==='one.33trial.progress.v1'?profiles.validate(data.profile):profile;session=restored;profile=restoredProfile;saveBlocked=false;storageWarning='';$('telemetry').checked=session.telemetryEnabled;resetSelection();feedAt=session.level===5?Date.now()+2000:null;settle();render();}
 catch(err){$('feedback').textContent='Save import failed: '+(err.message||String(err));}finally{e.target.value='';}});
document.addEventListener('visibilitychange',()=>{if(!document.hidden)synchronizeSpiral();});
setInterval(()=>synchronizeSpiral(),250);
render();
if(!storageWarning){settle();render();}
})();